import { cn } from '@/lib/cn';

// Marca em texto (quadro de marca CÓRTEX). O símbolo hexagonal oficial ainda não está no repositório como
// arquivo vetorial — não é redesenhado aqui (docs/CORTEX/historico/registro-de-auditoria-2026-09-14-a-25.md).
export function CortexWordmark({
  as: Tag = 'span',
  tagline = true,
  size = 'md',
  className,
}: {
  as?: 'span' | 'h1' | 'p';
  tagline?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}) {
  const word = { sm: 'text-lg', md: 'text-xl', lg: 'text-3xl' }[size];
  const sub = { sm: 'text-[8px]', md: 'text-[9px]', lg: 'text-[11px]' }[size];
  return (
    <div className={cn('flex flex-col leading-none', className)}>
      <Tag className={cn(word, 'font-bold tracking-[0.12em] text-foreground')}>CÓRTEX</Tag>
      {tagline && (
        <span className={cn(sub, 'mt-1 font-medium uppercase tracking-[0.32em] text-muted-foreground')}>
          Lógica de Negócios
        </span>
      )}
    </div>
  );
}
