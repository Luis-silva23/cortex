// Build de PRODUÇÃO só aponta para uma API em HTTPS (o endereço é fixado no build). Exceção: loopback (homologação de um host só, sem
// TLS). Falha fechada: um build com http://servidor-real não sai, em vez de mandar senha e token em texto puro.
const apiUrl = process.env.NEXT_PUBLIC_API_URL;
if (process.env.NODE_ENV === 'production' && apiUrl && !/^https:\/\//i.test(apiUrl) && !/^http:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/i.test(apiUrl)) {
  throw new Error('NEXT_PUBLIC_API_URL precisa ser https:// em build de produção (http só para localhost)');
}

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Necessário para o Dockerfile multi-stage (apps/admin-web/Dockerfile):
  // 'standalone' produz um server.js self-contained com só as dependências
  // realmente usadas (Next.js faz tree-shaking do node_modules), em vez de
  // precisar copiar node_modules inteiro (centenas de MB) pra imagem final.
  output: 'standalone',
  transpilePackages: ['@ln-system/shared'],
  // O build VALIDA tipos e lint (antes ignorava os dois: um erro de tipo ou de lint chegava a produção sem ninguém ver). Estavam limpos
  // em 2026-10-06 (`tsc --noEmit` e `next lint` sem erro); o CI também roda os dois antes do build.
  eslint: {
    ignoreDuringBuilds: false,
  },
  typescript: {
    ignoreBuildErrors: false,
  },
  // Otimizações de imagem
  images: {
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    minimumCacheTTL: 60,
  },
  // Code splitting otimizado
  experimental: {
    optimizePackageImports: ['lucide-react', 'recharts'],
    // Em máquina corporativa/limitada: NEXT_BUILD_CPUS=2 reduz os processos de trabalho do `next build` (padrão: núcleos − 1).
    ...(process.env.NEXT_BUILD_CPUS && { cpus: Math.max(1, Number(process.env.NEXT_BUILD_CPUS)) }),
  },
  // Compressão
  compress: true,
  // Não anuncia o framework; cabeçalhos de segurança básicos em toda página (anti-clickjacking, anti-sniffing, referrer e permissões).
  // CSP completa fica de fora de propósito: o script de tema do layout é inline (exigiria nonce); registrado como evolução.
  poweredByHeader: false,
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
          { key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains' },
        ],
      },
    ];
  },
  // Otimizar produção
  ...(process.env.NODE_ENV === 'production' && {
    compiler: {
      removeConsole: {
        exclude: ['error', 'warn'],
      },
    },
  }),
}

module.exports = nextConfig
