**Execução de 2026-10-14** (`npm run db:replay-check`) — banco temporário vazio, criado e removido pelo script; o banco de desenvolvimento só foi lido. Resultado: **IDÊNTICO — nada no banco de desenvolvimento escapa das migrations**.

- `prisma migrate deploy` em banco vazio: sucesso (36 migrations encontradas em `prisma/migrations`).
- `prisma migrate diff` (banco → schema.prisma): banco reaplicado do zero e banco de desenvolvimento produzem **exatamente a mesma saída** (7 instruções; são as diferenças intencionais que o Prisma não representa — ver BANCO_DE_DADOS §4).
- Catálogo completo (colunas, índices, constraints, policies, RLS, triggers, funções, sequências, enums): dev = 3331 itens, reaplicado = 3331 itens; **só no dev: 0**; **só no reaplicado: 0**.
- PostgreSQL: PostgreSQL 18.6 on x86_64-windows.
- `db:check-rls` no banco reaplicado: todas as invariantes OK — [check-rls] "lnsystem_db_replay_tmp": todas as invariantes de RLS OK
- Banco temporário removido: sim.
