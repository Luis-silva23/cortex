# Pacote de revisão do banco de dados (CÓRTEX)

Gerado em 2026-10-14 por `cd apps/api && npm run db:docs -- --write`. Contém **apenas estrutura**: cópia do schema Prisma e das 36 migrations (SQL), com SHA-256 em `SHA256SUMS.txt`. Sem segredo, sem dado de cliente, sem `.env`.

- `packages/database/prisma/schema.prisma` — schema atual.
- `packages/database/prisma/migrations/` — todas as migrations, na ordem de execução, e `migration_lock.toml`.
- `drift-dev.txt` — saída de `prisma migrate diff` (banco de desenvolvimento → schema).
- `replay-resultado.md` — resultado de reaplicar as migrations do zero em banco vazio (`npm run db:replay-check`).

Documentos relacionados (em `docs/CORTEX`): `BANCO_DE_DADOS.md` (inventário por tabela), `MAPA_RELACIONAMENTOS.md`, `RELATORIO_MIGRATIONS.md`, `REVISAO_BANCO_PENDENCIAS.md`, `DECISIONS.md`.

Conferir a integridade: `sha256sum -c SHA256SUMS.txt` (a partir desta pasta).
