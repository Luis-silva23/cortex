# Revisão do banco de dados — problemas, riscos e pendências antes da produção

> Escrito em 2026-10-14 para revisão técnica **independente**. Fonte: catálogo do PostgreSQL de **desenvolvimento** (18.6, dados sintéticos), `schema.prisma`, as 36 migrations e o código da API. Nada foi lido de cliente real; nada foi alterado no banco para gerar este documento (só leitura; o único banco criado foi um temporário vazio, já removido). O bloco "Achados automáticos" (§2) é regerado por `cd apps/api && npm run db:docs -- --write --orphans`; o restante é análise escrita.
>
> Convenção: **Observado** = verificado por consulta/execução nesta data · **Inferência** = dedução técnica do código/policy, não executada · **Pendente** = depende de decisão, infraestrutura ou jurídico. Gravidade: **Alta** (resolver/decidir antes de produção), **Média**, **Baixa**.
> Documentos irmãos: [BANCO_DE_DADOS](BANCO_DE_DADOS.md) (por tabela), [MAPA_RELACIONAMENTOS](MAPA_RELACIONAMENTOS.md), [RELATORIO_MIGRATIONS](RELATORIO_MIGRATIONS.md), [DECISIONS](DECISIONS.md) (quadro "Decisões e pendências que tocam o banco de dados"), pacote com schema e migrations em [revisao-banco/](revisao-banco/LEIA-ME.md).

## 0. Resumo executivo

| Pergunta | Resposta | Evidência |
|---|---|---|
| Quantas tabelas? | **106**, as mesmas 106 do schema Prisma | catálogo × `schema.prisma`: nenhuma sobrando/faltando |
| As migrations reproduzem o banco? | **Sim**: 36 migrations aplicadas do zero num banco vazio dão exatamente o catálogo do dev (3 331 itens iguais; 0 só no dev, 0 só no reaplicado) e o mesmo `prisma migrate diff` | `npm run db:replay-check` ([RELATORIO_MIGRATIONS §4](RELATORIO_MIGRATIONS.md)) |
| Há alteração manual invisível? | **Não encontrada** (a prova acima) · checksums das 36 conferem com os arquivos · nenhuma migration aplicada fora do repositório | `_prisma_migrations` do dev e do teste |
| RLS | **106/106 habilitada e forçada**, todas com policy; a conexão da aplicação não é superusuário nem ignora RLS | `db:check-rls` e catálogo |
| Isolamento entre empresas | Bom nas tabelas com `companyId` (`users`: 0 linhas de outra empresa visíveis a uma sessão de empresa) — **com exceções que exigem decisão** (R1–R4) | consulta em sessão de empresa, revertida |
| Está pronto para produção? | **Não**: faltam aplicar/validar em staging e produção, backup restaurável testado e as decisões de R1–R4 | §1 (R13–R15) |

## 1. Problemas e riscos identificados

### Segurança e isolamento

**R1 — `refresh_tokens`: sem isolamento por empresa e token em texto. Gravidade: Alta (antes de produção).**
- *Observado:* as 136 linhas do dev têm `companyId` **nulo** (o código que cria a sessão — `auth.service.ts` — não preenche a coluna) e a policy `refresh_tokens_isolation` aceita `"companyId" IS NULL` para qualquer sessão; uma sessão **de empresa** (COMPANY_ADMIN) enxerga as 136 linhas (todas as sessões do dev, de qualquer empresa e, quando existem, de Super Admin). A coluna `token` guarda o **refresh token em texto** (a busca é por igualdade).
- *Por que importa:* a aplicação sempre filtra por token/usuário, então não há vazamento hoje por rota; mas uma falha futura de filtro, uma injeção de SQL ou um backup lido por terceiro entrega sessões utilizáveis (7 dias) de todas as empresas. A RLS, que deveria ser a segunda barreira, não protege esta tabela.
- *Recomendação (não aplicada — mexe no núcleo de autenticação e exige migration + testes):* (1) preencher `companyId` na criação e remover o ramo `IS NULL` da policy para contextos de empresa (Super Admin usa o contexto de plataforma, que já passa por `is_super_admin()`); (2) guardar o **SHA-256** do refresh token e buscar pelo hash, com leitura dupla (hash e texto) até as sessões antigas expirarem (≤ 7 dias); (3) teste de integração de acesso cruzado. **Decide:** responsável técnico/dono. **Pendente:** aprovação.

**R2 — Policies `ALL` que aceitam `companyId` nulo ou `WITH CHECK true`. Gravidade: Média.**
- *Observado (catálogo):* `request_logs_isolation` e `system_logs_isolation` têm `WITH CHECK true` — uma sessão de empresa pode gravar log com `companyId` de **outra** empresa ou nulo (falsificar log). `roles_isolation` e `permissions_isolation` usam `USING (… OR "companyId" IS NULL)` em comando `ALL`.
- *Inferência (semântica do PostgreSQL, não executada para não alterar dado):* em `ALL`, o `DELETE` usa só o `USING`; logo uma sessão de empresa poderia apagar perfis/permissões **globais** (`companyId` nulo). Hoje o dev não tem perfil nem permissão global (0 linhas em cada), e a aplicação não oferece essa operação.
- *Recomendação:* separar por comando (SELECT pode ver o global; INSERT/UPDATE/DELETE só da própria empresa ou Super Admin); `WITH CHECK` de logs igual ao `USING`. **Pendente:** aprovação (muda RLS).

**R3 — Livros e históricos imutáveis só na aplicação. Gravidade: Média.** *Observado* (§2-E): `stock_movements`, `cash_movements`, `sale_items`, `revisions`, `service_order_status_history` e `policy_changes` permitem UPDATE/DELETE pela RLS; `audit_logs`, `collection_attempts`, `discount_events` e `monitoring_threshold_changes` já negam UPDATE no banco. Varredura do código: a aplicação só altera `sale_items.returnedQuantity` (devolução) e `revisions.notes` (anonimização, decisão 120); nenhuma rota apaga os demais. *Recomendação:* repetir o padrão de `20260925100000_audit_logs_append_only` onde nenhuma rota atualiza. **Pendente:** aprovação (migration).

**R4 — `ON DELETE CASCADE` sobre histórico. Gravidade: Média (mitigada pela aplicação).** *Observado* (§2-D): 41 FKs em cascata, entre elas `stock_movements.productId → products`, `sale_items.saleId → sales`, `payments.saleId → sales` e `cash_movements.cashRegisterId → cash_registers`. Apagar o pai apaga o histórico financeiro/de estoque. Mitigação *observada*: o único `delete` de entidade-pai no código (`company`, `product`, `sale`, `cashRegister`, `customer`, `serviceOrder`) é `company.delete`, e só para empresa **sem filiais e sem usuários**. *Recomendação:* `RESTRICT` nessas FKs (decisão consciente: hoje, "limpar" um produto de teste por SQL apagaria o livro dele). **Pendente:** aprovação.

**R5 — Colunas sensíveis. Gravidade: Baixa (inventário) / Média (retenção).** 48 colunas pelo nome (§2-F). *Observado no código:* senha = Argon2id/bcrypt; `mfaSecret` e segredos fiscais/de canal = `enc:v1` (AES com `DATA_ENCRYPTION_KEY`); códigos de recuperação e `devices.secretHash` = hash; **exceção:** `refresh_tokens.token` (R1). Dado pessoal (LGPD): `customers` (documento, e-mail, telefone, nascimento, endereço), `suppliers`, `users`, `support_tickets` (solicitante) e **endereços IP** (`audit_logs`, `refresh_tokens`, `device_sessions`, `devices`, `activations`). **Pendente (jurídico):** prazo de retenção de IP e de logs — não há expurgo automático (R9).

### Integridade

**R6 — Escopo e relações sem chave estrangeira. Gravidade: Média.** *Observado:* 74 das 85 tabelas com `companyId` não têm FK para `companies`, e 64 tabelas com `branchId` não têm FK para `branches` (convenção do projeto: o isolamento é da RLS); 43 relações entre entidades também são só lógicas (ex.: `sales.cashRegisterId`, `tef_payments.saleId`, `fiscal_documents.saleId`, `accounts_receivable.customerId`, `stock_movements.userId`). Conferência de órfãos (§2-D2, só contagem, papel de leitura que ignora RLS): **181 relações, 10 com órfãos** — `request_logs`/`system_logs` (logs de empresas/usuários de teste já removidos: esperado, sem FK por desenho), `idempotency_keys.companyId` (7) e **uma `accounts_receivable` (`ServiceOrder`, `PAID`, criada em 14/09/2026) cuja empresa, filial e cliente não existem mais** — sobra de teste antigo, **não removida** (regra: não apagar registro financeiro). *Inferência:* a origem provável é a limpeza de uma empresa de teste (sem FK, nada impede apagar a empresa deixando o recebível); a decisão pendente é se o `companyId` das tabelas financeiras deve ter FK `RESTRICT`. **Pendente:** decisão e investigação da origem.

**R7 — Diferenças intencionais entre schema e banco (7 instruções do `prisma migrate diff`). Gravidade: Média (operacional).** O Prisma não representa a coluna gerada `support_kb_articles.search` (tsvector) e seu índice GIN, a sequência `support_ticket_number_seq`/`DEFAULT nextval` de `support_tickets.ticketNumber` e os `DEFAULT now()` de `updatedAt` de duas tabelas (arquivo [revisao-banco/drift-dev.txt](revisao-banco/drift-dev.txt)). **Risco:** um `prisma migrate dev` ou `db push` futuro **proporia apagar** esse índice e essa sequência. *Mitigação em vigor:* a regra do projeto (e desta tarefa) é só `migrate deploy`; as diferenças estão documentadas em [BANCO_DE_DADOS §4](BANCO_DE_DADOS.md). *Recomendação:* se a equipe usar `migrate dev`, modelar esses objetos no schema (`Unsupported("tsvector")`, `@default(dbgenerated(...))`) numa mudança própria. **Pendente:** decisão técnica.

**R8 — Duplicatas legadas de `products.barcode`.** A migration `20261014100000_product_barcodes` copia o código principal sem descartar duplicatas (a primeira entra, as demais seguem ambíguas na leitura com 409). *Pendente:* o dono decidir qual produto vale antes de produção, se houver duplicata real. Gravidade: Baixa (nenhuma duplicata conhecida no dev).

### Operação

**R9 — Sem retenção/expurgo automático de `audit_logs`, `request_logs`, `system_logs`, `idempotency_keys` e evidências.** Crescimento ilimitado e dado pessoal (IP, usuário) sem prazo. *Observado no dev:* `request_logs` com ≈ 13 mil linhas apontando empresas inexistentes. *Pendente:* política de retenção aprovada (jurídico + dono); só então criar rotina e (se preciso) partição.

**R10 — Índice de `companyId` ausente em 10 tabelas filhas** (§2-A). A RLS filtra por `companyId`; sem índice, o plano depende do índice da chave do pai. Gravidade: Baixa até haver volume. *Recomendação:* acompanhar `pg_stat_statements` em staging; criar índice sob demanda (migration aditiva).

**R11 — 9 tabelas com `branchId` cuja policy não usa filial** (§2-A: `devices`, `installment_policies`, `monitoring_threshold_changes`, `monitoring_thresholds`, `partners`, `request_logs`, `system_logs`, `user_roles`, `users`). O isolamento por filial é só da aplicação nelas. Gravidade: Baixa/Média — *Inferência:* são tabelas de escopo de empresa (a filial é atributo, não fronteira), mas a decisão de produto "o gerente da filial A vê o usuário da filial B?" precisa ser confirmada. **Pendente:** dono.

**R12 — Migrations: 15 de 36 trazem a reversão documentada no cabeçalho** (as 5 de 2026-10-14 todas trazem). Só 1 contém operação que apaga/substitui estrutura (`20260925100000_audit_logs_append_only`: troca uma policy; reversão descrita). Nenhuma contém `DELETE`, `TRUNCATE`, `DROP TABLE` ou `DROP COLUMN` (varredura textual do SQL). Gravidade: Baixa. *Recomendação:* exigir reversão no cabeçalho de toda migration nova.

### Infraestrutura e processo (pendentes)

**R13 — Nada aplicado em staging/produção.** As 36 migrations estão aplicadas só no dev e no teste. Roteiro: backup restaurável → `prisma migrate deploy` → `npm run db:check-rls` → suíte de integração apontada ao staging ([PRODUCAO §4, §13–14](PRODUCAO.md)). **Pendente:** ambiente (infraestrutura).

**R14 — PostgreSQL 18 em Linux não exercitado.** O dev roda 18.6 no Windows e a CI/compose usam `postgres:18-alpine`; a cadeia de migrations nunca rodou em Linux nesta máquina (sem Docker). **Pendente:** CI com Docker.

**R15 — Backup restaurável só provado em desenvolvimento** (`backup:verify`, 18/18, mesma instância). **Pendente:** restauração em **outro host** e RPO/RTO definidos pelo responsável (decisão 106).

**R16 — Verificação periódica de deriva.** Recomenda-se rodar `npm run db:replay-check` (cria banco temporário, aplica tudo do zero, compara com o dev e remove) e `npm run db:check-rls` na CI a cada mudança de migration. Não foi adicionado ao pipeline (não pode ser exercitado daqui). **Pendente:** infraestrutura.

## 2. Achados automáticos (catálogo do PostgreSQL)

<!-- db-docs:findings:begin -->
### A. Estrutura e RLS (consulta ao catálogo em 2026-10-14)

| Verificação | Resultado |
|---|---|
| Tabelas (banco) / modelos (schema) | 106 / 106 — coincidem |
| Tabelas sem RLS habilitada **e** forçada | 0 |
| Tabelas com RLS e **nenhuma** policy | 0 |
| Tabelas sem chave primária | 0 |
| Policies sem condição ou `true` | `request_logs.request_logs_isolation (ALL: WITH CHECK true)`, `support_kb_categories.support_kb_categories_read (SELECT: true)`, `system_logs.system_logs_isolation (ALL: WITH CHECK true)` |
| `companyId` anulável (linha sem dono de empresa) | `audit_logs`, `monitoring_alerts`, `monitoring_threshold_changes`, `monitoring_thresholds`, `permissions`, `refresh_tokens`, `request_logs`, `roles`, `system_logs`, `users` |
| Tabelas com `branchId` cuja policy **não** menciona filial | 9: `devices`, `installment_policies`, `monitoring_threshold_changes`, `monitoring_thresholds`, `partners`, `request_logs`, `system_logs`, `user_roles`, `users` |
| Tabelas com `companyId` sem índice que comece por `companyId` | 10: `employee_agreement_charges`, `employee_payroll_deductions`, `external_order_items`, `quote_events`, `supplier_return_events`, `supplier_return_items`, `support_ticket_attachments`, `support_ticket_events`, `support_ticket_messages`, `warranty_claims` |
| Papel de conexão desta consulta | `lnsystem` — superusuário: não; ignora RLS: não |

### B. Tabelas sem `companyId` (21) e como são isoladas

| Tabela | Domínio | Policies (condição resumida) |
|---|---|---|
| `access_revocations` | Plataforma, identidade e acesso | access_revocations_platform: `is_super_admin()` |
| `activations` | Plataforma, identidade e acesso | activations_isolation: `(is_super_admin() OR ("licenseId" IN ( SELECT licenses.id FROM licenses WHERE (licenses."companyId" = get_current_company_id()))))` |
| `appointment_events` | Clientes, veículos e pós-venda | appointment_events_isolation: `("appointmentId" IN ( SELECT appointments.id FROM appointments))` |
| `cash_movements` | Vendas, caixa e pagamento | cash_movements_isolation: `("cashRegisterId" IN ( SELECT cash_registers.id FROM cash_registers))` |
| `combo_items` | Catálogo e estoque | combo_items_isolation: `("comboId" IN ( SELECT products.id FROM products))` |
| `companies` | Plataforma, identidade e acesso | companies_isolation: `(is_super_admin() OR (id = get_current_company_id()))` |
| `devices` | Plataforma, identidade e acesso | devices_isolation: `(is_super_admin() OR ("licenseId" IN ( SELECT licenses.id FROM licenses WHERE (licenses."companyId" = get_current_company_id()))))` |
| `follow_up_events` | Clientes, veículos e pós-venda | follow_up_events_isolation: `("followUpId" IN ( SELECT follow_ups.id FROM follow_ups))` |
| `inventory_counts` | Catálogo e estoque | inventory_counts_isolation: `("inventoryId" IN ( SELECT inventories.id FROM inventories))` |
| `purchase_order_items` | Catálogo e estoque | purchase_order_items_isolation: `("purchaseOrderId" IN ( SELECT purchase_orders.id FROM purchase_orders))` |
| `quote_items` | Oficina | quote_items_isolation: `("quoteVersionId" IN ( SELECT quote_versions.id FROM quote_versions))` |
| `quote_versions` | Oficina | quote_versions_isolation: `("quoteId" IN ( SELECT quotes.id FROM quotes))` |
| `role_permissions` | Plataforma, identidade e acesso | role_permissions_isolation: `("roleId" IN ( SELECT roles.id FROM roles))` |
| `sale_items` | Vendas, caixa e pagamento | sale_items_isolation: `("saleId" IN ( SELECT sales.id FROM sales))` |
| `service_order_items` | Oficina | service_order_items_isolation: `("serviceOrderId" IN ( SELECT service_orders.id FROM service_orders))` |
| `service_order_status_history` | Oficina | service_order_status_history_isolation: `("serviceOrderId" IN ( SELECT service_orders.id FROM service_orders))` |
| `support_kb_articles` | Ajuda e Suporte | support_kb_articles_read: `((status = 'PUBLISHED'::text) OR is_super_admin())`; support_kb_articles_write: `is_super_admin()` |
| `support_kb_categories` | Ajuda e Suporte | support_kb_categories_read: `true`; support_kb_categories_write: `is_super_admin()` |
| `transfer_items` | Catálogo e estoque | transfer_items_isolation: `("transferId" IN ( SELECT transfers.id FROM transfers))` |
| `user_roles` | Plataforma, identidade e acesso | user_roles_isolation: `("userId" IN ( SELECT users.id FROM users))` |
| `vehicle_entry_checklist_items` | Oficina | vehicle_entry_checklist_items_isolation: `("checklistId" IN ( SELECT vehicle_entry_checklists.id FROM vehicle_entry_checklists))` |

### C. Isolamento por convenção (sem FK)

- **74** tabelas com `companyId` sem FK para `companies`; **64** com `branchId` sem FK para `branches`; **43** relações `…Id` entre entidades sem FK (inferidas; ver [MAPA_RELACIONAMENTOS](MAPA_RELACIONAMENTOS.md) §5).
- Efeito: o banco não rejeita uma referência órfã nem um registro apontando para outra empresa; a defesa é a RLS (`WITH CHECK`) e os serviços. Uma verificação de órfãos por consulta exigiria um papel que ignore a RLS (não disponível; a conexão da aplicação não ignora RLS) — **não executada**.

### D. FKs com `ON DELETE CASCADE` (41; apagar o pai apaga os filhos — as marcadas com ⚠ ficam em domínio financeiro, fiscal, de oficina ou de auditoria)

- `activations.deviceId` → `devices` (Plataforma, identidade e acesso)
- `activations.licenseId` → `licenses` (Plataforma, identidade e acesso)
- `activations.userId` → `users` (Plataforma, identidade e acesso)
- `appointment_events.appointmentId` → `appointments` (Clientes, veículos e pós-venda)
- ⚠ `audit_logs.companyId` → `companies` (Auditoria, observabilidade e operação)
- `branches.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `cash_movements.cashRegisterId` → `cash_registers` (Vendas, caixa e pagamento)
- `combo_items.comboId` → `products` (Catálogo e estoque)
- `combo_items.productId` → `products` (Catálogo e estoque)
- `device_sessions.deviceId` → `devices` (Plataforma, identidade e acesso)
- `device_sessions.userId` → `users` (Plataforma, identidade e acesso)
- `devices.licenseId` → `licenses` (Plataforma, identidade e acesso)
- `follow_up_events.followUpId` → `follow_ups` (Clientes, veículos e pós-venda)
- `installment_policies.companyId` → `companies` (Políticas e calendário)
- `inventory_counts.inventoryId` → `inventories` (Catálogo e estoque)
- `licenses.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `partners.companyId` → `companies` (Vendas, caixa e pagamento)
- ⚠ `payments.saleId` → `sales` (Vendas, caixa e pagamento)
- `permissions.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `privacy_requests.companyId` → `companies` (Auditoria, observabilidade e operação)
- `product_barcodes.companyId` → `companies` (Catálogo e estoque)
- `product_images.companyId` → `companies` (Catálogo e estoque)
- `product_images.productId` → `products` (Catálogo e estoque)
- `purchase_order_items.purchaseOrderId` → `purchase_orders` (Catálogo e estoque)
- ⚠ `quote_events.quoteId` → `quotes` (Oficina)
- ⚠ `quote_items.quoteVersionId` → `quote_versions` (Oficina)
- ⚠ `quote_versions.quoteId` → `quotes` (Oficina)
- `refresh_tokens.userId` → `users` (Plataforma, identidade e acesso)
- `role_permissions.permissionId` → `permissions` (Plataforma, identidade e acesso)
- `role_permissions.roleId` → `roles` (Plataforma, identidade e acesso)
- `roles.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `sale_items.saleId` → `sales` (Vendas, caixa e pagamento)
- ⚠ `service_order_items.serviceOrderId` → `service_orders` (Oficina)
- ⚠ `service_order_status_history.serviceOrderId` → `service_orders` (Oficina)
- `stock_movements.productId` → `products` (Catálogo e estoque)
- `transfer_items.transferId` → `transfers` (Catálogo e estoque)
- `user_roles.roleId` → `roles` (Plataforma, identidade e acesso)
- `user_roles.userId` → `users` (Plataforma, identidade e acesso)
- `users.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `vehicle_entry_checklist_items.checklistId` → `vehicle_entry_checklists` (Oficina)
- ⚠ `vehicle_entry_checklists.serviceOrderId` → `service_orders` (Oficina)

### D2. Órfãos nas relações sem FK — executada em 2026-10-14 no banco de desenvolvimento (dados sintéticos), somente contagens

181 relações conferidas (escopo de empresa e de filial sem FK + relações lógicas inferidas por nome); com órfãos: **10**.

| Relação | Linhas órfãs |
|---|---|
| `accounts_receivable.companyId → companies (empresa)` | 1 |
| `idempotency_keys.companyId → companies (empresa)` | 7 |
| `request_logs.companyId → companies (empresa)` | 12863 |
| `system_logs.companyId → companies (empresa)` | 90 |
| `accounts_receivable.branchId → branches (filial)` | 1 |
| `request_logs.branchId → branches (filial)` | 10500 |
| `system_logs.branchId → branches (filial)` | 68 |
| `accounts_receivable.customerId → customers (lógica inferida)` | 1 |
| `request_logs.userId → users (lógica inferida)` | 13528 |
| `system_logs.userId → users (lógica inferida)` | 420 |

Relações "lógica inferida" são deduzidas do nome da coluna: contagem > 0 pode ser erro da inferência (coluna que aponta para outra entidade) e não necessariamente dado órfão — conferir caso a caso.

### E. Imutabilidade de histórico e livros: o que a RLS permite

A imutabilidade no banco é feita por **RLS** (comando sem policy = negado; `FORCE RLS` vale também para o dono), não por trigger. Para cada tabela de histórico/livro, os comandos que têm policy:

| Tabela | SELECT | INSERT | UPDATE | DELETE | Leitura |
|---|---|---|---|---|---|
| `audit_logs` | policy | policy | negado | policy | sem UPDATE; DELETE só pelas condições da policy |
| `collection_attempts` | policy | policy | negado | policy | sem UPDATE; DELETE só pelas condições da policy |
| `discount_events` | policy | policy | negado | policy | sem UPDATE; DELETE só pelas condições da policy |
| `policy_changes` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `monitoring_threshold_changes` | policy | policy | negado | negado | imutável pelo banco |
| `service_order_status_history` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `revisions` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `stock_movements` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `cash_movements` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `sale_items` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |

Triggers não internos no banco (0): nenhum.

### F. Colunas sensíveis a revisar (nome sugere segredo, hash, documento ou dado pessoal) — 48

Só nomes e tipos; nenhum valor foi lido. Confirmar, para cada uma, se o conteúdo é cifrado/hash ou dado pessoal sujeito à LGPD.

| Tabela | Coluna | Tipo |
|---|---|---|
| `activations` | `ipAddress` | text |
| `agreement_companies` | `cnpj` | text |
| `agreement_companies` | `phone` | text |
| `agreement_companies` | `email` | text |
| `audit_logs` | `ipAddress` | text |
| `branches` | `document` | text |
| `branches` | `address` | text |
| `branches` | `phone` | text |
| `branches` | `email` | text |
| `channel_api_credentials` | `secretEncrypted` | text |
| `channel_api_credentials` | `secretHint` | text |
| `companies` | `document` | text |
| `companies` | `email` | text |
| `companies` | `phone` | text |
| `customers` | `document` | text |
| `customers` | `email` | text |
| `customers` | `phone` | text |
| `customers` | `birthDate` | timestamp(3) without time zone |
| `customers` | `address` | text |
| `device_sessions` | `ipAddress` | text |
| `devices` | `macAddress` | text |
| `devices` | `ipAddress` | text |
| `devices` | `secretHash` | text |
| `employee_agreements` | `cpf` | text |
| `fiscal_configs` | `certificatePassword` | text |
| `fiscal_configs` | `cscToken` | text |
| `fiscal_documents` | `documentType` | "FiscalDocumentType" |
| `idempotency_keys` | `requestHash` | text |
| `motorcycles` | `licensePlate` | text |
| `motorcycles` | `chassisNumber` | text |
| `refresh_tokens` | `token` | text |
| `refresh_tokens` | `ipAddress` | text |
| `sales_channels` | `credentialsEncrypted` | text |
| `sales_channels` | `credentialsHint` | text |
| `suppliers` | `document` | text |
| `suppliers` | `email` | text |
| `suppliers` | `phone` | text |
| `suppliers` | `address` | text |
| `suppliers` | `addressComplement` | text |
| `suppliers` | `addressNumber` | text |
| `support_tickets` | `requesterEmail` | text |
| `support_tickets` | `requesterPhone` | text |
| `users` | `email` | text |
| `users` | `phone` | text |
| `users` | `password` | text |
| `users` | `emailVerified` | boolean |
| `users` | `mfaSecret` | text |
| `users` | `mfaBackupCodes` | text[] |

<!-- db-docs:findings:end -->
