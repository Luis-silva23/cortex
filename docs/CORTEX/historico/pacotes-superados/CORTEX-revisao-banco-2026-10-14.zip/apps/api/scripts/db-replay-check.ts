/**
 * PROVA DE REPRODUTIBILIDADE DO BANCO: aplica TODAS as migrations versionadas num banco TEMPORÁRIO e VAZIO e compara o resultado com o
 * banco de desenvolvimento (colunas, índices, constraints, policies RLS, triggers) e com o schema Prisma. Se algo existir no dev e não vier
 * das migrations (alteração manual invisível), aparece como diferença.
 *
 *   npm run db:replay-check
 *
 * Segurança: cria `<banco-de-dev>_replay_tmp` (RECUSA se ele já existir — nunca apaga um banco que não criou), usa só esse banco e o remove
 * no fim. Não toca no banco de desenvolvimento nem no de teste (só leitura do catálogo). Não imprime URL/credencial.
 * Grava: docs/CORTEX/revisao-banco/replay-resultado.md e drift-dev.txt.
 */
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';
import { spawnSync } from 'child_process';
import { PrismaClient } from '@prisma/client';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const REPO = path.resolve(__dirname, '../../..');
const DB_PKG = path.join(REPO, 'packages/database');
const OUT = path.join(REPO, 'docs/CORTEX/revisao-banco');

function withDatabase(url: string, name: string): string {
  const u = new URL(url);
  u.pathname = `/${name}`;
  return u.toString();
}

async function signature(url: string): Promise<{ lines: string[]; version: string }> {
  const db = new PrismaClient({ datasources: { db: { url } } });
  const q = async <T = any>(sql: string): Promise<T[]> => (await db.$queryRawUnsafe(sql)) as T[];
  try {
    const out: string[] = [];
    for (const r of await q<{ l: string }>(
      `SELECT 'col ' || c.relname || '.' || a.attname || ' ' || format_type(a.atttypid, a.atttypmod) || ' notnull=' || a.attnotnull || ' def=' || coalesce(pg_get_expr(d.adbin, d.adrelid), '') AS l
         FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid LEFT JOIN pg_attrdef d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
        WHERE c.relnamespace = 'public'::regnamespace AND c.relkind = 'r' AND a.attnum > 0 AND NOT a.attisdropped AND c.relname <> '_prisma_migrations'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'idx ' || indexdef AS l FROM pg_indexes WHERE schemaname = 'public' AND tablename <> '_prisma_migrations'`)) out.push(r.l);
    for (const r of await q<{ l: string }>(
      `SELECT 'con ' || c.relname || ' ' || k.conname || ' ' || pg_get_constraintdef(k.oid) AS l FROM pg_constraint k JOIN pg_class c ON c.oid = k.conrelid
        WHERE c.relnamespace = 'public'::regnamespace AND c.relname <> '_prisma_migrations'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(
      `SELECT 'pol ' || tablename || ' ' || policyname || ' ' || cmd || ' ' || coalesce(qual, '') || ' | ' || coalesce(with_check, '') AS l FROM pg_policies WHERE schemaname = 'public'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(
      `SELECT 'rls ' || c.relname || ' enabled=' || c.relrowsecurity || ' forced=' || c.relforcerowsecurity AS l FROM pg_class c
        WHERE c.relnamespace = 'public'::regnamespace AND c.relkind = 'r' AND c.relname <> '_prisma_migrations'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'trg ' || pg_get_triggerdef(t.oid) AS l FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid WHERE NOT t.tgisinternal AND c.relnamespace = 'public'::regnamespace`)) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'fn ' || p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')' AS l FROM pg_proc p WHERE p.pronamespace = 'public'::regnamespace`)) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'seq ' || sequencename AS l FROM pg_sequences WHERE schemaname = 'public'`)) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'enum ' || t.typname || ' ' || string_agg(e.enumlabel, ',' ORDER BY e.enumsortorder) AS l FROM pg_type t JOIN pg_enum e ON e.enumtypid = t.oid GROUP BY t.typname`)) out.push(r.l);
    const version = ((await q<{ v: string }>(`SELECT version() AS v`))[0]?.v ?? '').split(',')[0];
    return { lines: out.sort(), version };
  } finally {
    await db.$disconnect();
  }
}

function prisma(args: string[], url: string) {
  return spawnSync('npx', ['prisma', ...args], { cwd: DB_PKG, env: { ...process.env, DATABASE_URL: url }, shell: true, encoding: 'utf8' });
}

async function main() {
  const devUrl = process.env.DATABASE_URL;
  if (!devUrl) throw new Error('DATABASE_URL ausente (apps/api/.env).');
  const devName = new URL(devUrl).pathname.replace(/^\//, '');
  const name = `${devName}_replay_tmp`;
  if (!/^[A-Za-z0-9_]+$/.test(name) || !name.endsWith('_replay_tmp') || name === devName) throw new Error(`nome de banco temporário inválido: ${name}`);
  const scratchUrl = withDatabase(devUrl, name);
  const admin = new PrismaClient({ datasources: { db: { url: withDatabase(devUrl, 'postgres') } } });

  const exists = (await admin.$queryRawUnsafe(`SELECT 1 AS x FROM pg_database WHERE datname = '${name}'`)) as unknown[];
  if (exists.length) { await admin.$disconnect(); throw new Error(`o banco temporário "${name}" já existe — recusado (não apago o que não criei).`); }
  await admin.$executeRawUnsafe(`CREATE DATABASE "${name}"`);

  const lines: string[] = [];
  let ok = true;
  let dropped = false;
  try {
    const deploy = prisma(['migrate', 'deploy'], scratchUrl);
    const found = (deploy.stdout.match(/(\d+) migrations? found/i) ?? [])[1];
    lines.push(`- \`prisma migrate deploy\` em banco vazio: ${deploy.status === 0 ? 'sucesso' : '**FALHOU**'} (${found ?? '?'} migrations encontradas em \`prisma/migrations\`).`);
    if (deploy.status !== 0) { ok = false; lines.push('```\n' + (deploy.stderr || deploy.stdout).split('\n').slice(-15).join('\n') + '\n```'); }

    if (deploy.status === 0) {
      // schema Prisma × banco reaplicado (o que o Prisma enxerga)
      const diffArgs = ['migrate', 'diff', '--from-schema-datasource', 'prisma/schema.prisma', '--to-schema-datamodel', 'prisma/schema.prisma', '--script'];
      const diffReplay = prisma(diffArgs, scratchUrl);
      const diffDev = prisma(diffArgs, devUrl);
      const norm = (s: string) => s.replace(/\r\n/g, '\n').trim();
      fs.mkdirSync(OUT, { recursive: true });
      fs.writeFileSync(path.join(OUT, 'drift-dev.txt'), norm(diffDev.stdout) + '\n', 'utf8');
      const same = norm(diffReplay.stdout) === norm(diffDev.stdout);
      lines.push(`- \`prisma migrate diff\` (banco → schema.prisma): banco reaplicado do zero e banco de desenvolvimento produzem ${same ? '**exatamente a mesma saída**' : '**saídas DIFERENTES**'} (${norm(diffReplay.stdout).split('\n').filter((l) => l.trim() && !l.startsWith('--')).length} instruções; são as diferenças intencionais que o Prisma não representa — ver BANCO_DE_DADOS §4).`);
      if (!same) ok = false;

      // catálogo completo: dev × reaplicado
      const a = await signature(devUrl);
      const b = await signature(scratchUrl);
      const setA = new Set(a.lines);
      const setB = new Set(b.lines);
      const onlyDev = a.lines.filter((l) => !setB.has(l));
      const onlyReplay = b.lines.filter((l) => !setA.has(l));
      lines.push(`- Catálogo completo (colunas, índices, constraints, policies, RLS, triggers, funções, sequências, enums): dev = ${a.lines.length} itens, reaplicado = ${b.lines.length} itens; **só no dev: ${onlyDev.length}**; **só no reaplicado: ${onlyReplay.length}**.`);
      if (onlyDev.length || onlyReplay.length) {
        ok = false;
        lines.push('```');
        for (const l of onlyDev.slice(0, 40)) lines.push(`só no dev: ${l.slice(0, 220)}`);
        for (const l of onlyReplay.slice(0, 40)) lines.push(`só no reaplicado: ${l.slice(0, 220)}`);
        lines.push('```');
      }
      lines.push(`- PostgreSQL: ${b.version}.`);

      // RLS no banco reaplicado
      const rls = spawnSync('npx', ['tsx', 'scripts/check-rls.ts'], { cwd: path.resolve(__dirname, '..'), env: { ...process.env, DATABASE_URL: scratchUrl }, shell: true, encoding: 'utf8' });
      const tail = (rls.stdout || '').trim().split('\n').slice(-3).join(' ').slice(0, 300);
      lines.push(`- \`db:check-rls\` no banco reaplicado: ${rls.status === 0 ? 'todas as invariantes OK' : '**FALHOU**'} — ${tail}`);
      if (rls.status !== 0) ok = false;
    }
  } finally {
    try {
      await admin.$executeRawUnsafe(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '${name}' AND pid <> pg_backend_pid()`);
      await admin.$executeRawUnsafe(`DROP DATABASE "${name}"`);
      dropped = true;
    } catch (e) {
      lines.push(`- **Banco temporário NÃO removido** (${e instanceof Error ? e.message.split('\n').pop() : 'erro'}): remover manualmente \`DROP DATABASE "${name}"\`.`);
    }
    await admin.$disconnect();
  }
  const date = new Date().toISOString().slice(0, 10);
  const md = [
    `**Execução de ${date}** (\`npm run db:replay-check\`) — banco temporário vazio, criado e removido pelo script; o banco de desenvolvimento só foi lido. Resultado: **${ok ? 'IDÊNTICO — nada no banco de desenvolvimento escapa das migrations' : 'COM DIFERENÇAS (ver abaixo)'}**.`,
    '',
    ...lines,
    `- Banco temporário removido: ${dropped ? 'sim' : '**não**'}.`,
    '',
  ].join('\n');
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, 'replay-resultado.md'), md, 'utf8');
  console.log(md);
  if (!ok) process.exitCode = 1;
}

main().catch((error) => {
  console.error(`[erro] ${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
