# CÓRTEX — Produção: configuração, deploy, rollback e operação

> **Estado (2026-10-06):** documento de **preparação**. Nada aqui foi executado em produção nem em staging: não há infraestrutura real, Git remoto, domínio, HTTPS, banco/Redis gerenciados, Docker nem CI remoto neste ambiente. O que é **verificado** (testes reais contra PostgreSQL e Redis locais) está marcado como tal; o que é **procedimento a executar** está marcado como "a executar". O veredito de prontidão está no [DIAGNOSTICO_PRODUCAO](DIAGNOSTICO_PRODUCAO.md).

## 1. Topologia alvo

```
 navegador / PDV / app ─HTTPS─► balanceador (TLS, WAF opcional) ─► API ×2+ (Node 20; HTTP + workers BullMQ + agendador)
                                                                      ├─► PostgreSQL 18 gerenciado (TLS, backup, PITR, réplica opcional)
                                                                      └─► Redis 7 gerenciado (senha, rede privada; só cache, sessão, limites, filas)
 Admin Web e Super Admin: Next.js `standalone` (imagens próprias) atrás do mesmo balanceador; **Balcão**: SPA estática em nginx (`apps/balcao/Dockerfile`, `balcao.<domínio>`), só fala com a API
```

- **PostgreSQL é a fonte da verdade** (dinheiro, estoque, vendas, pagamentos, auditoria). Redis guarda só o que pode ser reconstruído ou perdido sem dano ao negócio (cache, sessão/revogação, contadores de limite, filas, trava de apoio).
- A API é **sem estado** entre requisições: pode ter N instâncias. Cada instância também roda os workers e registra as rotinas recorrentes (idempotente: `jobId` fixo). `ENABLE_SCHEDULER=false` numa instância desliga só o registro das rotinas nela.
- **O que existe no repositório:** `docker-compose.yml` (desenvolvimento/homologação em um host, não é produção), **`docker-compose.staging.yml` + `deploy/Caddyfile`** (homologação **com HTTPS**: proxy com certificado automático à frente da API, porta 3001 fechada — §11), Dockerfiles da API, do Admin Web e do Super Admin, `.github/workflows/ci.yml`, `scripts/smoke-device-flow.js` (fumaça do fluxo de equipamento contra uma API real, §11). **Não validados com Docker nem no GitHub a partir daqui.**

## 2. Pré-requisitos (a executar)

| Item | Detalhe |
|---|---|
| Domínio e HTTPS | certificado válido no balanceador; HSTS no balanceador; API e web em origens HTTPS |
| PostgreSQL 18 | usuário **dono das tabelas** = usuário de runtime da API (senão as tabelas novas ficam sem permissão); `sslmode=require` na URL; role de backup dedicado com `BYPASSRLS` + `pg_read_all_data` |
| Redis 7 | senha, rede privada, persistência (AOF) opcional; nada de negócio depende dele |
| Segredos | cofre (secrets manager): `JWT_SECRET`, `JWT_REFRESH_SECRET` (diferentes), `DATA_ENCRYPTION_KEY` (guardada **junto do backup**, fora do repositório), senhas de banco/Redis, `BACKUP_DATABASE_URL` |
| Proxy | `TRUST_PROXY` com o número de saltos do balanceador |
| Monitoramento | coleta dos logs da API e alertas (§8) |
| Git remoto + CI | repositório remoto, proteção de branch exigindo os checks do `ci.yml` (hoje **não há remoto**) |

## 3. Configuração (variáveis de ambiente)

A API **valida a configuração na partida** (`apps/api/src/config/env.ts`). Em `NODE_ENV=production` um erro **impede a subida** (falha fechada, com todos os erros de uma vez e **sem imprimir valor de segredo**); fora de produção só avisa. Verificado por testes unitários.

| Variável | Produção | Observação |
|---|---|---|
| `NODE_ENV=production` | obrigatória | liga a validação estrita, esconde o Swagger |
| `DATABASE_URL` | obrigatória | recusada se tiver senha de exemplo (`lnsystem123`, `password`...); aviso sem `sslmode=require` |
| `REDIS_URL` ou `REDIS_HOST` (+ `REDIS_PASSWORD`, `REDIS_PORT`, `REDIS_DB`) | obrigatória | senha de exemplo recusada; aviso sem senha |
| `JWT_SECRET`, `JWT_REFRESH_SECRET` | obrigatórias | fortes (mínimo exigido em `shared/utils/token.ts`), **diferentes** entre si; `JWT_EXPIRES_IN` (padrão 15 min) é a janela de validade de uma sessão revogada com o Redis fora (§8) |
| `DATA_ENCRYPTION_KEY` | obrigatória | 32 bytes em base64; perder = perder MFA/certificado cifrados |
| `TRUST_PROXY` | **obrigatória** (a API não sobe sem ela, salvo `ENFORCE_HTTPS=false`) | número de saltos (`1`), `loopback`/`linklocal`/`uniquelocal` ou IP/CIDR; **`true` é recusado** (qualquer cliente forjaria o IP); sem ela o limite de tentativas e o bloqueio por IP veem todos como o IP do balanceador **e a API não reconhece a conexão HTTPS** (`X-Forwarded-Proto`) |
| `ENFORCE_HTTPS` | padrão **ligado** em produção | `false` desliga a exigência de HTTPS (só rede interna sem TLS; a API avisa). Ver §11 |
| `DEVICE_LEGACY_CUTOFF` | opcional | data ISO do corte do **legado de equipamento sem chave** (padrão `2026-12-31T23:59:59-03:00`); inválida = a API não sobe. Ver [DISPOSITIVOS §8](DISPOSITIVOS.md#8-configuração-obrigatória-e-legado) |
| `WEB_URL`, `SUPER_ADMIN_URL` | recomendadas | origens CORS (HTTPS); sem elas nenhuma origem de navegador é liberada |
| `API_PORT` | opcional | padrão 3001 |
| `REQUIRE_MFA_PRIVILEGED` | opcional | Super Admin sem MFA recebe 403 `MFA_ENROLLMENT_REQUIRED` no login; **padrão ligado em produção**, `true`/`false` força (§13) |
| `REQUIRE_MFA_COMPANY_ADMIN` | opcional | administrador da empresa sem MFA recebe 403 `MFA_ENROLLMENT_REQUIRED` + credencial de configuração (configura na tela); **padrão ligado em produção**; `false` em produção **impede a API de subir** (decisão 123) |
| `PASSWORD_HASH_ALGORITHM`, `ARGON2_MEMORY_KIB`, `ARGON2_TIME_COST`, `ARGON2_PARALLELISM`, `PASSWORD_LEGACY_BCRYPT` | opcionais | hash de senha: Argon2id por padrão (19456 KiB, 2, 1); `PASSWORD_HASH_ALGORITHM=bcrypt` reverte a gravação; `PASSWORD_LEGACY_BCRYPT=false` desliga o custo extra de bcrypt quando não restar hash `$2…` no banco. **Medir** o tempo no hardware real (alvo 50–100 ms) e dimensionar a memória pela concorrência de login (decisão 121) |
| `AUTH_REDIS_TIMEOUT_MS`, `AUTH_DB_TIMEOUT_MS` | opcionais | prazos da checagem de revogação de sessão (750 e 3000 ms); estourar = cai para o PostgreSQL / 503 (decisão 107) |
| `PRIVACY_FISCAL_RETENTION_YEARS` | opcional | anos de retenção do nome e CPF/CNPJ de cliente com documento fiscal autorizado ao anonimizar (padrão 5; **confirmar com o contador/jurídico**; decisão 120) |
| `ALLOW_SUPER_ADMIN_BOOTSTRAP` | **só durante** o procedimento | `true` libera `npm run admin:bootstrap` em produção; remover depois (§13). Nunca guarda senha |
| `COMMERCE_RATE_LIMIT_PER_MIN`, `COMMERCE_AUTH_FAILURES_PER_MIN` | opcionais | 300 e 20 por padrão; sem medição com tráfego real (decisão 94) |
| `CHANNEL_SANDBOX_PROVIDER` | **deixar vazio** | `true` registra o provedor SIMULADO em produção; a API avisa no log. Nenhum provedor real existe |
| `BACKUP_DATABASE_URL` | obrigatória se `ENABLE_AUTO_BACKUP` ≠ `false` | role de backup; sem BYPASSRLS o backup sai vazio e o job falha com mensagem clara |
| `ENABLE_SCHEDULER`, `ENABLE_AUTO_BACKUP` | opcionais | `false` desliga o registro das rotinas / o backup semanal da própria API (agora são honrados; antes eram ignorados) |
| `DEFAULT_TRIAL_DAYS`, `LOG_LEVEL`, `LOG_FILE_PATH`, e-mail/SMS/pagamento/fiscal | opcionais | integrações reais não existem (modo manual honesto) |

Os prazos do desligamento são constantes em `config/shutdown.ts` (25 s no total). `docker-compose.yml` não traz mais senhas: `POSTGRES_PASSWORD` e `REDIS_PASSWORD` são obrigatórias no `.env` (o compose recusa subir sem elas) e as portas do banco e do Redis só escutam em `127.0.0.1`. **Não validado com `docker compose config`** (sem Docker aqui).

## 4. Banco de dados

- **Migrações:** **50** (14 da revisão do banco de 2026-10-14/15 — lista e decisões 124–142 em [DECISIONS](DECISIONS.md); inventário em [BANCO_DE_DADOS](BANCO_DE_DADOS.md)), cada uma com problema, guarda e reversão no cabeçalho. **Atenção:** `20261014170000_refresh_tokens_hash_and_company` troca `refresh_tokens.token` por `tokenHash` — **reiniciar a API logo depois** (o código novo lê o hash; as sessões existentes continuam valendo) — e as migrations de FK têm **guarda de dados**: se abortarem (`FKs … abortadas: N linha(s)`), **não** forçar: corrigir o dado por procedimento documentado, `prisma migrate resolve --rolled-back <migration>` e reaplicar ([RELATORIO_MIGRATIONS §4](RELATORIO_MIGRATIONS.md)). Aplicar com `npx prisma migrate deploy --schema=packages/database/prisma/schema.prisma` **usando o usuário dono das tabelas**. Nunca `migrate dev`/`db push` em produção; nunca editar o banco à mão.
- **Depois de migrar:** `npm run db:check-rls` (em `apps/api`, com `DATABASE_URL` do alvo). Verificado no banco de desenvolvimento em 2026-10-06: **102 tabelas com RLS `FORCE`, 116 policies, "todas as invariantes de RLS OK"**; o mesmo verificador roda no `rls-invariants.integration` e no CI.
- **Dois papéis no banco (recomendado antes de produção — decisão 132):** o **dono** das tabelas só roda `migrate deploy` (`DATABASE_URL=<url-do-dono> npx prisma migrate deploy …`); a API em execução usa um papel **sem posse e sem DDL** (modelo e `GRANT`s em `deploy/db-runtime-role.sql`; repetir os `GRANT`s — ou `ALTER DEFAULT PRIVILEGES` — depois de cada migration que crie tabela). Prova antes de adotar: `CORTEX_DB_ADMIN_URL=<superusuário> npm run db:role-split-check -- --suites` (banco e papel temporários; resultado em `docs/CORTEX/revisao-banco/role-split-resultado.md`). Sem esse papel, quem executar SQL arbitrário com o papel da aplicação consegue `ALTER TABLE … DISABLE ROW LEVEL SECURITY`.
- **Fuso do banco = UTC:** a migration `20261015150000` executa `ALTER DATABASE <banco> SET timezone TO 'UTC'` (só novas sessões; reiniciar a API/pool). Se o papel que migra **não** for dono do banco ela só avisa — o DBA executa `ALTER DATABASE "<banco>" SET timezone TO 'UTC';` e confere com `SHOW timezone` numa sessão nova.
- **FK `NOT VALID` (legado):** uma FK pode ficar `NOT VALID` quando existe linha de **empresa que não existe mais** (sobra de teste/limpeza antiga; no dev, 1 recebível). A migration **não** apaga nem associa a linha a empresa alguma. Listar: `SELECT conrelid::regclass, conname FROM pg_constraint WHERE contype='f' AND NOT convalidated;`. Tratar cada linha com o dono do negócio (arquivar/excluir com autorização) e só então `ALTER TABLE … VALIDATE CONSTRAINT …` (como Super Admin: `set_config('app.user_type','SUPER_ADMIN',true)` na mesma transação).
- **Excluir filial/empresa/venda com histórico passa a ser recusado pelo banco** (`ON DELETE RESTRICT`): a API responde **409** (`BRANCH_IN_USE`, `RECORD_IN_USE`) — desativar em vez de excluir. Livros de estoque, caixa, política e histórico de OS são **append-only** (UPDATE negado; DELETE só de Super Admin com `app.audit_purge = on` na mesma transação — nunca por rotina de negócio).
- **Retenção** (já existente, por env): `AUDIT_LOG_RETENTION_DAYS` 90, `SYSTEM_LOG_RETENTION_DAYS` 90, `REQUEST_LOG_RETENTION_DAYS` 30, `TELEMETRY_RETENTION_DAYS` 30, `INCIDENT_RETENTION_DAYS` 365; `Idempotency-Key` expira em 24 h (e o job expurga as vencidas). **Prazos aguardam aprovação do dono/jurídico** (decisão 141).
- **Reversão de migração:** o caminho de produção é **restaurar o backup tirado antes da migração** (as migrações são só para frente). Os comentários `ROLLBACK` de cada arquivo servem de apoio e dizem quando a reversão manual é segura.
- **Pool de conexões:** não alterado (decisão 57 pendente: medir em Linux). Ao dimensionar, ajustar `connection_limit` e `pool_timeout` na `DATABASE_URL` por instância de API (instâncias × limite ≤ `max_connections` do banco).

## 5. Saúde e desligamento

| Sonda | Rota | Responde |
|---|---|---|
| Vida | `GET /api/health/live` | 200 se o processo responde; **não** consulta dependência (banco fora não reinicia a API); continua 200 enquanto drena |
| Prontidão | `GET /api/health/ready` | 200 com PostgreSQL, Redis e workers de pé; 503 `{status:'not ready', failing:[...]}` (só o nome da dependência, nunca a mensagem do erro); **503 `draining`** durante o desligamento |
| Detalhe | `GET /api/health` | estado de banco, Redis, fila e workers; 503 se algo estiver fora ou drenando |

Cada verificação tem prazo de 2 s (nunca pendura). Use `live` para reinício e `ready` para tirar a instância do balanceador.

**Desligamento ordenado** (`config/shutdown.ts`, SIGTERM/SIGINT): marca "drenando" (a prontidão vira 503) → para de aceitar conexões e fecha as ociosas → as requisições em andamento terminam (conexões que sobrarem são derrubadas depois de 10 s) → fecha workers (esperam o job ativo) e filas → Redis (cache e limitador) → PostgreSQL → `exit(0)`; prazo total 25 s, cada fechamento 8 s, falha em um não impede os seguintes (`exit(1)` e registro). Configure o orquestrador com **`terminationGracePeriod`/`stop_grace_period` ≥ 30 s** e, se possível, aguarde alguns segundos entre tirar da rotação e enviar o SIGTERM. **Verificado** com servidor HTTP real e fechamentos simulados; o **sinal real SIGTERM não existe no Windows**: o teste com o processo completo é **a executar em Linux/staging**.

## 6. Deploy (a executar)

1. **Congelar e conferir:** `git status` limpo, tag da versão, CI verde (lint, tipos, testes unitários e de integração, `db:check-rls`, build, links da documentação, build das imagens).
2. **Backup:** dump com o role de backup (§7) **e** guardar a `DATA_ENCRYPTION_KEY` correspondente. Confirmar que o arquivo restaura (`npm run backup:verify` em staging).
3. **Migrar:** `prisma migrate deploy` + `npm run db:check-rls` contra o banco alvo, **antes** de subir a nova versão. Se falhar: parar; restaurar o backup se a migração tiver deixado o banco inconsistente.
4. **Subir a API** em rolagem, uma instância por vez: a nova instância só entra na rotação quando `/api/health/ready` responde 200; a antiga sai (SIGTERM, drenagem de §5). Atenção: a partida de uma instância recria as rotinas recorrentes (remove e adiciona com os mesmos `jobId`): pode pular **um** disparo de uma rotina curta durante a rolagem (inofensivo: todas são idempotentes).
5. **Subir Admin Web e Super Admin** (`NEXT_PUBLIC_API_URL` é fixado **no build**: a URL pública HTTPS da API).
6. **Smoke test** (sem carga, sequencial): `/api/health` 200 OK; login de um usuário de teste do tenant de homologação; listar produtos; abrir e fechar um caixa de teste; criar uma venda de R$ 1,00 e cancelá-la com o autorizador; abrir o painel gerencial; `GET /api/health/ready` com o Redis derrubado (esperado 503) e religado; conferir no log da API a linha de partida sem avisos de configuração inesperados.
7. **Observar** 30 min: erros 5xx, `Slow Request`, filas (jobs falhos), `DEAD` na caixa de saída dos canais, conexões do banco.

**Rollback (a executar):** (a) código: reimplantar a imagem/tag anterior (a API anterior continua compatível com o banco **enquanto as migrações forem aditivas**, que é a regra do projeto); (b) banco: só restaurar backup se a migração tiver sido destrutiva ou corrompido dado — perde o que foi gravado depois do backup; por isso a migração é feita em janela e com o backup imediatamente antes; (c) configuração: a validação de partida recusa subir com configuração inválida, então a versão antiga continua atendendo.

## 7. Backup e recuperação

**O que existe:** `BackupService` (pg_dump com o role de backup), rota do Super Admin, job semanal da própria API (domingo 02:00; desligável por `ENABLE_AUTO_BACKUP=false`; **retenção de 30 dias** no diretório `BACKUP_DIR`, na **mesma máquina**), e `npm run backup:verify` (backup real + restauração num banco **temporário** + comparação de tabelas, RLS, policies, constraints, índices, donos e migrações + teste de segredos cifrados). **Reexecutado em 2026-10-06 (dev, depois da migração de equipamentos): 18/18 OK** — backup gerado pelo `BackupService` (1,8 MB), `pg_restore --exit-on-error` sem erro, **24 tabelas de negócio com as mesmas linhas** (inclui `devices`, `_prisma_migrations=31`), RLS **102 FORCE / 116 policies** idênticas, constraints/índices/funções/donos idênticos, **RLS funcional no restaurado** (sem contexto: 0 usuários; com a empresa, só a empresa), segredos de MFA `enc:v1` abrem com a `DATA_ENCRYPTION_KEY` e **não** abrem com chave errada, arquivo sem segredo em texto puro, banco temporário removido. **Isso valida a integridade e a recuperabilidade do backup no ambiente de desenvolvimento; não é a homologação de produção/staging.**

**O que NÃO existe (a configurar na infraestrutura):** backup contínuo (WAL/PITR), cópia fora do host, retenção e criptografia do arquivo, restauração testada periodicamente, alerta de backup que falhou (hoje só `logger.error('Auto backup failed')`).

**Procedimento de recuperação (DBA, nunca pela API; sempre num banco NOVO, nunca sobre o de produção em uso):** (1) anunciar a janela e **parar as instâncias da API** (ou tirá-las da rotação); (2) criar um banco vazio e restaurar nele o dump mais recente com `pg_restore --exit-on-error` (o `backup:verify` roda esta sequência num banco temporário; o dono das tabelas precisa ser o usuário de runtime, §4); (3) conferir **no banco restaurado**: `DATABASE_URL=<banco_novo> npm run db:check-rls` (todas as invariantes OK) e a contagem de `_prisma_migrations` igual à da versão em produção; (4) `prisma migrate deploy` se a versão do código for mais nova que o dump; (5) trocar a `DATABASE_URL` das instâncias para o banco restaurado **com a mesma `DATA_ENCRYPTION_KEY` do backup** (sem ela, MFA e certificados fiscais não abrem); (6) subir **uma** instância e esperar `/api/health/ready` 200, depois as demais; (7) fumaça: login de um usuário de teste e uma consulta de produto; (8) registrar RPO real (hora do dump × hora da falha) e RTO real. **Multiempresa/multifilial:** o dump é do banco inteiro (todas as empresas) e a RLS volta junto (provado no `backup:verify`); **não existe restauração de UMA empresa isolada** — se for preciso, restaura-se num banco paralelo e exporta-se só aquela empresa (procedimento manual de DBA). **Credenciais:** o role de backup (`BACKUP_DATABASE_URL`, BYPASSRLS + `pg_read_all_data`) e a `DATA_ENCRYPTION_KEY` ficam no cofre; o arquivo de backup nunca contém segredo em texto puro. **Não executado em staging/produção** (não há infraestrutura): a restauração periódica agendada, a cópia fora do host, o alerta de backup que falhou e o RPO/RTO medidos continuam **a executar**.

| Parâmetro | Recomendação técnica (a confirmar pelo dono — decisão 106) |
|---|---|
| RPO | ≤ 15 min (WAL/PITR do banco gerenciado); o job semanal da API **não** atende isso: tratá-lo como cópia extra, não como estratégia |
| RTO | ≤ 1 h (restaurar o último dump + reaplicar WAL; trocar `DATABASE_URL`; `ready` 200) |
| Retenção | diários por 30 dias, semanais por 12 semanas, mensais por 12 meses (ajustar à LGPD, decisão 93) |
| Teste de restauração | mensal em staging com `backup:verify`; a restauração de produção é procedimento de DBA, nunca pela API |
| Chave | `DATA_ENCRYPTION_KEY` guardada com o backup; sem ela MFA e certificados fiscais não voltam |

## 8. Observabilidade e operação

- **Rastreio:** toda requisição tem `X-Request-Id` (aceita o do cliente) e o log de acesso registra `requestId`, `companyId`, `branchId`, `userId`, método, caminho **sem query string**, status e duração; eventos de canal, caixa de entrada/saída e pedidos guardam a mesma correlação. Com isso se responde empresa, filial, canal, requisição, evento e etapa **sem dado sensível** (senha, token e segredo são cortados dos logs e da auditoria).
- **Alertas a configurar no coletor de logs** (padrões que a API já emite): `Slow Request Detected`; `Erro no Redis`; `Auto backup failed`; `OUTBOX_DEAD`, `PROVIDER_AUTH_FAILED`, `ORDER_NEEDS_REVIEW`, `INBOUND_EVENT_ORPHAN`, `PAYMENT_ON_CLOSED_ORDER` (eventos de canal); `UNHANDLED_REJECTION`/`UNCAUGHT_EXCEPTION`; jobs falhos das filas (`Job ... failed`).
- **Painel interno:** monitoramento e incidentes do Super Admin (`evaluate-health` a cada minuto).
- **Redis fora do ar** (comportamento projetado e testado; decisão 107): a API continua; cache degrada para "sem cache"; limites de tentativa contam em memória por instância (não somam entre instâncias); **a auditoria é gravada direto no PostgreSQL** quando a fila não confirma em 1,5 s (id idempotente); a **revogação de sessão NÃO falha aberta**: toda revogação é gravada também em `access_revocations` (PostgreSQL), com o Redis fora a checagem consulta o PostgreSQL e, se os dois estiverem fora, a API responde 503 `AUTH_UNAVAILABLE` (nunca aceita, nunca 401); ao voltar, o Redis recebe de volta as revogações vigentes antes de ser a fonte de novo. Refresh tokens ficam no PostgreSQL. **Ensaio com o Redis real derrubado: feito em desenvolvimento (2026-10-14)** — token revogado seguiu 401, válido 200, revogação durante a queda valeu, login funcionou, `/health` DEGRADED e, ao religar, as revogações foram ressincronizadas; **a executar em staging com 2+ instâncias** (teste `session-revocation-redis-outage` cobre a queda simulada).
- **Segurança operacional:** `TRUST_PROXY` correto; HTTPS no balanceador; CORS só para as origens do front; limites por usuário/IP/credencial; troca periódica dos segredos (rotação da `DATA_ENCRYPTION_KEY` **não** está implementada).

## 9. CI/CD

`ci.yml` (nunca executado de verdade: sem remoto): lint (API, Admin Web, Super Admin), documentação (links), tipos (todos os pacotes), testes unitários (API e Admin Web), integração com PostgreSQL e Redis reais (migrações aplicadas, **`db:check-rls`**, suíte completa), build de todos, build das três imagens Docker e `npm audit` (informativo: há vulnerabilidades transitivas a triar). Corrigido nesta fase: o passo de migrações não recebia `DATABASE_URL` (falharia), o Admin Web não tinha testes no pipeline, e o build do Admin Web **ignorava tipos e lint** (agora valida; ambos estavam limpos e um `next build` real passou).

## 10. O que só dá para validar em staging (não executado — restrição do ambiente corporativo)

Carga e concorrência em escala (pool de conexões, Postgres em Linux), failover do Redis e do PostgreSQL, SIGTERM real com tráfego, rolagem sem indisponibilidade, restauração de backup completa, throttling real atrás do balanceador (`TRUST_PROXY`), HTTPS/HSTS, e o build/execução das imagens Docker.

## 11. HTTPS, conexão dos aplicativos e autorização de equipamento (2026-10-06)

- **HTTPS obrigatório:** em produção a API responde **426 `HTTPS_REQUIRED`** a qualquer requisição que não chegou por HTTPS (`middleware/https.ts`; só `GET /api/health`, `/live`, `/ready` passam por HTTP, para o orquestrador). A API **não termina TLS**: o certificado, o redirecionamento 80→443 e o HSTS ficam no proxy/balanceador, que envia `X-Forwarded-Proto` e é declarado em `TRUST_PROXY`. Sem `TRUST_PROXY` a API **recusa subir** em produção (ou `ENFORCE_HTTPS=false` explícito). Provado por testes unitários (`https.test`, `env.test`); **o certificado real e o redirecionamento 80→443 são a executar em staging.**
- **Aplicativos:** o PDV em produção recusa endereço sem HTTPS; mobile e TV lançam erro na partida de um build de produção sem URL https; **nenhum aplicativo ignora erro de certificado**. O endereço é fixado na instalação (`VITE_API_URL`/`EXPO_PUBLIC_API_URL`) com o **domínio oficial — ainda não definido** (nada foi inventado). Detalhe e fluxo: [DISPOSITIVOS](DISPOSITIVOS.md).
- **Topologia de rede:** Internet → HTTPS → proxy → API → PostgreSQL/Redis/workers. **Nunca** Internet→PostgreSQL nem aplicativo→PostgreSQL; Redis nunca exposto; banco e Redis só aceitam a rede privada da API (**regra de firewall/security group: infraestrutura**; no `docker-compose.yml` já escutam só em `127.0.0.1`).
- **Equipamento autorizado:** máquina nova se registra (PENDENTE, sem empresa/filial), o administrador vincula licença e filial, e só então o login funciona; revogar derruba a sessão na hora. Migração **`20261006200000_device_enrollment`** (aditiva; reversão no cabeçalho): aplicar com `migrate deploy` + `db:check-rls` como as demais. **Para o go-live, configurar por empresa a política `devices.requiredUserTypes`** com os perfis de balcão (decisão 109).
- **Homologação com HTTPS** (a executar numa máquina Linux com Docker e um domínio real): `docker compose -f docker-compose.yml -f docker-compose.staging.yml up -d --build` com `STAGING_DOMAIN`, `TRUST_PROXY=1`, `WEB_URL`, `SUPER_ADMIN_URL` no `.env`; depois `node scripts/smoke-device-flow.js` (variáveis de ambiente descritas no cabeçalho do script; usa uma empresa de **teste**, cria e revoga **um** equipamento, sem carga). Conferir ainda: `curl -i http://<dominio>/api/auth/login` redireciona (proxy) e `curl -i` direto na API por HTTP devolve 426; `ss -tln` mostra 5432/6379 só em loopback/rede privada.
- **Aplicações atrás do mesmo proxy (staging):** `docker-compose.staging.yml` publica **só** o Caddy (80/443); `api.<domínio>`, `admin.<domínio>`, `super.<domínio>` e `balcao.<domínio>` precisam existir no DNS; `NEXT_PUBLIC_API_URL` dos painéis e `WEB_URL`/`SUPER_ADMIN_URL`/`BALCAO_URL` da API (CORS) e o `VITE_API_URL` do Balcão (sem `/api`; fixado no build, https obrigatório em produção). O container do Balcão recebe `API_ORIGIN` (origem https da API) para o `connect-src` da CSP do nginx (template em `/etc/nginx/templates`) são montados a partir de `STAGING_DOMAIN`. O `next build` de **produção** dos dois painéis **recusa** `NEXT_PUBLIC_API_URL` que não seja `https://` (exceto `http://localhost`). Corrigido junto: o `docker-compose.yml` passava a mesma URL sem `/api` aos dois painéis e o Admin Web (que espera o sufixo) chamava `/sales` em vez de `/api/sales`.
- **Provado localmente em 2026-10-06 (sem Docker, sem domínio):** cadeia **TLS real** com proxy HTTPS (certificado autoassinado, sockets reais) → `middleware/https.ts` com `TRUST_PROXY=1`: o cliente com a validação padrão **recusa** o certificado autoassinado; com o certificado confiado a API responde 200; **HTTP direto → 426**; sonda de saúde por HTTP → 200 ([DISPOSITIVOS §10](DISPOSITIVOS.md#10-o-que-foi-provado-e-o-que-falta)). **Não** é a prova de um certificado emitido para um domínio real nem do Caddy/Docker.

## 12. Checklist de go-live

| P | Item | Estado |
|---|---|---|
| P0 | Infraestrutura: domínio, HTTPS, PostgreSQL e Redis gerenciados, segredos no cofre, `TRUST_PROXY`, Git remoto + CI executado | **a executar** (nada disponível aqui) |
| P0 | Migrar (inclui `20261006200000_device_enrollment`) e conferir RLS no banco de produção; expurgar auditoria antiga com segredo (SECURITY, ação 3) | **a executar** |
| P0 | HTTPS real (certificado, 80→443, 426 em HTTP direto) e a **fumaça do fluxo de equipamento** em staging (§11); política `devices.requiredUserTypes` configurada por empresa (decisão 109) | **a executar** (código pronto e provado em teste; falta domínio/certificado) |
| P0 | Backup contínuo com RPO/RTO acordados e **uma restauração testada** | **a executar** |
| P0 | Criar o Super Admin de TI (§13) com MFA e **conferir** o login; publicar a Central de Ajuda | **a executar** (conta ainda não criada) |
| P1 | Teste de carga/concorrência e do desligamento real em staging | **a executar** |
| P1 | Alertas configurados (§8) | **a executar** |
| P1 | Decisões de dono ligadas a canais antes de ligar qualquer canal real (82–92, 95–105) | **abertas** |
| P2 | Rotação da `DATA_ENCRYPTION_KEY`; saldo materializado; pool (decisão 57) | evolução |

## 13. Primeiro Super Admin (bootstrap) e MFA

Procedimento **administrativo, no servidor da API** (acesso ao `.env` com `DATABASE_URL` e `DATA_ENCRYPTION_KEY`). **Não há conta padrão**: nenhuma senha fixa existe no código, nas migrations ou nos logs. **Estado em 2026-10-14: a conta ainda NÃO foi criada** — a simulação no banco de desenvolvimento mostrou o login `1` livre; criar é uma execução com `--apply` por quem tem a senha.

1. **Simular** (não grava nada): `cd apps/api && npm run admin:bootstrap -- bootstrap --email <e-mail> --name "<Nome Completo>" --numeric-id 1`. O plano diz se criaria, se já existe (no-op) ou por que recusa (`EMAIL_INVALID`, `NAME_INVALID`, `NUMERIC_ID_INVALID`, `NUMERIC_ID_TAKEN`, `EMAIL_BELONGS_TO_OTHER_ROLE`). Nunca promove conta existente de outro perfil e nunca troca o identificador por conta própria.
2. **Criar:** `BOOTSTRAP_SA_PASSWORD` definida **só no terminal desse comando** (ou digitada no prompt oculto), depois `… bootstrap … --apply`. Em produção, antes: `ALLOW_SUPER_ADMIN_BOOTSTRAP=true` (remover ao terminar). Senha: 12+ caracteres, 3 tipos, sem nome/e-mail, fora da lista de comuns. Gravada só como hash; o comando não a imprime; a auditoria registra o ato sem segredo.
3. **Conferir o resultado real** (não presumir): repetir o passo 1 (deve responder "já é Super Admin") e tentar o login pela tela do Super Admin.
4. **Ligar o MFA** (obrigatório em produção): `npm run admin:bootstrap -- enroll-mfa --numeric-id 1 --apply`; o segredo e os códigos de backup aparecem **uma vez** — guardar no cofre; confirmar com um código do autenticador. Sem MFA o Super Admin é barrado com 403 enquanto `REQUIRE_MFA_PRIVILEGED` estiver ligado.
5. **Recuperação:** perda do autenticador/senha = repetir `enroll-mfa`/redefinir a senha por procedimento de TI no servidor (auditado). Não existe "esqueci a senha" por e-mail para conta privilegiada.
6. **Central de Ajuda:** `npm run help:seed` (simulação) e `npm run help:seed -- --apply --publish` publicam os 13 artigos de [docs/ajuda](../ajuda/CENTRAL_DE_AJUDA.md) de forma idempotente (o autor é o primeiro Super Admin ativo — **depois** do passo 2).
7. **Migrações de 2026-10-14 (reversão no cabeçalho de cada uma):** as 5 aditivas `20261014100000_product_barcodes`, `20261014120000_access_revocations`, `20261014130000_mfa_replay_guard`, `20261014140000_privacy_requests`, `20261014150000_product_images` e as 4 da revisão do banco — `20261014155900_guard_product_children_same_company` (**guarda**: aborta se houver código de barras/imagem apontando para produto de outra empresa; roda antes da seguinte), `20261014160000_product_children_same_company` (FKs compostas), `20261014161000_product_images_company_product_unique` e `20261014162000_rls_logs_roles_tighten` (RLS de logs e de perfis/permissões globais). `migrate deploy` + `db:check-rls` + `db:replay-check` como as demais, **depois de um backup restaurável** ([BANCO_DE_DADOS §3](BANCO_DE_DADOS.md)). Se a guarda abortar: corrigir as linhas por procedimento documentado (nunca apagando histórico), `prisma migrate resolve --rolled-back 20261014155900_guard_product_children_same_company` e repetir o deploy (roteiro testado em banco temporário).
8. **Recuperar o acesso do Super Admin** (perdeu o autenticador): `npm run admin:bootstrap -- reset-mfa --numeric-id 1` (simulação) e `… --apply` (com `ALLOW_SUPER_ADMIN_BOOTSTRAP=true` em produção); depois `enroll-mfa --numeric-id 1 --apply`. Reinicia o fator, derruba as sessões e audita. A senha esquecida segue o passo 2 por outra conta de Super Admin ou por procedimento de TI no banco.

## 14. Operações manuais restantes (comandos exatos) — 2026-10-14

| Operação | Comando / procedimento | Estado |
|---|---|---|
| Criar o Super Admin de TI + MFA | §13 (passos 1–4), a senha só por prompt oculto | **a executar pelo responsável** (conta ainda não criada) |
| Migrar staging/produção | `prisma migrate deploy --schema=packages/database/prisma/schema.prisma` + `npm run db:check-rls` + `npm run db:inventory` (comparar com [BANCO_DE_DADOS](BANCO_DE_DADOS.md)) | **a executar** |
| Medir o Argon2id no hardware real | em `apps/api`: `npm run password:bench` (20 amostras sequenciais e um pico de 3 verificações simultâneas; sem banco, sem carga; imprime CPU, mediana/p95 e memória); ajustar `ARGON2_*` para 50–100 ms por verificação | **a executar no servidor-alvo/contêiner Linux** (na máquina de trabalho, 2026-10-14: verificação 26 ms com 19 MiB, t=2, +38 MB com 3 simultâneas; bcrypt custo 12: 257 ms — [SECURITY](SECURITY.md)) |
| Auditar o banco antes de migrar (deriva e RLS) | em `apps/api`: `npm run db:replay-check` (cria banco temporário, aplica as migrations do zero, compara com o dev, remove) · `npm run db:docs -- --write --orphans` (regera [BANCO_DE_DADOS](BANCO_DE_DADOS.md) Anexo A, [MAPA_RELACIONAMENTOS](MAPA_RELACIONAMENTOS.md), [RELATORIO_MIGRATIONS](RELATORIO_MIGRATIONS.md) e [REVISAO_BANCO_PENDENCIAS](REVISAO_BANCO_PENDENCIAS.md)) | **feito em dev em 2026-10-14**; repetir contra o **staging** depois de migrar (e incluir `db:replay-check` na CI: **não incluído**, não dá para exercitar a CI daqui) |
| Acompanhar o fim do bcrypt | contar `users.password LIKE '$2%'`; zerou → `PASSWORD_LEGACY_BCRYPT=false` | **a acompanhar** |
| Publicar a Central de Ajuda | `npm run help:seed` (simulação) e `npm run help:seed -- --apply --publish` (depois de criar o Super Admin) | **a executar** por ambiente |
| Ensaio do Redis real derrubado com 2+ instâncias | derrubar o Redis com login/logout em duas instâncias; esperado: revogado segue 401, válido 200, 503 só se o PostgreSQL também cair | **a executar em staging** (em dev: feito) |
| Instalador do PDV (Windows) | em `apps/pdv-desktop`: `npx electron-builder --win nsis --x64 --publish never` (usa `build.electronVersion`, fixado em 28.3.3). **Assinatura:** exige o certificado de assinatura (não existe aqui) e, no Windows, privilégio de criar links simbólicos (Modo de Desenvolvedor ou administrador) para o cache `winCodeSign`; **ícone do aplicativo não definido** (usa o padrão do Electron); **marca antiga no instalador:** `build.productName` = "LN System PDV" e `appId` = `com.lnsystem.pdv` (a janela já é "CÓRTEX PDV") — alinhar a CÓRTEX **antes da 1ª distribuição** (decisão do dono: trocar o `appId` muda a identidade da instalação e não atualiza instalações antigas); arquivo conferido em 2026-10-14: 82 MB, `NotSigned` | **gerado sem assinar** (dev); instalação real em máquina isolada **não executada** |
| Restauração em ambiente separado | `npm run backup:verify` prova a restauração em banco temporário da mesma instância (18/18, 2026-10-14); falta restaurar o dump em **outro host** e rodar `db:check-rls` lá | **a executar** |
| HTTPS, domínio e certificado | §11 (compose de staging + Caddy + `smoke-device-flow.js`) | **a executar** (sem domínio/Docker aqui) |

## 15. Staging — recursos externos que faltam e roteiro (2026-10-14)

Os arquivos existem e foram **revisados, não executados** (a máquina de trabalho não tem Docker nem domínio): [docker-compose.yml](../../docker-compose.yml), [docker-compose.staging.yml](../../docker-compose.staging.yml) (Caddy com TLS automático, portas 3000/3001/3002 fechadas, `ENFORCE_HTTPS`), [deploy/Caddyfile](../../deploy/Caddyfile), os Dockerfiles de `apps/*` e a CI ([.github/workflows/ci.yml](../../.github/workflows/ci.yml): lint, tipos, unitários, **integração com PostgreSQL 18 e Redis 7 reais**, `db:check-rls`, build, build das imagens, auditoria de dependências). Para a homologação real faltam:

| Recurso | O que é | Quem fornece |
|---|---|---|
| Servidor Linux | Docker Engine + Compose ≥ 2.24.4 (usa `!reset`), acesso por SSH, firewall liberando só 80/443 (nunca 5432/6379/3000–3002) | infraestrutura |
| Domínio e DNS | `STAGING_DOMAIN` real e registros `api.`, `admin.`, `super.` e `balcao.` apontando ao servidor (o Caddy emite e renova o certificado de cada nome; sem DNS não há certificado) | infraestrutura |
| Segredos (gerados na hora; nunca versionados, nunca copiados do desenvolvimento) | `.env` do servidor com `POSTGRES_PASSWORD`, `REDIS_PASSWORD` (só letras e números), `JWT_SECRET`, `JWT_REFRESH_SECRET`, `DATA_ENCRYPTION_KEY` (32 bytes em base64; perdê-la inutiliza MFA e segredos fiscais), `STAGING_DOMAIN`, `TRUST_PROXY=1`; `REQUIRE_MFA_*` ficam no padrão (ligados em produção); `ALLOW_SUPER_ADMIN_BOOTSTRAP=true` só durante a criação do Super Admin | responsável de TI |
| CI/CD de implantação | a CI atual valida, mas **não implanta** e não tem credenciais de registro de imagens nem de acesso ao servidor | infraestrutura |
| Backup fora do host | destino, retenção e **RPO/RTO** (decisão 106 — só o responsável define; nada foi inventado aqui) e a restauração testada em **outro** host | dono + infraestrutura |
| Observabilidade | `SENTRY_DSN`/APM opcionais (hoje não configurados); logs de contêiner e `/api/health` | infraestrutura |
| Certificado de assinatura e ícone do PDV | para assinar o instalador (§14) | dono |

Roteiro: (1) `docker compose -f docker-compose.yml -f docker-compose.staging.yml config` (valida o YAML e as variáveis obrigatórias) → (2) backup do banco → (3) `… up -d --build` (o serviço `migrate` roda `prisma migrate deploy` antes da API; a API só sobe com `service_completed_successfully`) → (4) `npm run db:check-rls` e `npm run db:replay-check` contra o banco do staging → (5) `scripts/smoke-device-flow.js` e a verificação 80→443 / 426 em HTTP direto (§11) → (6) criar o Super Admin (§13) → (7) `npm run password:bench` no contêiner. **Rollback:** imagens anteriores (`docker compose up -d` com a tag anterior) e, se uma migration precisar voltar, o SQL de reversão do cabeçalho dela — todas as migrations desta rodada são aditivas (apagar a tabela/coluna nova); restaurar o backup só se houver dado novo que dependa da estrutura. **Diagnóstico:** `docker compose ps`, `docker compose logs --tail=200 api`, `curl -fsS https://api.<domínio>/api/health/ready`, `/api/health` (detalha banco, Redis e workers), `npm run db:check-rls`; conexões do banco: `npx tsx scripts/pg-sample.ts <arquivo.log> 2000` em `apps/api` (amostrador somente leitura; §7 de [BANCO_DE_DADOS](BANCO_DE_DADOS.md)).
