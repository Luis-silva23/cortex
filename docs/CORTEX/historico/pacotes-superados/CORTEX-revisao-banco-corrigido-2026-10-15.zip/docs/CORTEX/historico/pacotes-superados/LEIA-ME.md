# Pacotes de revisão do banco SUPERADOS

Os dois ZIPs desta pasta são entregas das rodadas anteriores (2026-10-14) e descrevem o banco com **36/40 migrations** e com pendências que **já foram corrigidas**
(`refresh_tokens`, referência entre empresas, livros mutáveis, `ON DELETE CASCADE`). Não use como referência do estado atual.

O pacote vigente é `docs/CORTEX/CORTEX-revisao-banco-corrigido-2026-10-15.zip` (50 migrations), com o manifesto
`docs/CORTEX/SHA256SUMS-revisao-banco-corrigido-2026-10-15.txt`.
