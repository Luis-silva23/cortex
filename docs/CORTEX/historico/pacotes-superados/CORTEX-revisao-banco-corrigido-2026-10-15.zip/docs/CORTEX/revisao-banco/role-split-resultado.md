**Execução de 2026-10-15** (`npm run db:role-split-check`) — banco e papel temporários criados e removidos pelo script; dev/teste intocados. Resultado: **APROVADO**.

- ✅ migrations aplicadas pelo DONO no banco temporário vazio — 50 migrations found
- ✅ papel de execução temporário criado com os GRANTs do modelo (DML; sem posse, sem DDL)
- ✅ o papel de execução não é superusuário, não tem BYPASSRLS, CREATEDB nem CREATEROLE
- ✅ o papel de execução não é dono de nenhuma tabela — tabelas de que é dono: 0
- ✅ DDL negado: desligar a RLS de uma tabela (ALTER TABLE … DISABLE ROW LEVEL SECURITY)
- ✅ DDL negado: desligar o FORCE da RLS (NO FORCE ROW LEVEL SECURITY)
- ✅ DDL negado: apagar uma policy (DROP POLICY)
- ✅ DDL negado: alterar uma policy (ALTER POLICY … USING (true))
- ✅ DDL negado: apagar uma tabela (DROP TABLE)
- ✅ DDL negado: esvaziar uma tabela (TRUNCATE)
- ✅ DDL negado: criar uma tabela no schema public (CREATE TABLE)
- ✅ DDL negado: apagar uma restrição (ALTER TABLE … DROP CONSTRAINT)
- ✅ `_prisma_migrations` ilegível para o papel de execução
- ✅ RLS: a empresa dona enxerga a própria linha
- ✅ RLS: a empresa B NÃO enxerga a linha da A
- ✅ RLS: sem contexto de empresa a leitura volta vazia (0 linhas)
- ✅ RLS: a empresa B não consegue inserir linha com o companyId da A (WITH CHECK) — recusado
- ✅ livro de estoque: UPDATE e DELETE pela empresa afetam 0 linhas (append-only) — update 0, delete 0
- ✅ as funções auxiliares da RLS são executáveis pelo papel de execução
- ✅ suíte de integração real (COMPLETA) com a aplicação como papel SEM posse — Test Suites: 116 passed, 116 total; Tests: 1614 passed, 1614 total
- Banco e papel temporários removidos: sim.

> Limite honesto: o papel de execução ainda consegue `set_config('app.user_type', 'SUPER_ADMIN')` na própria sessão — o contexto da RLS é escolhido pela aplicação (decisão de arquitetura documentada). A separação de papéis impede o DDL (desligar RLS/apagar policy/tabela), não uma falha de lógica da própria aplicação.
