/**
 * PROVA DE REPRODUTIBILIDADE DO BANCO: aplica TODAS as migrations versionadas num banco TEMPORÁRIO e VAZIO e compara o resultado com o
 * banco de desenvolvimento (colunas, índices, constraints, policies RLS, triggers) e com o schema Prisma. Se algo existir no dev e não vier
 * das migrations (alteração manual invisível), aparece como diferença.
 *
 *   npm run db:replay-check
 *
 * Segurança: cria `<banco-de-dev>_replay_tmp` (RECUSA se ele já existir — nunca apaga um banco que não criou), usa só esse banco e o remove
 * no fim. Não toca no banco de desenvolvimento nem no de teste (só leitura do catálogo). Não imprime URL/credencial.
 * Grava: docs/CORTEX/revisao-banco/replay-resultado.md e drift-dev.txt.
 */
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import * as dotenv from 'dotenv';
import { spawnSync } from 'child_process';
import { PrismaClient } from '@prisma/client';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const REPO = path.resolve(__dirname, '../../..');
const DB_PKG = path.join(REPO, 'packages/database');
const OUT = path.join(REPO, 'docs/CORTEX/revisao-banco');

function withDatabase(url: string, name: string): string {
  const u = new URL(url);
  u.pathname = `/${name}`;
  return u.toString();
}

async function signature(url: string): Promise<{ lines: string[]; version: string }> {
  const db = new PrismaClient({ datasources: { db: { url } } });
  const q = async <T = any>(sql: string): Promise<T[]> => (await db.$queryRawUnsafe(sql)) as T[];
  try {
    const out: string[] = [];
    for (const r of await q<{ l: string }>(
      `SELECT 'col ' || c.relname || '.' || a.attname || ' ' || format_type(a.atttypid, a.atttypmod) || ' notnull=' || a.attnotnull || ' def=' || coalesce(pg_get_expr(d.adbin, d.adrelid), '') AS l
         FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid LEFT JOIN pg_attrdef d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
        WHERE c.relnamespace = 'public'::regnamespace AND c.relkind = 'r' AND a.attnum > 0 AND NOT a.attisdropped AND c.relname <> '_prisma_migrations'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'idx ' || indexdef AS l FROM pg_indexes WHERE schemaname = 'public' AND tablename <> '_prisma_migrations'`)) out.push(r.l);
    for (const r of await q<{ l: string }>(
      `SELECT 'con ' || c.relname || ' ' || k.conname || ' ' || pg_get_constraintdef(k.oid) AS l FROM pg_constraint k JOIN pg_class c ON c.oid = k.conrelid
        WHERE c.relnamespace = 'public'::regnamespace AND c.relname <> '_prisma_migrations'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(
      `SELECT 'pol ' || tablename || ' ' || policyname || ' ' || cmd || ' ' || coalesce(qual, '') || ' | ' || coalesce(with_check, '') AS l FROM pg_policies WHERE schemaname = 'public'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(
      `SELECT 'rls ' || c.relname || ' enabled=' || c.relrowsecurity || ' forced=' || c.relforcerowsecurity AS l FROM pg_class c
        WHERE c.relnamespace = 'public'::regnamespace AND c.relkind = 'r' AND c.relname <> '_prisma_migrations'`
    )) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'trg ' || pg_get_triggerdef(t.oid) AS l FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid WHERE NOT t.tgisinternal AND c.relnamespace = 'public'::regnamespace`)) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'fn ' || p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')' AS l FROM pg_proc p WHERE p.pronamespace = 'public'::regnamespace`)) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'seq ' || sequencename AS l FROM pg_sequences WHERE schemaname = 'public'`)) out.push(r.l);
    for (const r of await q<{ l: string }>(`SELECT 'enum ' || t.typname || ' ' || string_agg(e.enumlabel, ',' ORDER BY e.enumsortorder) AS l FROM pg_type t JOIN pg_enum e ON e.enumtypid = t.oid GROUP BY t.typname`)) out.push(r.l);
    const version = ((await q<{ v: string }>(`SELECT version() AS v`))[0]?.v ?? '').split(',')[0];
    return { lines: out.sort(), version };
  } finally {
    await db.$disconnect();
  }
}

function prisma(args: string[], url: string) {
  return spawnSync('npx', ['prisma', ...args], { cwd: DB_PKG, env: { ...process.env, DATABASE_URL: url }, shell: true, encoding: 'utf8' });
}

/**
 * CENÁRIO COM DADOS (segundo banco temporário): aplica as migrations ATÉ a anterior à FK composta, grava uma linha SINTÉTICA que a viola
 * (código de barras da empresa A apontando para produto da B) e roda o `migrate deploy` completo. Esperado: a migration
 * `20261014155900_guard_product_children_same_company` FALHA, NADA das FKs compostas fica aplicado (atomicidade) e, depois de corrigir a linha e
 * `migrate resolve --rolled-back`, o deploy conclui. Prova que a migration não "funciona só em banco vazio" nem corrompe dado inconsistente.
 */
// A guarda roda ANTES das FKs compostas (nome menor): em banco com dado cruzado é ELA que falha, e a das FKs nem começa.
const FIRST_COMPOSITE_MIGRATION = '20261014155900_guard_product_children_same_company';

async function dataScenario(devUrl: string, admin: PrismaClient): Promise<{ ok: boolean; lines: string[] }> {
  const lines: string[] = [];
  const devName = new URL(devUrl).pathname.replace(/^\//, '');
  const name = `${devName}_replay2_tmp`;
  if (!/^[A-Za-z0-9_]+$/.test(name)) throw new Error(`nome inválido: ${name}`);
  const exists = (await admin.$queryRawUnsafe(`SELECT 1 AS x FROM pg_database WHERE datname = '${name}'`)) as unknown[];
  if (exists.length) throw new Error(`o banco temporário "${name}" já existe — recusado.`);
  await admin.$executeRawUnsafe(`CREATE DATABASE "${name}"`);
  const url = withDatabase(devUrl, name);
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cortex-mig-'));
  let ok = true;
  const client = new PrismaClient({ datasources: { db: { url } } });
  try {
    // 1. schema + migrations só até a anterior
    fs.mkdirSync(path.join(tmp, 'prisma', 'migrations'), { recursive: true });
    fs.copyFileSync(path.join(DB_PKG, 'prisma', 'schema.prisma'), path.join(tmp, 'prisma', 'schema.prisma'));
    fs.copyFileSync(path.join(DB_PKG, 'prisma', 'migrations', 'migration_lock.toml'), path.join(tmp, 'prisma', 'migrations', 'migration_lock.toml'));
    const all = fs.readdirSync(path.join(DB_PKG, 'prisma', 'migrations')).filter((d) => fs.statSync(path.join(DB_PKG, 'prisma', 'migrations', d)).isDirectory()).sort();
    const before = all.filter((d) => d < FIRST_COMPOSITE_MIGRATION);
    for (const d of before) fs.cpSync(path.join(DB_PKG, 'prisma', 'migrations', d), path.join(tmp, 'prisma', 'migrations', d), { recursive: true });
    // a pasta temporária fica FORA do repositório: `npx prisma` ali baixaria outra versão do CLI — usa o CLI instalado no monorepo
    const prismaCli = path.join(REPO, 'node_modules', 'prisma', 'build', 'index.js');
    const partial = spawnSync(process.execPath, [prismaCli, 'migrate', 'deploy'], { cwd: tmp, env: { ...process.env, DATABASE_URL: url }, encoding: 'utf8' });
    lines.push(`- Banco temporário 2: ${before.length} migrations aplicadas (até a anterior à FK composta): ${partial.status === 0 ? 'sucesso' : '**FALHOU**'}.`);
    if (partial.status !== 0) {
      lines.push('```\n' + `${partial.stdout}\n${partial.stderr}`.replace(/postgres(ql)?:\/\/\S+/g, 'postgresql://***').split('\n').filter((l) => l.trim()).slice(-12).join('\n') + '\n```');
      return { ok: false, lines };
    }

    // 2. dados sintéticos: duas empresas, um produto em cada, e UM código de barras da A apontando para o produto da B (a FK antiga aceita)
    const sa = (ops: any[]) =>
      client.$transaction([
        client.$executeRaw`SELECT set_config('app.current_company_id', '', true)`,
        client.$executeRaw`SELECT set_config('app.user_type', 'SUPER_ADMIN', true)`,
        client.$executeRaw`SELECT set_config('app.current_branch_id', '', true)`,
        ...ops,
      ]);
    const stamp = Date.now();
    const mkCompany = async (n: string, doc: string) => (await sa([client.company.create({ data: { name: `Teste migracao ${n}`, document: doc, email: `mig-${n}-${stamp}@teste.local`, isActive: true } })]))[3] as { id: string };
    const A = await mkCompany('A', String(stamp).slice(-8).padStart(14, '1'));
    const B = await mkCompany('B', String(stamp + 1).slice(-8).padStart(14, '2'));
    const mkProduct = async (c: string, sku: string) => (await sa([client.product.create({ data: { companyId: c, sku, name: sku, costPrice: 1, salePrice: 2, isActive: true } })]))[3] as { id: string };
    const pB = await mkProduct(B.id, `MIG-B-${stamp}`);
    await mkProduct(A.id, `MIG-A-${stamp}`);
    const bad = (await sa([client.productBarcode.create({ data: { companyId: A.id, productId: pB.id, code: `MIG-${stamp}` } })]))[3] as { id: string };
    // confere que a linha cruzada EXISTE de verdade antes do deploy (leitura como Super Admin, na mesma transação)
    const crossBefore = (await sa([client.$queryRawUnsafe(`SELECT count(*)::int AS n FROM product_barcodes b JOIN products p ON p.id = b."productId" WHERE p."companyId" <> b."companyId"`)]))[3] as Array<{ n: number }>;
    lines.push(`- Dados sintéticos: 2 empresas, 1 produto em cada e **1 código de barras da empresa A apontando para o produto da empresa B** (aceito pela FK antiga); linhas cruzadas confirmadas antes do deploy: ${crossBefore[0].n}.`);
    if (crossBefore[0].n !== 1) ok = false;

    // 3. deploy completo: a migration das FKs compostas tem que FALHAR
    const full = spawnSync('npx', ['prisma', 'migrate', 'deploy'], { cwd: DB_PKG, env: { ...process.env, DATABASE_URL: url }, shell: true, encoding: 'utf8' });
    const failedAsExpected = full.status !== 0 && /product_children_same_company/.test(`${full.stdout}${full.stderr}`);
    lines.push(`- \`migrate deploy\` completo com a linha inconsistente: ${failedAsExpected ? '**falhou como esperado** (a migration `' + FIRST_COMPOSITE_MIGRATION + '` recusou o dado cruzado)' : '**NÃO falhou — inesperado**'}.`);
    if (!failedAsExpected) ok = false;

    // 4. atomicidade: nada da migration ficou aplicado
    const state = (await client.$queryRawUnsafe(`
      SELECT (SELECT count(*)::int FROM pg_indexes WHERE indexname = 'products_companyId_id_key') AS idx,
             (SELECT count(*)::int FROM pg_constraint WHERE conname = 'product_barcodes_companyId_productId_fkey') AS composite,
             (SELECT count(*)::int FROM pg_constraint WHERE conname = 'product_barcodes_productId_fkey') AS legacy`)) as Array<{ idx: number; composite: number; legacy: number }>;
    const atomic = state[0].idx === 0 && state[0].composite === 0 && state[0].legacy === 1;
    lines.push(`- Atomicidade: depois da falha, índice composto ${state[0].idx}, FK composta ${state[0].composite}, FK antiga ${state[0].legacy} → ${atomic ? '**nada ficou aplicado pela metade**' : '**ESTADO PARCIAL — investigar**'}.`);
    if (!atomic) ok = false;

    // 5. recuperação documentada: corrigir a linha (aqui: remover a linha sintética), marcar a migration como revertida e reaplicar
    await sa([client.productBarcode.deleteMany({ where: { id: bad.id, companyId: A.id } })]);
    const resolve = spawnSync('npx', ['prisma', 'migrate', 'resolve', '--rolled-back', FIRST_COMPOSITE_MIGRATION], { cwd: DB_PKG, env: { ...process.env, DATABASE_URL: url }, shell: true, encoding: 'utf8' });
    const redeploy = spawnSync('npx', ['prisma', 'migrate', 'deploy'], { cwd: DB_PKG, env: { ...process.env, DATABASE_URL: url }, shell: true, encoding: 'utf8' });
    const final = (await client.$queryRawUnsafe(`SELECT (SELECT count(*)::int FROM pg_constraint WHERE conname IN ('product_barcodes_companyId_productId_fkey','product_images_companyId_productId_fkey')) AS composite`)) as Array<{ composite: number }>;
    const recovered = resolve.status === 0 && redeploy.status === 0 && final[0].composite === 2;
    lines.push(`- Recuperação (corrigir a linha → \`migrate resolve --rolled-back ${FIRST_COMPOSITE_MIGRATION}\` → \`migrate deploy\`): ${recovered ? '**concluiu**, as 2 FKs compostas existem' : '**FALHOU**'}.`);
    if (!recovered) ok = false;
  } finally {
    await client.$disconnect();
    try {
      await admin.$executeRawUnsafe(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '${name}' AND pid <> pg_backend_pid()`);
      await admin.$executeRawUnsafe(`DROP DATABASE "${name}"`);
      lines.push('- Banco temporário 2 removido: sim.');
    } catch (e) {
      lines.push(`- **Banco temporário 2 NÃO removido** (${e instanceof Error ? e.message.split('\n').pop() : 'erro'}): \`DROP DATABASE "${name}"\` manual.`);
      ok = false;
    }
    // só a pasta temporária criada por este script; no Windows o motor do Prisma pode segurar um arquivo por instantes (EBUSY) — não derruba o resultado
    try {
      fs.rmSync(tmp, { recursive: true, force: true, maxRetries: 5, retryDelay: 400 });
    } catch {
      lines.push(`- Pasta temporária \`${tmp}\` não pôde ser removida agora (arquivo em uso); pode ser apagada à mão (só contém cópia do schema e das migrations).`);
    }
  }
  return { ok, lines };
}

async function main() {
  const devUrl = process.env.DATABASE_URL;
  if (!devUrl) throw new Error('DATABASE_URL ausente (apps/api/.env).');
  const devName = new URL(devUrl).pathname.replace(/^\//, '');
  const name = `${devName}_replay_tmp`;
  if (!/^[A-Za-z0-9_]+$/.test(name) || !name.endsWith('_replay_tmp') || name === devName) throw new Error(`nome de banco temporário inválido: ${name}`);
  const scratchUrl = withDatabase(devUrl, name);
  const admin = new PrismaClient({ datasources: { db: { url: withDatabase(devUrl, 'postgres') } } });

  const exists = (await admin.$queryRawUnsafe(`SELECT 1 AS x FROM pg_database WHERE datname = '${name}'`)) as unknown[];
  if (exists.length) { await admin.$disconnect(); throw new Error(`o banco temporário "${name}" já existe — recusado (não apago o que não criei).`); }
  await admin.$executeRawUnsafe(`CREATE DATABASE "${name}"`);

  const lines: string[] = [];
  let ok = true;
  let dropped = false;
  try {
    const deploy = prisma(['migrate', 'deploy'], scratchUrl);
    const found = (deploy.stdout.match(/(\d+) migrations? found/i) ?? [])[1];
    lines.push(`- \`prisma migrate deploy\` em banco vazio: ${deploy.status === 0 ? 'sucesso' : '**FALHOU**'} (${found ?? '?'} migrations encontradas em \`prisma/migrations\`).`);
    if (deploy.status !== 0) { ok = false; lines.push('```\n' + (deploy.stderr || deploy.stdout).split('\n').slice(-15).join('\n') + '\n```'); }

    if (deploy.status === 0) {
      // schema Prisma × banco reaplicado (o que o Prisma enxerga)
      const diffArgs = ['migrate', 'diff', '--from-schema-datasource', 'prisma/schema.prisma', '--to-schema-datamodel', 'prisma/schema.prisma', '--script'];
      const diffReplay = prisma(diffArgs, scratchUrl);
      const diffDev = prisma(diffArgs, devUrl);
      const norm = (s: string) => s.replace(/\r\n/g, '\n').trim();
      fs.mkdirSync(OUT, { recursive: true });
      fs.writeFileSync(path.join(OUT, 'drift-dev.txt'), norm(diffDev.stdout) + '\n', 'utf8');
      const same = norm(diffReplay.stdout) === norm(diffDev.stdout);
      const stmts = (s: string) => norm(s).split('\n').filter((l) => l.trim() && !l.startsWith('--')).length;
      const empty = stmts(diffReplay.stdout) === 0 && stmts(diffDev.stdout) === 0;
      lines.push(
        `- \`prisma migrate diff\` (banco → schema.prisma): banco reaplicado do zero e banco de desenvolvimento produzem ${same ? '**exatamente a mesma saída**' : '**saídas DIFERENTES**'}` +
          (empty ? ' — **vazia (0 instruções): o `schema.prisma` descreve exatamente o banco**.' : ` (${stmts(diffReplay.stdout)} instruções que o schema não representa — ver drift-dev.txt).`)
      );
      if (!same) ok = false;

      // catálogo completo: dev × reaplicado
      const a = await signature(devUrl);
      const b = await signature(scratchUrl);
      const setA = new Set(a.lines);
      const setB = new Set(b.lines);
      const onlyDev = a.lines.filter((l) => !setB.has(l));
      const onlyReplay = b.lines.filter((l) => !setA.has(l));
      lines.push(`- Catálogo completo (colunas, índices, constraints, policies, RLS, triggers, funções, sequências, enums): dev = ${a.lines.length} itens, reaplicado = ${b.lines.length} itens; **só no dev: ${onlyDev.length}**; **só no reaplicado: ${onlyReplay.length}**.`);
      if (onlyDev.length || onlyReplay.length) {
        ok = false;
        lines.push('```');
        for (const l of onlyDev.slice(0, 40)) lines.push(`só no dev: ${l.slice(0, 220)}`);
        for (const l of onlyReplay.slice(0, 40)) lines.push(`só no reaplicado: ${l.slice(0, 220)}`);
        lines.push('```');
      }
      lines.push(`- PostgreSQL: ${b.version}.`);

      // RLS no banco reaplicado
      const rls = spawnSync('npx', ['tsx', 'scripts/check-rls.ts'], { cwd: path.resolve(__dirname, '..'), env: { ...process.env, DATABASE_URL: scratchUrl }, shell: true, encoding: 'utf8' });
      const tail = (rls.stdout || '').trim().split('\n').slice(-3).join(' ').slice(0, 300);
      lines.push(`- \`db:check-rls\` no banco reaplicado: ${rls.status === 0 ? 'todas as invariantes OK' : '**FALHOU**'} — ${tail}`);
      if (rls.status !== 0) ok = false;
    }
  } finally {
    try {
      await admin.$executeRawUnsafe(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '${name}' AND pid <> pg_backend_pid()`);
      await admin.$executeRawUnsafe(`DROP DATABASE "${name}"`);
      dropped = true;
    } catch (e) {
      lines.push(`- **Banco temporário NÃO removido** (${e instanceof Error ? e.message.split('\n').pop() : 'erro'}): remover manualmente \`DROP DATABASE "${name}"\`.`);
    }
  }
  let scenario: { ok: boolean; lines: string[] } = { ok: false, lines: ['- Cenário com dados: não executado.'] };
  try {
    scenario = await dataScenario(devUrl, admin);
  } catch (e) {
    scenario = { ok: false, lines: [`- Cenário com dados **FALHOU**: ${e instanceof Error ? e.message.split('\n')[0] : 'erro'}`] };
  }
  if (!scenario.ok) ok = false;
  await admin.$disconnect();
  const date = new Date().toISOString().slice(0, 10);
  const md = [
    `**Execução de ${date}** (\`npm run db:replay-check\`) — banco temporário vazio, criado e removido pelo script; o banco de desenvolvimento só foi lido. Resultado: **${ok ? 'IDÊNTICO — nada no banco de desenvolvimento escapa das migrations' : 'COM DIFERENÇAS (ver abaixo)'}**.`,
    '',
    ...lines,
    `- Banco temporário removido: ${dropped ? 'sim' : '**não**'}.`,
    '',
    '**Cenário com dados inconsistentes (migration das FKs compostas):**',
    '',
    ...scenario.lines,
    '',
  ].join('\n');
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, 'replay-resultado.md'), md, 'utf8');
  console.log(md);
  if (!ok) process.exitCode = 1;
}

main().catch((error) => {
  console.error(`[erro] ${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
