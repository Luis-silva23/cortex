# Revisão do banco de dados — achados, correções, testes e pendências

> Escrito em 2026-10-14 (revisão técnica independente, 2ª rodada). Fonte: catálogo do PostgreSQL de **desenvolvimento** (18.6, dados sintéticos), `schema.prisma`, as **40 migrations**, o código da API e experimentos **revertidos** no banco de teste. Nada foi lido de cliente real; nada foi apagado ou reescrito em banco compartilhado; staging e produção **não existem/não foram tocados**. O bloco "Achados automáticos" (§5) é regerado por `cd apps/api && npm run db:docs -- --write --orphans`; o restante é análise escrita.
>
> **Classes:** **Confirmado** (evidência direta no schema, SQL, catálogo ou teste que falhava) · **Provável** · **Não confirmado** · **Falso positivo** (a estrutura atual ou uma proteção comprovada elimina o risco). **Estados:** **CORRIGIDO** (migration/schema + teste) · **PENDENTE-DECISÃO** (mexe em autenticação, RLS ou integridade e precisa de aprovação) · **PENDENTE-INFRA**.
> Documentos irmãos: [BANCO_DE_DADOS](BANCO_DE_DADOS.md) (por tabela) · [MAPA_RELACIONAMENTOS](MAPA_RELACIONAMENTOS.md) · [RELATORIO_MIGRATIONS](RELATORIO_MIGRATIONS.md) · [DECISIONS](DECISIONS.md) (decisões 124 a 135) · pacote com schema e migrations em [revisao-banco/](revisao-banco/LEIA-ME.md).

## 0. Resumo executivo

| Pergunta | Resposta | Evidência |
|---|---|---|
| Os três achados iniciais procedem? | **A (numeração dos chamados) e B (índice da busca): o SQL apresentado nunca foi uma migration — é a saída do `prisma migrate diff` banco → schema.prisma (arquivo `drift-dev.txt` da rodada anterior).** O banco real está certo; o risco era do `schema.prisma` não descrever esses objetos: um `migrate dev`/`db push` teria gerado exatamente aquele SQL. **Corrigido só no schema** (nenhuma mudança de banco) e o diff agora é **vazio**. **C (referência cruzada entre empresas) é real e foi reproduzido** (teste que falhava) — **corrigido** com FK composta. | §2 |
| Quantas tabelas / migrations? | **106** tabelas = 106 modelos · **40** migrations (36 anteriores + 4 desta revisão), todas aplicadas em dev e teste, checksums conferem | `db:docs`, `_prisma_migrations` |
| As migrations reproduzem o banco? | **Sim**: aplicadas do zero num banco vazio dão exatamente o catálogo do dev (3 339 itens iguais) e `prisma migrate diff` **vazio** | `npm run db:replay-check` |
| Migration segura com dado existente? | **Sim, com guarda.** Provado em banco temporário **com dado cruzado**: a migration-guarda falha, nada fica pela metade, e o roteiro de recuperação conclui | `db:replay-check`, cenário com dados |
| RLS | **106/106 habilitada e forçada**; 3 lacunas encontradas (logs, perfis/permissões globais, `refresh_tokens`): as duas primeiras **corrigidas**, `refresh_tokens` **pendente de decisão** | §3 D-01/D-02 |
| Pronto para produção? | **Não.** Faltam staging com PostgreSQL 18 em Linux, backup restaurado em outro host e as decisões D-01, D-03, D-04, D-05, D-08 | §3 |

## 1. Registro de achados

| ID | Classe | Gravidade | Objeto | Estado | Resumo |
|---|---|---|---|---|---|
| A-01 | Falso positivo como migration · **Confirmado como risco de deriva** | Alta (se o diff fosse aplicado) | `support_tickets.ticketNumber`, `support_ticket_number_seq` | **CORRIGIDO** (schema) | o diff propunha `SET DEFAULT` + `DROP DEFAULT` + `DROP SEQUENCE`; novos chamados ficariam sem número |
| B-01 | Falso positivo como migration · **Confirmado como risco de deriva** | Média | `support_kb_articles.search` / `support_kb_articles_search_idx` | **CORRIGIDO** (schema) | o diff propunha `DROP INDEX` do GIN e tirar defaults |
| B-02 | **Confirmado** | Baixa | índice GIN da busca | PENDENTE-DECISÃO (monitorar) | com o papel da aplicação a RLS impede o planejador de usar o GIN; irrelevante no volume atual |
| C-01 | **Confirmado** (teste vermelho antes) | Média | `product_barcodes`, `product_images` | **CORRIGIDO** | linha da empresa A apontava para produto da empresa B |
| C-02 | **Confirmado** (estrutura) · 0 linhas cruzadas (dados) | Média | 66 FKs simples com `companyId` nos dois lados | PENDENTE-DECISÃO | mesma classe de C-01, em outras tabelas; plano por fases |
| C-03 | **Confirmado** (experimento revertido) | Média (processo) | `ADD CONSTRAINT` sobre tabela FORCE RLS | **CORRIGIDO** (guarda) | a validação da FK feita pelo dono sem contexto "passa em branco" |
| D-01 | **Confirmado** | **Alta** | `refresh_tokens` | PENDENTE-DECISÃO | 136/136 linhas com `companyId` nulo, visíveis a qualquer empresa; token em texto |
| D-02 | **Confirmado** (teste vermelho antes) | Média | `request_logs`, `system_logs`, `roles`, `permissions` | **CORRIGIDO** | logs de plataforma legíveis por empresa; `WITH CHECK true`; globais apagáveis por empresa |
| D-03 | Confirmado | Média | `stock_movements`, `cash_movements`, `sale_items`, `revisions`, `service_order_status_history`, `policy_changes` | PENDENTE-DECISÃO | imutabilidade só na aplicação |
| D-04 | Confirmado | Média | 41 FKs `ON DELETE CASCADE` | PENDENTE-DECISÃO | apagar o pai apaga histórico (a aplicação só apaga empresa vazia) |
| D-05 | Confirmado | Média | 74 `companyId` e 64 `branchId` sem FK; 1 recebível órfão | PENDENTE-DECISÃO | convenção do projeto; órfão de teste antigo, não removido |
| D-06 | Confirmado | Baixa | 6 índices idênticos a um UNIQUE + 34 que são início de outro | PENDENTE-DECISÃO | custo de escrita; nada removido |
| D-07 | Confirmado | Média | colunas `timestamp` sem fuso (273) com default do banco (110) | PENDENTE-DECISÃO | servidor em `America/Sao_Paulo`; Prisma grava UTC |
| D-08 | Confirmado | Média | papel da aplicação = dono das tabelas; contexto de empresa é variável de sessão | PENDENTE-INFRA | quem executa SQL arbitrário pode desligar RLS ou virar Super Admin |
| D-09 | Confirmado | Baixa | 10 tabelas filhas sem índice começando por `companyId`; 9 tabelas com `branchId` fora da policy | PENDENTE-DECISÃO | desempenho / regra de filial |
| D-10 | Confirmado | Média | sem retenção de `audit_logs`, `request_logs`, `system_logs`, `idempotency_keys` | PENDENTE-DECISÃO | jurídico + dono |
| D-11 | Confirmado | — | staging/produção, PostgreSQL 18 em Linux, backup em outro host | PENDENTE-INFRA | nada aplicado fora de dev/teste |

## 2. Os três achados iniciais — investigação

### Achado A — `ticketNumber` e a sequência

- **Origem do SQL (Confirmado):** não está em nenhuma migration. `support_ticket_number_seq` aparece só em `20260928200000_support_center` (criação da sequência `START WITH 1000`, `DEFAULT nextval(...)` da coluna `NOT NULL` e `OWNED BY`). As linhas `SET DEFAULT … DROP DEFAULT … DROP SEQUENCE` são a saída de `prisma migrate diff --from-schema-datasource` da rodada anterior (`drift-dev.txt` antigo). Causa: o schema descrevia o default como `dbgenerated("nextval('support_ticket_number_seq'::regclass)")`; o motor do Prisma trata `nextval(...)` como *autoincrement* e, com `dbgenerated`, "corrige" para nenhum default.
- **Estado real do banco:** coluna `NOT NULL`, `DEFAULT nextval('support_ticket_number_seq'::regclass)`, índice único, sequência pertencente à coluna. Dev: sequência em 1012, 0 chamados; teste: sequência em 1704, 0 chamados (nenhum número a preservar nesses bancos, e nenhum dado foi tocado).
- **Decisão:** a numeração **continua automática pela mesma sequência** (global, não depende de enxergar linhas de outras empresas sob RLS). `schema.prisma` passa a `@default(autoincrement())` — exatamente o que o `db pull` devolve.
- **Preservação e colisão:** nenhuma mudança de banco → números existentes intactos; a sequência não é recriada nem reiniciada. Teste `support-schema-objects` (5): estrutura (NOT NULL, default, sequência existe e pertence à coluna), **12 chamados em paralelo recebem 12 números distintos, acima de qualquer existente**, `last_value ≥ max(ticketNumber)`, e repetir um número é recusado pelo índice único.
- **Se o diff antigo tivesse sido aplicado:** `INSERT` sem número → violação de `NOT NULL` em todo chamado novo.

### Achado B — índice e coluna `search` da base de conhecimento

- **Origem do SQL (Confirmado):** idem — o `DROP INDEX` e os `DROP DEFAULT` são do diff, não de migration. `20260928200000_support_center` cria `search tsvector GENERATED ALWAYS AS (setweight(to_tsvector('portuguese', title), 'A') || … resumo+palavras-chave 'B' || … corpo 'C') STORED` e `CREATE INDEX support_kb_articles_search_idx … USING GIN (search)`.
- **Natureza (Confirmado):** coluna **gerada e armazenada** (`attgenerated = 's'`), mantida pelo banco — não por trigger nem pela aplicação. Consultas: `support-kb.service.ts` usa `search @@ websearch_to_tsquery('portuguese', …)` e `ts_rank(search, …)`; é o único uso.
- **Correção (schema, sem mudança de banco):** `search Unsupported("tsvector")? @default(dbgenerated("<expressão de geração como o PostgreSQL a guarda>"))`, `@@index([search], type: Gin)` e `updatedAt @default(now()) @updatedAt` nas duas tabelas da base de conhecimento. `prisma migrate diff` banco → schema: **vazio**. Pesquisa, índice e defaults **preservados**.
- **Plano de consulta (Observado, `EXPLAIN (ANALYZE, BUFFERS)` no banco de teste, somente leitura):** com `enable_seqscan = off` a consulta de texto puro usa `Bitmap Index Scan on support_kb_articles_search_idx` (índice utilizável); com 10 artigos o planejador escolhe varredura sequencial por custo. A consulta **real** do serviço combina `OR title ILIKE … OR keywords ILIKE …` e por isso não usa o índice de qualquer forma.
- **B-02 (Confirmado, Baixa):** sob o papel da aplicação, a RLS acrescenta ao filtro a condição `is_super_admin()` (função **não** *leakproof*), e o operador `@@` também não é — o planejador **não usa o GIN para esse papel** nem com `enable_seqscan = off`. Com a base de conhecimento global pequena é irrelevante; o teste fixa um limite (< 2 000 artigos) e a recomendação, se crescer, é busca por função `SECURITY DEFINER` ou policy sem função. O índice foi **mantido** (usado por papéis que ignoram RLS e se a policy mudar).

### Achado C — `product_barcodes` e `product_images`

- **Estrutura anterior (Confirmado):** FK `(productId) → products(id)` e FK `(companyId) → companies(id)`; policy `rls_company_match("companyId")` só olha o `companyId` **da própria linha**; a checagem de FK do PostgreSQL **não passa pela RLS**. Teste de integração (sessão da empresa A, papel da aplicação): `INSERT (companyId = A, productId = produto da B)` **era aceito** (6 de 8 casos vermelhos), e o mesmo no `UPDATE`.
- **Dados existentes (Observado):** dev 0 e teste 1 linha de código de barras, 0 imagens; **0 linhas cruzadas**; `(companyId, id)` sem duplicidade em `products` (`companyId` é `NOT NULL`).
- **Correção:** `20261014155900_guard_product_children_same_company` (guarda: lê como plataforma e aborta se houver linha cruzada) → `20261014160000_product_children_same_company` (índice único `products(companyId, id)` como alvo; FKs compostas `(companyId, productId) → products(companyId, id)` com as **mesmas** regras de antes — código de barras `RESTRICT`, imagem `CASCADE`; FKs simples antigas saem) → `20261014161000_product_images_company_product_unique` (índice `(companyId, productId)` exigido pelo Prisma para a relação 1:1). `schema.prisma`: relações compostas e `@@unique([companyId, id])` em `Product`. O código da API não mudou (usa `companyId` e `productId` escalares).
- **Teste `product-children-same-company` (8, verde):** estrutura; INSERT cruzado recusado nas duas tabelas (`P2003`); INSERT legítimo funciona; UPDATE cruzado recusado e linha inalterada; leitura da empresa B não vê linhas da A; DELETE do produto com código de barras segue `RESTRICT` e com imagem segue `CASCADE`; nenhum dado cruzado.
- **Achado derivado (C-03) — a validação de FK é cega sob FORCE RLS:** o `ADD CONSTRAINT` feito pelo dono, sem contexto, enxerga **zero linhas** e é criado mesmo com linha violando (experimento revertido: com uma linha cruzada ele **passou**; com `app.user_type = SUPER_ADMIN` **falhou**). A primeira versão do cabeçalho prometia "a migration falha"; **estava errada** e foi corrigida (reconciliação de checksum documentada em [RELATORIO_MIGRATIONS §4.4](RELATORIO_MIGRATIONS.md)). A guarda faz a checagem explícita. Provado em banco temporário **com dado cruzado**: o `migrate deploy` falha na guarda, nada fica pela metade, e `migrate resolve --rolled-back` + novo deploy conclui. Além disso, as **109 FKs existentes foram conferidas com o papel que ignora RLS: 0 violações**.
- **C-02 (Pendente):** a mesma classe existe nas outras **66 FKs simples** (filho e pai com `companyId`); dados atuais: **0 linhas cruzadas** (lista e dados em §5-D3). Não foi generalizado porque (a) 12 delas são `SET NULL`, que o Prisma não modela como FK composta (anularia também o `companyId`), (b) exige uma chave única `(companyId, id)` em 24 tabelas-pai e mudar o schema de ~54 relações, (c) a exploração exige conhecer o UUID de um registro de outra empresa. **Plano por fases:** 1) financeiras (`payments.saleId`, `external_orders.saleId`, `fulfillments.saleId`, `collection_attempts.receivableId`, `stock_reservations.*`, `sales.customerId/partnerId`), 2) estoque e catálogo (`stock_movements.productId`, `damage_records.productId`, `channel_product_links.productId`), 3) o resto; cada fase com guarda de dados, teste de acesso cruzado e *rollback* no cabeçalho.

## 3. Demais achados confirmados

**D-01 — `refresh_tokens` sem isolamento por empresa e com token em texto. Gravidade: Alta (antes de produção). Estado: PENDENTE-DECISÃO.**
- *Observado:* as 136 linhas do dev têm `companyId` **nulo** (o código que cria a sessão não preenche a coluna) e a policy `refresh_tokens_isolation` aceita `"companyId" IS NULL` para qualquer sessão; uma sessão **de empresa** (COMPANY_ADMIN) enxerga as 136 linhas. A coluna `token` guarda o refresh token **em texto** (busca por igualdade).
- *Impacto:* a aplicação sempre filtra por token/usuário, então não há vazamento hoje por rota; mas uma falha futura de filtro, injeção de SQL ou backup lido por terceiro entrega sessões utilizáveis (7 dias) de todas as empresas.
- *Correção proposta (não aplicada — mexe no núcleo de autenticação, exige backfill de dado e migration + testes):* (1) preencher `companyId` na criação **e** fazer o *backfill* das linhas existentes (`UPDATE … FROM users`), (2) remover o ramo `IS NULL` para contextos de empresa (o Super Admin usa o contexto de plataforma), (3) guardar o **SHA-256** do token e buscar pelo hash, com leitura dupla até as sessões antigas expirarem (≤ 7 dias), (4) teste de acesso cruzado. *Risco da correção:* sessões ativas caem se o backfill ou a leitura dupla falharem; a revogação por mudança de perfil deve continuar alcançando as linhas antigas.

**D-02 — Logs de plataforma e perfis/permissões globais alcançáveis por uma empresa. Gravidade: Média. Estado: CORRIGIDO** (`20261014162000_rls_logs_roles_tighten`, teste `rls-logs-roles-tighten`, 6, vermelho antes). *Observado no dev:* uma sessão de empresa lia **371** `system_logs` e **3 540** `request_logs` de plataforma (eventos como `REFRESH_TOKEN_REUSE_DETECTED`), gravava log com o `companyId` de **outra** empresa (`WITH CHECK true`), e — por semântica de política `ALL` (o `DELETE` usa só o `USING`) — alcançava o `UPDATE`/`DELETE` de perfis e permissões globais (`companyId` nulo). *Correção:* logs com `rls_company_match("companyId")` em leitura e escrita (quem grava é o worker, em contexto de plataforma); `roles`/`permissions` com `SELECT` incluindo os globais e `INSERT/UPDATE/DELETE` só da própria empresa ou do Super Admin. `audit_logs` já era estrito (0 linhas de plataforma visíveis). *Dados:* nenhuma linha tocada. *Risco residual:* um futuro código que grave log em contexto de empresa com `companyId` nulo será recusado (nenhum hoje: o único gravador é o worker).

**D-03 — Imutabilidade de livros e históricos só na aplicação. Gravidade: Média. PENDENTE-DECISÃO.** *Observado:* `stock_movements`, `cash_movements`, `sale_items`, `revisions`, `service_order_status_history` e `policy_changes` permitem UPDATE/DELETE pela RLS; `audit_logs`, `collection_attempts`, `discount_events` e `monitoring_threshold_changes` já negam UPDATE no banco. Varredura do código: só `sale_items.returnedQuantity` (contador de devolução) e `revisions.notes` (anonimização, decisão 120) são atualizados; nenhuma rota apaga os demais. *Por que não foi feito:* "append-only" indiscriminado quebraria correção legítima (estorno por lançamento reverso é o modelo certo, mas a anonimização LGPD e o contador de devolução precisam de exceção explícita). *Proposta:* repetir o padrão de `20260925100000_audit_logs_append_only` (políticas separadas por comando) em `stock_movements` e `cash_movements` (livros) e deixar `sale_items`/`revisions` com exceção documentada.

**D-04 — `ON DELETE CASCADE` sobre histórico. Gravidade: Média (mitigada pela aplicação). PENDENTE-DECISÃO.** 41 FKs em cascata, entre elas `stock_movements.productId → products`, `sale_items.saleId → sales`, `payments.saleId → sales`, `cash_movements.cashRegisterId → cash_registers` (§5-D). O único `delete` de entidade-pai no código (`company`, `product`, `sale`, `cashRegister`, `customer`, `serviceOrder`) é `company.delete`, só para empresa **sem filiais e sem usuários**. *Proposta:* `RESTRICT` nessas FKs; muda o comportamento de `destroyFixture` e de qualquer limpeza por SQL, por isso exige ajuste de testes.

**D-05 — Escopo e relações sem FK. Gravidade: Média. PENDENTE-DECISÃO.** 74 das 85 tabelas com `companyId` e 64 com `branchId` não têm FK; 43 relações entre entidades são só lógicas. Órfãos medidos (papel que ignora RLS, só contagem): **183 relações, 10 com órfãos** — logs de empresas/usuários de teste já removidos (esperado), `idempotency_keys.companyId` (7) e **1 `accounts_receivable`** (`ServiceOrder`, `PAID`, 14/09/2026) cuja empresa, filial e cliente não existem mais — sobra de teste antigo, **não removida** (regra: não apagar registro financeiro). *Inferência:* origem provável é a limpeza de uma empresa de teste; sem FK, nada impede apagar a empresa deixando o recebível. Decisão pendente: FK `RESTRICT` do `companyId` nas tabelas financeiras.

**D-06 — Índices duplicados. Gravidade: Baixa.** 6 índices comuns são **idênticos** a um UNIQUE existente (`device_telemetry_deviceId_collectedAt_idx`, `fiscal_documents_accessKey_idx`, `invoices_accessKey_idx`, `payments_transactionId_idx`, `refresh_tokens_token_idx`, `users_email_idx`) e 34 são o início de outro (§5-H). Esta revisão **acrescentou** dois ao conjunto (`products_companyId_idx` e `product_images_companyId_idx` passaram a ser cobertos pelos novos índices compostos). Nada foi removido: decidir com `pg_stat_user_indexes` em staging.

**D-07 — Fuso horário. Gravidade: Média/Baixa. PENDENTE-DECISÃO.** 273 colunas `timestamp(3) without time zone` (o Prisma grava em UTC) e 110 delas com `DEFAULT CURRENT_TIMESTAMP` no banco, cujo valor usa o fuso da **sessão** (`America/Sao_Paulo` no dev). Linhas criadas por SQL direto (migrations de carga, scripts) podem ficar em hora local enquanto as criadas pelo Prisma ficam em UTC (diferença de 3 h). *Proposta:* `ALTER ROLE <app> SET timezone = 'UTC'` (ou no servidor) e/ou `timestamptz` numa migration planejada. Dinheiro: nenhuma coluna `numeric` sem precisão; nenhuma coluna de ponto flutuante em tabela financeira (as 12 são métricas de monitoramento).

**D-08 — Papel da aplicação é o dono das tabelas. Gravidade: Média. PENDENTE-INFRA.** O papel de execução (`lnsystem`, não superusuário, sem `BYPASSRLS`) **é o dono** das tabelas e o contexto de empresa/Super Admin vem de variáveis de sessão (`app.current_company_id`, `app.user_type`) definidas pela aplicação (transação-local: seguro com *pool*). `FORCE ROW LEVEL SECURITY` vale para o dono, mas quem consegue executar SQL arbitrário com esse papel pode `ALTER TABLE … DISABLE ROW LEVEL SECURITY`, `DROP POLICY` ou `set_config('app.user_type','SUPER_ADMIN')`. *Proposta:* dois papéis — um dono das migrations (usado só no deploy) e um de execução não dono, só com DML, sem DDL; combinar com a guarda de dados (C-03). Exige mudança de infraestrutura e do `docker-compose.yml`.

**D-09 — Índices e filial.** 10 tabelas filhas com `companyId` sem índice que o comece (`employee_agreement_charges`, `employee_payroll_deductions`, `external_order_items`, `quote_events`, `supplier_return_events`, `supplier_return_items`, `support_ticket_attachments`, `support_ticket_events`, `support_ticket_messages`, `warranty_claims`): a RLS filtra por `companyId` e o plano depende do índice da chave do pai — acompanhar em staging. 9 tabelas com `branchId` cuja policy não usa filial (`devices`, `installment_policies`, `monitoring_threshold_changes`, `monitoring_thresholds`, `partners`, `request_logs`, `system_logs`, `user_roles`, `users`): o isolamento por filial é só da aplicação nelas — confirmar com o dono ("o gerente da filial A vê o usuário da filial B?").

**D-10 — Retenção.** Sem expurgo de `audit_logs`, `request_logs`, `system_logs` e `idempotency_keys`; `request_logs` tem ≈ 13 mil linhas apontando empresas inexistentes. Dado pessoal (IP, usuário) sem prazo. Depende de política aprovada (jurídico + dono).

**D-11 — Infraestrutura.** As 40 migrations estão aplicadas só em dev e teste. Roteiro: backup restaurável → `prisma migrate deploy` → `npm run db:check-rls` → `npm run db:replay-check` contra o staging ([PRODUCAO §4, §13–15](PRODUCAO.md)). O dev roda PostgreSQL 18.6 no Windows; a CI e o compose usam `postgres:18-alpine`; **a cadeia de migrations nunca rodou em Linux nesta máquina**. Backup restaurável só provado em dev (`backup:verify`, 18/18); restauração em **outro host** e RPO/RTO pendentes (decisão 106).

## 4. Dados existentes — como foram protegidos

- Nenhum registro de banco compartilhado foi apagado, truncado, anonimizado ou reescrito. As quatro migrations novas **não leem nem alteram linha** (guarda: só `SELECT`; FKs e índice: só estrutura; políticas: só RLS) e foram aplicadas apenas nos bancos locais de desenvolvimento e teste.
- Antes de criar as FKs compostas: contagem de linhas cruzadas (0), de duplicidade de `(companyId, id)` (0) e das 109 FKs existentes (0 violações).
- Os testes criam dados sintéticos em empresas de teste e os removem por `id` (a fixture `destroyFixture` recusa empresas que não sejam "Integration Test Co …"). Experimentos que exigiam dado inconsistente rodaram em **transação revertida** (banco de teste) ou em **banco temporário** criado e removido pelo script.
- Exceção documentada: o **checksum** de `20261014160000…` no `_prisma_migrations` de dev e teste foi atualizado depois de corrigir um comentário do cabeçalho (nenhuma instrução SQL mudou) — [RELATORIO_MIGRATIONS §4.4](RELATORIO_MIGRATIONS.md).
- O recebível órfão de teste e as 4 vendas do sandbox foram **mantidos**.

## 5. Achados automáticos (catálogo do PostgreSQL)

<!-- db-docs:findings:begin -->
### A. Estrutura e RLS (consulta ao catálogo em 2026-10-14)

| Verificação | Resultado |
|---|---|
| Tabelas (banco) / modelos (schema) | 106 / 106 — coincidem |
| Tabelas sem RLS habilitada **e** forçada | 0 |
| Tabelas com RLS e **nenhuma** policy | 0 |
| Tabelas sem chave primária | 0 |
| Policies sem condição ou `true` | `support_kb_categories.support_kb_categories_read (SELECT: true)` |
| `companyId` anulável (linha sem dono de empresa) | `audit_logs`, `monitoring_alerts`, `monitoring_threshold_changes`, `monitoring_thresholds`, `permissions`, `refresh_tokens`, `request_logs`, `roles`, `system_logs`, `users` |
| Tabelas com `branchId` cuja policy **não** menciona filial | 9: `devices`, `installment_policies`, `monitoring_threshold_changes`, `monitoring_thresholds`, `partners`, `request_logs`, `system_logs`, `user_roles`, `users` |
| Tabelas com `companyId` sem índice que comece por `companyId` | 10: `employee_agreement_charges`, `employee_payroll_deductions`, `external_order_items`, `quote_events`, `supplier_return_events`, `supplier_return_items`, `support_ticket_attachments`, `support_ticket_events`, `support_ticket_messages`, `warranty_claims` |
| Papel de conexão desta consulta | `lnsystem` — superusuário: não; ignora RLS: não |

### B. Tabelas sem `companyId` (21) e como são isoladas

| Tabela | Domínio | Policies (condição resumida) |
|---|---|---|
| `access_revocations` | Plataforma, identidade e acesso | access_revocations_platform: `is_super_admin()` |
| `activations` | Plataforma, identidade e acesso | activations_isolation: `(is_super_admin() OR ("licenseId" IN ( SELECT licenses.id FROM licenses WHERE (licenses."companyId" = get_current_company_id()))))` |
| `appointment_events` | Clientes, veículos e pós-venda | appointment_events_isolation: `("appointmentId" IN ( SELECT appointments.id FROM appointments))` |
| `cash_movements` | Vendas, caixa e pagamento | cash_movements_isolation: `("cashRegisterId" IN ( SELECT cash_registers.id FROM cash_registers))` |
| `combo_items` | Catálogo e estoque | combo_items_isolation: `("comboId" IN ( SELECT products.id FROM products))` |
| `companies` | Plataforma, identidade e acesso | companies_isolation: `(is_super_admin() OR (id = get_current_company_id()))` |
| `devices` | Plataforma, identidade e acesso | devices_isolation: `(is_super_admin() OR ("licenseId" IN ( SELECT licenses.id FROM licenses WHERE (licenses."companyId" = get_current_company_id()))))` |
| `follow_up_events` | Clientes, veículos e pós-venda | follow_up_events_isolation: `("followUpId" IN ( SELECT follow_ups.id FROM follow_ups))` |
| `inventory_counts` | Catálogo e estoque | inventory_counts_isolation: `("inventoryId" IN ( SELECT inventories.id FROM inventories))` |
| `purchase_order_items` | Catálogo e estoque | purchase_order_items_isolation: `("purchaseOrderId" IN ( SELECT purchase_orders.id FROM purchase_orders))` |
| `quote_items` | Oficina | quote_items_isolation: `("quoteVersionId" IN ( SELECT quote_versions.id FROM quote_versions))` |
| `quote_versions` | Oficina | quote_versions_isolation: `("quoteId" IN ( SELECT quotes.id FROM quotes))` |
| `role_permissions` | Plataforma, identidade e acesso | role_permissions_isolation: `("roleId" IN ( SELECT roles.id FROM roles))` |
| `sale_items` | Vendas, caixa e pagamento | sale_items_isolation: `("saleId" IN ( SELECT sales.id FROM sales))` |
| `service_order_items` | Oficina | service_order_items_isolation: `("serviceOrderId" IN ( SELECT service_orders.id FROM service_orders))` |
| `service_order_status_history` | Oficina | service_order_status_history_isolation: `("serviceOrderId" IN ( SELECT service_orders.id FROM service_orders))` |
| `support_kb_articles` | Ajuda e Suporte | support_kb_articles_read: `((status = 'PUBLISHED'::text) OR is_super_admin())`; support_kb_articles_write: `is_super_admin()` |
| `support_kb_categories` | Ajuda e Suporte | support_kb_categories_read: `true`; support_kb_categories_write: `is_super_admin()` |
| `transfer_items` | Catálogo e estoque | transfer_items_isolation: `("transferId" IN ( SELECT transfers.id FROM transfers))` |
| `user_roles` | Plataforma, identidade e acesso | user_roles_isolation: `("userId" IN ( SELECT users.id FROM users))` |
| `vehicle_entry_checklist_items` | Oficina | vehicle_entry_checklist_items_isolation: `("checklistId" IN ( SELECT vehicle_entry_checklists.id FROM vehicle_entry_checklists))` |

### C. Isolamento por convenção (sem FK)

- **74** tabelas com `companyId` sem FK para `companies`; **64** com `branchId` sem FK para `branches`; **45** relações `…Id` entre entidades sem FK (inferidas; ver [MAPA_RELACIONAMENTOS](MAPA_RELACIONAMENTOS.md) §5).
- Efeito: o banco não rejeita uma referência órfã nem um registro apontando para outra empresa; a defesa é a RLS (`WITH CHECK`) e os serviços. Uma verificação de órfãos por consulta exigiria um papel que ignore a RLS (não disponível; a conexão da aplicação não ignora RLS) — **não executada**.

### D. FKs com `ON DELETE CASCADE` (41; apagar o pai apaga os filhos — as marcadas com ⚠ ficam em domínio financeiro, fiscal, de oficina ou de auditoria)

- `activations.deviceId` → `devices` (Plataforma, identidade e acesso)
- `activations.licenseId` → `licenses` (Plataforma, identidade e acesso)
- `activations.userId` → `users` (Plataforma, identidade e acesso)
- `appointment_events.appointmentId` → `appointments` (Clientes, veículos e pós-venda)
- ⚠ `audit_logs.companyId` → `companies` (Auditoria, observabilidade e operação)
- `branches.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `cash_movements.cashRegisterId` → `cash_registers` (Vendas, caixa e pagamento)
- `combo_items.comboId` → `products` (Catálogo e estoque)
- `combo_items.productId` → `products` (Catálogo e estoque)
- `device_sessions.deviceId` → `devices` (Plataforma, identidade e acesso)
- `device_sessions.userId` → `users` (Plataforma, identidade e acesso)
- `devices.licenseId` → `licenses` (Plataforma, identidade e acesso)
- `follow_up_events.followUpId` → `follow_ups` (Clientes, veículos e pós-venda)
- `installment_policies.companyId` → `companies` (Políticas e calendário)
- `inventory_counts.inventoryId` → `inventories` (Catálogo e estoque)
- `licenses.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `partners.companyId` → `companies` (Vendas, caixa e pagamento)
- ⚠ `payments.saleId` → `sales` (Vendas, caixa e pagamento)
- `permissions.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `privacy_requests.companyId` → `companies` (Auditoria, observabilidade e operação)
- `product_barcodes.companyId` → `companies` (Catálogo e estoque)
- `product_images.companyId` → `companies` (Catálogo e estoque)
- `product_images.companyId, productId` → `products` (Catálogo e estoque)
- `purchase_order_items.purchaseOrderId` → `purchase_orders` (Catálogo e estoque)
- ⚠ `quote_events.quoteId` → `quotes` (Oficina)
- ⚠ `quote_items.quoteVersionId` → `quote_versions` (Oficina)
- ⚠ `quote_versions.quoteId` → `quotes` (Oficina)
- `refresh_tokens.userId` → `users` (Plataforma, identidade e acesso)
- `role_permissions.permissionId` → `permissions` (Plataforma, identidade e acesso)
- `role_permissions.roleId` → `roles` (Plataforma, identidade e acesso)
- `roles.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `sale_items.saleId` → `sales` (Vendas, caixa e pagamento)
- ⚠ `service_order_items.serviceOrderId` → `service_orders` (Oficina)
- ⚠ `service_order_status_history.serviceOrderId` → `service_orders` (Oficina)
- `stock_movements.productId` → `products` (Catálogo e estoque)
- `transfer_items.transferId` → `transfers` (Catálogo e estoque)
- `user_roles.roleId` → `roles` (Plataforma, identidade e acesso)
- `user_roles.userId` → `users` (Plataforma, identidade e acesso)
- `users.companyId` → `companies` (Plataforma, identidade e acesso)
- ⚠ `vehicle_entry_checklist_items.checklistId` → `vehicle_entry_checklists` (Oficina)
- ⚠ `vehicle_entry_checklists.serviceOrderId` → `service_orders` (Oficina)

### D2. Órfãos nas relações sem FK — executada em 2026-10-14 no banco de desenvolvimento (dados sintéticos), somente contagens

183 relações conferidas (escopo de empresa e de filial sem FK + relações lógicas inferidas por nome); com órfãos: **10**.

| Relação | Linhas órfãs |
|---|---|
| `accounts_receivable.companyId → companies (empresa)` | 1 |
| `idempotency_keys.companyId → companies (empresa)` | 7 |
| `request_logs.companyId → companies (empresa)` | 12863 |
| `system_logs.companyId → companies (empresa)` | 90 |
| `accounts_receivable.branchId → branches (filial)` | 1 |
| `request_logs.branchId → branches (filial)` | 10500 |
| `system_logs.branchId → branches (filial)` | 68 |
| `accounts_receivable.customerId → customers (lógica inferida)` | 1 |
| `request_logs.userId → users (lógica inferida)` | 13528 |
| `system_logs.userId → users (lógica inferida)` | 420 |

Relações "lógica inferida" são deduzidas do nome da coluna: contagem > 0 pode ser erro da inferência (coluna que aponta para outra entidade) e não necessariamente dado órfão — conferir caso a caso.

### D2b. FKs declaradas: linhas sem pai — 109 FKs conferidas com o papel que ignora RLS; **com violação: 0**

Existir a FK não prova que os dados antigos a respeitam: o `ADD CONSTRAINT` feito pelo dono sob FORCE RLS, sem contexto, não enxerga as linhas (ver [RELATORIO_MIGRATIONS](RELATORIO_MIGRATIONS.md) §4.3).

### D3. Referências possivelmente cruzadas entre empresas — FKs simples onde filho e pai têm `companyId` (66)

Nada no banco impede `(companyId = A, <pai> = registro da B)` nestas FKs: a checagem de FK não passa pela RLS e a policy do filho só olha o companyId do próprio filho. As FKs de `product_barcodes` e `product_images` **já são compostas** (migração 20261014160000) e por isso não entram na lista. Dados atuais: **66 FKs conferidas, 0 com linha cruzada**. "SET NULL" não pode virar FK composta no Prisma (anularia também o companyId); "pai/filho anulável" exige tratamento próprio.

| Filho.coluna → Pai | Ao apagar o pai | companyId do pai | companyId do filho |
|---|---|---|---|
| `appointments.customerId` → `customers` | RESTRICT | obrigatório | obrigatório |
| `appointments.followUpId` → `follow_ups` | SET NULL | obrigatório | obrigatório |
| `appointments.motorcycleId` → `motorcycles` | SET NULL | obrigatório | obrigatório |
| `audit_logs.userId` → `users` | SET NULL | **anulável** | **anulável** |
| `categories.parentId` → `categories` | SET NULL | obrigatório | obrigatório |
| `channel_api_credentials.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `channel_events.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `channel_inbound_events.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `channel_outbox.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `channel_product_links.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `channel_product_links.productId` → `products` | RESTRICT | obrigatório | obrigatório |
| `collection_attempts.receivableId` → `accounts_receivable` | RESTRICT | obrigatório | obrigatório |
| `damage_records.productId` → `products` | RESTRICT | obrigatório | obrigatório |
| `device_sessions.userId` → `users` | CASCADE | **anulável** | obrigatório |
| `employee_agreement_charges.agreementId` → `employee_agreements` | RESTRICT | obrigatório | obrigatório |
| `employee_payroll_deductions.chargeId` → `employee_agreement_charges` | RESTRICT | obrigatório | obrigatório |
| `external_order_items.orderId` → `external_orders` | RESTRICT | obrigatório | obrigatório |
| `external_order_items.productId` → `products` | RESTRICT | obrigatório | obrigatório |
| `external_orders.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `external_orders.saleId` → `sales` | RESTRICT | obrigatório | obrigatório |
| `external_payments.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `external_payments.orderId` → `external_orders` | RESTRICT | obrigatório | obrigatório |
| `follow_ups.customerId` → `customers` | RESTRICT | obrigatório | obrigatório |
| `follow_ups.motorcycleId` → `motorcycles` | RESTRICT | obrigatório | obrigatório |
| `follow_ups.revisionId` → `revisions` | SET NULL | obrigatório | obrigatório |
| `fulfillments.orderId` → `external_orders` | RESTRICT | obrigatório | obrigatório |
| `fulfillments.saleId` → `sales` | RESTRICT | obrigatório | obrigatório |
| `invoices.purchaseOrderId` → `purchase_orders` | SET NULL | obrigatório | obrigatório |
| `invoices.supplierId` → `suppliers` | RESTRICT | obrigatório | obrigatório |
| `mechanic_commissions.serviceOrderId` → `service_orders` | RESTRICT | obrigatório | obrigatório |
| `motorcycles.customerId` → `customers` | RESTRICT | obrigatório | obrigatório |
| `payment_exceptions.paymentId` → `payments` | RESTRICT | obrigatório | obrigatório |
| `payments.saleId` → `sales` | CASCADE | obrigatório | obrigatório |
| `products.categoryId` → `categories` | SET NULL | obrigatório | obrigatório |
| `purchase_orders.supplierId` → `suppliers` | RESTRICT | obrigatório | obrigatório |
| `quote_events.quoteId` → `quotes` | CASCADE | obrigatório | obrigatório |
| `quotes.customerId` → `customers` | RESTRICT | obrigatório | obrigatório |
| `quotes.motorcycleId` → `motorcycles` | RESTRICT | obrigatório | obrigatório |
| `refresh_tokens.userId` → `users` | CASCADE | **anulável** | **anulável** |
| `revisions.customerId` → `customers` | RESTRICT | obrigatório | obrigatório |
| `revisions.motorcycleId` → `motorcycles` | RESTRICT | obrigatório | obrigatório |
| `revisions.serviceOrderId` → `service_orders` | SET NULL | obrigatório | obrigatório |
| `sales.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `sales.customerId` → `customers` | SET NULL | obrigatório | obrigatório |
| `sales.partnerId` → `partners` | SET NULL | obrigatório | obrigatório |
| `sales.userId` → `users` | RESTRICT | **anulável** | obrigatório |
| `service_order_warranties.serviceOrderId` → `service_orders` | RESTRICT | obrigatório | obrigatório |
| `service_orders.customerId` → `customers` | RESTRICT | obrigatório | obrigatório |
| `service_orders.mechanicId` → `users` | SET NULL | **anulável** | obrigatório |
| `service_orders.motorcycleId` → `motorcycles` | RESTRICT | obrigatório | obrigatório |
| `stock_movements.productId` → `products` | CASCADE | obrigatório | obrigatório |
| `stock_reservations.channelId` → `sales_channels` | RESTRICT | obrigatório | obrigatório |
| `stock_reservations.orderId` → `external_orders` | RESTRICT | obrigatório | obrigatório |
| `stock_reservations.productId` → `products` | RESTRICT | obrigatório | obrigatório |
| `supplier_return_events.returnId` → `supplier_returns` | RESTRICT | obrigatório | obrigatório |
| `supplier_return_items.productId` → `products` | RESTRICT | obrigatório | obrigatório |
| `supplier_return_items.returnId` → `supplier_returns` | RESTRICT | obrigatório | obrigatório |
| `supplier_returns.supplierId` → `suppliers` | RESTRICT | obrigatório | obrigatório |
| `support_ticket_attachments.messageId` → `support_ticket_messages` | RESTRICT | obrigatório | obrigatório |
| `support_ticket_attachments.ticketId` → `support_tickets` | RESTRICT | obrigatório | obrigatório |
| `support_ticket_events.ticketId` → `support_tickets` | RESTRICT | obrigatório | obrigatório |
| `support_ticket_messages.ticketId` → `support_tickets` | RESTRICT | obrigatório | obrigatório |
| `users.branchId` → `branches` | SET NULL | obrigatório | **anulável** |
| `vehicle_entry_checklists.motorcycleId` → `motorcycles` | RESTRICT | obrigatório | obrigatório |
| `vehicle_entry_checklists.serviceOrderId` → `service_orders` | CASCADE | obrigatório | obrigatório |
| `warranty_claims.warrantyId` → `service_order_warranties` | RESTRICT | obrigatório | obrigatório |

### E. Imutabilidade de histórico e livros: o que a RLS permite

A imutabilidade no banco é feita por **RLS** (comando sem policy = negado; `FORCE RLS` vale também para o dono), não por trigger. Para cada tabela de histórico/livro, os comandos que têm policy:

| Tabela | SELECT | INSERT | UPDATE | DELETE | Leitura |
|---|---|---|---|---|---|
| `audit_logs` | policy | policy | negado | policy | sem UPDATE; DELETE só pelas condições da policy |
| `collection_attempts` | policy | policy | negado | policy | sem UPDATE; DELETE só pelas condições da policy |
| `discount_events` | policy | policy | negado | policy | sem UPDATE; DELETE só pelas condições da policy |
| `policy_changes` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `monitoring_threshold_changes` | policy | policy | negado | negado | imutável pelo banco |
| `service_order_status_history` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `revisions` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `stock_movements` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `cash_movements` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |
| `sale_items` | policy | policy | policy | policy | **UPDATE/DELETE permitidos pela RLS — imutabilidade só na aplicação** |

Triggers não internos no banco (0): nenhum.

### F. Colunas sensíveis a revisar (nome sugere segredo, hash, documento ou dado pessoal) — 48

Só nomes e tipos; nenhum valor foi lido. Confirmar, para cada uma, se o conteúdo é cifrado/hash ou dado pessoal sujeito à LGPD.

| Tabela | Coluna | Tipo |
|---|---|---|
| `activations` | `ipAddress` | text |
| `agreement_companies` | `cnpj` | text |
| `agreement_companies` | `phone` | text |
| `agreement_companies` | `email` | text |
| `audit_logs` | `ipAddress` | text |
| `branches` | `document` | text |
| `branches` | `address` | text |
| `branches` | `phone` | text |
| `branches` | `email` | text |
| `channel_api_credentials` | `secretEncrypted` | text |
| `channel_api_credentials` | `secretHint` | text |
| `companies` | `document` | text |
| `companies` | `email` | text |
| `companies` | `phone` | text |
| `customers` | `document` | text |
| `customers` | `email` | text |
| `customers` | `phone` | text |
| `customers` | `birthDate` | timestamp(3) without time zone |
| `customers` | `address` | text |
| `device_sessions` | `ipAddress` | text |
| `devices` | `macAddress` | text |
| `devices` | `ipAddress` | text |
| `devices` | `secretHash` | text |
| `employee_agreements` | `cpf` | text |
| `fiscal_configs` | `certificatePassword` | text |
| `fiscal_configs` | `cscToken` | text |
| `fiscal_documents` | `documentType` | "FiscalDocumentType" |
| `idempotency_keys` | `requestHash` | text |
| `motorcycles` | `licensePlate` | text |
| `motorcycles` | `chassisNumber` | text |
| `refresh_tokens` | `token` | text |
| `refresh_tokens` | `ipAddress` | text |
| `sales_channels` | `credentialsEncrypted` | text |
| `sales_channels` | `credentialsHint` | text |
| `suppliers` | `document` | text |
| `suppliers` | `email` | text |
| `suppliers` | `phone` | text |
| `suppliers` | `address` | text |
| `suppliers` | `addressComplement` | text |
| `suppliers` | `addressNumber` | text |
| `support_tickets` | `requesterEmail` | text |
| `support_tickets` | `requesterPhone` | text |
| `users` | `email` | text |
| `users` | `phone` | text |
| `users` | `password` | text |
| `users` | `emailVerified` | boolean |
| `users` | `mfaSecret` | text |
| `users` | `mfaBackupCodes` | text[] |

### G. Tipos, defaults e fuso horário

| Verificação | Resultado |
|---|---|
| Colunas `numeric` sem precisão/escala (valor monetário sem limite) | 0 |
| Colunas de ponto flutuante (`double precision`/`real`/`money`) | 12: `device_telemetry`, `monitoring_alerts`, `monitoring_threshold_changes`, `monitoring_thresholds` — só métricas de monitoramento/telemetria (nenhuma financeira) |
| `timestamp` SEM fuso | 273 colunas (o Prisma grava em UTC); com fuso: 0 |
| Dessas, com `DEFAULT CURRENT_TIMESTAMP`/`now()` no BANCO | 110 — o default do banco usa o fuso da SESSÃO (`timezone` do servidor consultado: **America/Sao_Paulo**); linhas criadas por SQL direto (migrations, scripts) podem ficar em hora local enquanto as criadas pelo Prisma ficam em UTC |

### H. Índices redundantes — 6 idênticos a outro e 34 que são só o início de outro

**Idênticos (mesmas colunas de um índice único ou de outro índice) — 6:**

- `device_telemetry_deviceId_collectedAt_idx` ("deviceId", "collectedAt") = `device_telemetry_deviceId_collectedAt_key` (único) em `device_telemetry`
- `fiscal_documents_accessKey_idx` ("accessKey") = `fiscal_documents_accessKey_key` (único) em `fiscal_documents`
- `invoices_accessKey_idx` ("accessKey") = `invoices_accessKey_key` (único) em `invoices`
- `payments_transactionId_idx` ("transactionId") = `payments_transactionId_key` (único) em `payments`
- `refresh_tokens_token_idx` (token) = `refresh_tokens_token_key` (único) em `refresh_tokens`
- `users_email_idx` (email) = `users_email_key` (único) em `users`

**Início de outro índice (btree comum, sem WHERE) — 34:**

- `accounts_payable_companyId_idx` ("companyId") ⊂ `accounts_payable_companyId_status_idx` ("companyId", status) em `accounts_payable`
- `accounts_receivable_companyId_idx` ("companyId") ⊂ `accounts_receivable_companyId_status_idx` ("companyId", status) em `accounts_receivable`
- `audit_logs_companyId_idx` ("companyId") ⊂ `audit_logs_companyId_createdAt_idx` ("companyId", "createdAt") em `audit_logs`
- `audit_logs_userId_idx` ("userId") ⊂ `audit_logs_userId_action_idx` ("userId", action) em `audit_logs`
- `cash_registers_branchId_idx` ("branchId") ⊂ `cash_registers_branchId_status_idx` ("branchId", status) em `cash_registers`
- `cash_registers_userId_idx` ("userId") ⊂ `cash_registers_userId_status_idx` ("userId", status) em `cash_registers`
- `company_module_settings_companyId_idx` ("companyId") ⊂ `company_module_settings_companyId_branchId_idx` ("companyId", "branchId") em `company_module_settings`
- `customers_companyId_idx` ("companyId") ⊂ `customers_companyId_document_key` ("companyId", document) em `customers`
- `fiscal_configs_companyId_idx` ("companyId") ⊂ `fiscal_configs_companyId_branchId_key` ("companyId", "branchId") em `fiscal_configs`
- `fiscal_documents_companyId_idx` ("companyId") ⊂ `fiscal_documents_companyId_branchId_documentType_series_num_key` ("companyId", "branchId", "documentType", series, number) em `fiscal_documents`
- `installment_policies_companyId_idx` ("companyId") ⊂ `installment_policies_companyId_branchId_paymentMethod_key` ("companyId", "branchId", "paymentMethod") em `installment_policies`
- `inventories_branchId_idx` ("branchId") ⊂ `inventories_branchId_inventoryNumber_key` ("branchId", "inventoryNumber") em `inventories`
- `inventory_counts_inventoryId_idx` ("inventoryId") ⊂ `inventory_counts_inventoryId_productId_key` ("inventoryId", "productId") em `inventory_counts`
- `invoices_companyId_idx` ("companyId") ⊂ `invoices_companyId_supplierId_invoiceNumber_series_key` ("companyId", "supplierId", "invoiceNumber", series) em `invoices`
- `licenses_companyId_idx` ("companyId") ⊂ `licenses_companyId_status_idx` ("companyId", status) em `licenses`
- `licenses_status_idx` (status) ⊂ `licenses_status_expiryDate_idx` (status, "expiryDate") em `licenses`
- `motorcycles_companyId_idx` ("companyId") ⊂ `motorcycles_companyId_licensePlate_key` ("companyId", "licensePlate") em `motorcycles`
- `partners_companyId_idx` ("companyId") ⊂ `partners_companyId_name_key` ("companyId", name) em `partners`
- `payments_saleId_idx` ("saleId") ⊂ `payments_saleId_status_idx` ("saleId", status) em `payments`
- `product_barcodes_companyId_idx` ("companyId") ⊂ `product_barcodes_companyId_code_key` ("companyId", code) em `product_barcodes`
- `product_images_companyId_idx` ("companyId") ⊂ `product_images_companyId_productId_key` ("companyId", "productId") em `product_images`
- `products_companyId_idx` ("companyId") ⊂ `products_companyId_id_key` ("companyId", id) em `products`
- `purchase_orders_companyId_idx` ("companyId") ⊂ `purchase_orders_companyId_branchId_poNumber_key` ("companyId", "branchId", "poNumber") em `purchase_orders`
- `quote_versions_quoteId_idx` ("quoteId") ⊂ `quote_versions_quoteId_versionNumber_key` ("quoteId", "versionNumber") em `quote_versions`
- `quotes_companyId_idx` ("companyId") ⊂ `quotes_companyId_quoteNumber_key` ("companyId", "quoteNumber") em `quotes`
- `sales_branchId_idx` ("branchId") ⊂ `sales_branchId_saleDate_idx` ("branchId", "saleDate") em `sales`
- `sales_companyId_idx` ("companyId") ⊂ `sales_companyId_branchId_saleNumber_key` ("companyId", "branchId", "saleNumber") em `sales`
- `sales_channels_companyId_idx` ("companyId") ⊂ `sales_channels_companyId_branchId_idx` ("companyId", "branchId") em `sales_channels`
- `service_orders_branchId_idx` ("branchId") ⊂ `service_orders_branchId_osNumber_key` ("branchId", "osNumber") em `service_orders`
- `stock_movements_branchId_idx` ("branchId") ⊂ `stock_movements_branchId_productId_idx` ("branchId", "productId") em `stock_movements`
- `stock_movements_productId_idx` ("productId") ⊂ `stock_movements_productId_createdAt_idx` ("productId", "createdAt") em `stock_movements`
- `suppliers_companyId_idx` ("companyId") ⊂ `suppliers_companyId_document_key` ("companyId", document) em `suppliers`
- `transfers_companyId_idx` ("companyId") ⊂ `transfers_companyId_transferNumber_key` ("companyId", "transferNumber") em `transfers`
- `users_companyId_idx` ("companyId") ⊂ `users_companyId_isActive_idx` ("companyId", "isActive") em `users`

Remover índice redundante é ganho de escrita/espaço, não correção: nada foi removido (decisão com medição de uso — `pg_stat_user_indexes` — em staging).

<!-- db-docs:findings:end -->
