# Relatório de execução — revisão técnica do banco (2026-10-14, 2ª rodada)

> Missão: auditar e corrigir o banco de dados do CÓRTEX (PostgreSQL + Prisma + RLS) sem tocar em bancos compartilhados, staging ou produção, sem commit, push ou deploy, e sem criar a conta Super Admin. Este arquivo lista **o que foi feito, com quais comandos, o que passou, o que falhou e o que depende de decisão humana**. Análise dos achados: [REVISAO_BANCO_PENDENCIAS](REVISAO_BANCO_PENDENCIAS.md). Decisões: [DECISIONS](DECISIONS.md) (124–135).

## 1. Linha de base (Fase 1)

| Item | Observado |
|---|---|
| Git | branch `master`, HEAD `e243ae1`, sem remote e sem stash; no início desta missão 84 arquivos modificados e 60 novos (alterações de rodadas anteriores, **preservadas**) |
| Schema e migrations | 106 modelos / 106 tabelas; 36 migrations (`migration_lock.toml` = postgresql); hashes do pacote anterior (`SHA256SUMS.txt`, 38 itens) conferiam |
| Ambiente | PostgreSQL 18.6 (Windows, local) e Redis locais; bancos `lnsystem_db` (dev) e `lnsystem_test` (teste), ambos com dados sintéticos |
| Papel de conexão | `lnsystem`: não superusuário, sem `BYPASSRLS`, **dono** das tabelas; papel de leitura `lnsystem_backup` (BYPASSRLS, somente leitura) usado só para contagens |

## 2. Resultado dos três achados iniciais

| Achado | Classe | Resultado |
|---|---|---|
| A — numeração dos chamados | SQL **nunca foi migration**: saída de `prisma migrate diff` (schema antigo). Risco de deriva **confirmado** | `schema.prisma`: `ticketNumber @default(autoincrement())`. Nenhuma mudança de banco; sequência intacta (dev 1012, teste 1704; 0 chamados); 12 chamados em paralelo → 12 números distintos (teste) |
| B — índice da busca | idem. Coluna `search` é **gerada e armazenada**; GIN existe e é utilizável (EXPLAIN com `enable_seqscan=off`) | `schema.prisma`: `search` com `dbgenerated`, `@@index([search], type: Gin)`, `updatedAt @default(now())`. Diff **vazio**. B-02: sob RLS o GIN não é usado pelo papel da aplicação (irrelevante no volume atual) |
| C — referência cruzada | **Confirmado** (teste vermelho: 6 de 8) | FK composta + guarda + índices; 8/8 verdes; achado derivado C-03 (validação de FK cega sob FORCE RLS) corrigido com guarda e testado com dado cruzado |

## 3. Arquivos alterados e criados nesta missão

**Schema e migrations**
- `packages/database/prisma/schema.prisma` (modificado): `SupportTicket.ticketNumber`, `SupportKbCategory.updatedAt`, `SupportKbArticle` (`updatedAt`, `search`, `@@index`), `ProductBarcode.product` e `ProductImage.product` (relações compostas, `@@unique([companyId, productId])`), `Product @@unique([companyId, id])`.
- **Migrations novas (4):** `20261014155900_guard_product_children_same_company`, `20261014160000_product_children_same_company`, `20261014161000_product_images_company_product_unique`, `20261014162000_rls_logs_roles_tighten`. Nenhuma lê ou altera linha; cada cabeçalho traz a reversão.

**Testes novos (integração, Postgres e Redis reais):** `product-children-same-company` (8), `support-schema-objects` (5), `rls-logs-roles-tighten` (6).

**Scripts:** `apps/api/scripts/db-docs.ts` (novas verificações: FKs declaradas × dados, candidatas a referência cruzada com contagem, tipos/fuso, índices redundantes, §4.3/4.4 do relatório de migrations), `apps/api/scripts/db-replay-check.ts` (cenário com dado inconsistente; diff vazio como invariante).

**Documentação:** `BANCO_DE_DADOS.md`, `DECISIONS.md`, `RELATORIO_MIGRATIONS.md`, `MAPA_RELACIONAMENTOS.md`, `REVISAO_BANCO_PENDENCIAS.md` (os cinco exigidos), `SECURITY.md`, `PRODUCAO.md`, `CHANGELOG.md`, `CURRENT_STATE.md`, `CODE_MAP.md`, `README.md`, este relatório, e o pacote `revisao-banco/`.

## 4. Comandos executados (principais) e resultado

| Comando | Ambiente | Resultado |
|---|---|---|
| `prisma validate` | schema | válido |
| `prisma migrate diff --from-schema-datasource … --to-schema-datamodel …` | dev | **antes:** 7 instruções (a saída apresentada na revisão); **depois:** vazio |
| `prisma db pull --print` (somente impressão) | dev | confirmou a forma canônica (`autoincrement()`, `dbgenerated`, `type: Gin`) |
| `prisma migrate deploy` | dev e teste | 4 migrations aplicadas; `migrate status`: "Database schema is up to date" (40) |
| `npm run db:replay-check` | banco temporário vazio + 2º banco temporário com dado sintético cruzado | 40 migrations do zero = catálogo do dev (3 339 itens iguais), diff vazio, `db:check-rls` OK; **cenário com dado:** guarda falha, nada fica pela metade, recuperação conclui; bancos temporários removidos |
| `npm run db:docs -- --write --orphans` | dev (papel de leitura para contagens) | gera os documentos; 109 FKs sem violação; 183 relações sem FK com 10 grupos de órfãos (logs de teste, 7 `idempotency_keys`, 1 recebível de teste); 66 candidatas a referência cruzada, 0 linhas cruzadas |
| `EXPLAIN (ANALYZE, BUFFERS)` da busca da base de conhecimento | teste (somente leitura) | GIN utilizável sem `seqscan`; consulta real faz varredura (ver B-02) |
| Experimentos **revertidos** (`BEGIN … ROLLBACK`) | teste | provaram C-03 (validação de FK cega sob FORCE RLS) e medições de visibilidade por empresa (136 `refresh_tokens`, 371 `system_logs`, 3 540 `request_logs`) |
| `npx tsc --noEmit` (API, Admin Web, Super Admin, Balcão, PDV) | — | limpo |
| `npm run lint` (API) | — | 0 erros, 8 avisos |
| `npm test` (API) | unitário | **112 suítes / 1118 testes aprovados** |
| `npm run test:integration` (API) | teste | **111 suítes / 1579 testes aprovados — 2 rodadas seguidas**; rodada 1 com `PG_ENV_DEBUG=1`: 0 conexão sobrando em cada um dos 111 arquivos |
| `npm run db:check-rls` | dev e banco reaplicado | todas as invariantes OK |
| `npm run backup:verify` | dev → banco temporário | 18/18 verificações |
| `npm run build` (API) | — | ok |
| Playwright: `admin-web-flow` + `catalog-and-help` + `support-contextual-buttons` | dev (API + Admin Web) | 22/22; `request_logs` continuou crescendo (+213 linhas): os logs ainda são gravados com a RLS nova |
| `git diff --check` | repositório | sem erro (só avisos de fim de linha) |

## 5. Testes reprovados, falhas e correções de rumo (sem esconder)

- **Vermelhos intencionais (provas do defeito):** `product-children-same-company` 6 de 8 antes da migration; `rls-logs-roles-tighten` 4 de 6 antes da migration. Ambos verdes depois.
- **Erro meu corrigido:** a primeira versão do cabeçalho de `20261014160000` prometia que a migration "falha e nada muda" se houvesse dado cruzado. O experimento revertido **refutou** isso (a validação da FK pelo dono sob FORCE RLS passa em branco). Criada a guarda `20261014155900`, corrigido o comentário e reconciliado o checksum em dev/teste ([RELATORIO_MIGRATIONS §4.4](RELATORIO_MIGRATIONS.md)).
- **Validação do Prisma:** a relação 1:1 `Product.image` com FK composta exigiu `@@unique([companyId, productId])` em `ProductImage` → migration `20261014161000`.
- **Script de réplica:** `npx prisma` fora do repositório baixou o CLI 7.10 (incompatível); passou a usar o CLI do monorepo. Uma exceção `EBUSY` ao apagar a pasta temporária derrubava o resultado; agora é tolerada e registrada.
- **Falha única não reproduzida:** numa execução combinada (`product-children-same-company product-images product-barcode support`) a suíte `support.integration` reprovou 14 testes logo depois da execução vermelha; reexecutada sozinha e em conjunto, e em **2 rodadas completas** depois das migrations finais, passou. Causa **não determinada** (hipótese: resíduo/limite de requisições da execução vermelha anterior); registrada como falha intermitente não explicada.
- **Resíduos:** três pastas temporárias do script em `%TEMP%` e um arquivo de log gravado por engano na pasta de instalação do Git (movido) — removidos/relocados; nenhum banco temporário sobrou.

## 6. Pendências que exigem decisão humana

Ver [DECISIONS 128–135](DECISIONS.md) e [REVISAO_BANCO_PENDENCIAS §1](REVISAO_BANCO_PENDENCIAS.md): `refresh_tokens` (isolamento por empresa + hash do token; **Alta**), FK composta nas outras 66 FKs (por fases), imutabilidade de livros por RLS, `CASCADE` → `RESTRICT` e FK do `companyId` financeiro (1 recebível órfão de teste mantido), separação do papel dono × execução (infraestrutura), fuso horário, índices duplicados, busca da base de conhecimento sob RLS. E, como antes: staging/PostgreSQL 18 em Linux, backup em outro host, retenção de logs e revisão jurídica da LGPD.

## 7. Garantias de segurança desta missão

- Nenhum commit, push, deploy ou migration em staging/produção; **Super Admin não criado** (nenhum `admin:bootstrap --apply`).
- Nenhum registro de banco compartilhado apagado, truncado, anonimizado ou reescrito; o recebível órfão de teste e as 4 vendas do sandbox foram mantidos.
- Nenhuma credencial ou URL com senha nos documentos; os documentos trazem só estrutura e números.
