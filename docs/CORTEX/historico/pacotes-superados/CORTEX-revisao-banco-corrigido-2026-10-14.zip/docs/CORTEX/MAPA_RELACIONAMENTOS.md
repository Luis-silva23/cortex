# Mapa de relacionamentos do banco de dados

> Gerado em 2026-10-14 por `npm run db:docs -- --write` a partir do catálogo do PostgreSQL de **desenvolvimento** (PostgreSQL 18.6 on x86_64-windows), sem ler dado de negócio. Complementa [BANCO_DE_DADOS](BANCO_DE_DADOS.md) (por tabela) e [REVISAO_BANCO_PENDENCIAS](REVISAO_BANCO_PENDENCIAS.md) (riscos).

## 1. Como ler

- **FK declarada** = chave estrangeira real no banco (ao apagar o pai: ver a regra).
- **Relação lógica (sem FK)** = coluna `…Id` cujo nome aponta um modelo, mas **sem** chave estrangeira — a convenção do projeto para quase todo dado de empresa/filial (o isolamento vem da **RLS**, não de FK). É **inferida pelo nome da coluna** (heurística) e deve ser conferida; o que não resolve para um modelo aparece em §6.
- Contagens: **106 tabelas**, **109 FKs declaradas**, **45 relações lógicas sem FK** inferidas (fora `companyId`/`branchId`), 31 colunas `…Id` sem alvo inferido.

## 2. Cadeias principais (empresa → filial → usuário → catálogo → estoque → venda → caixa → compra → pagamento)

Cada linha é verificada contra o catálogo: **FK** (declarada), **lógica** (coluna existe, sem FK) ou **coluna não encontrada**.

| Módulo | Filho.coluna | → Pai | Situação | Ao apagar o pai |
|---|---|---|---|---|
| Empresa/filial | `branches.companyId` | `companies` | **FK** | CASCADE |
| Empresa/filial | `licenses.companyId` | `companies` | **FK** | CASCADE |
| Empresa/filial | `invoices.companyId` | `companies` | lógica (sem FK) | — |
| Usuários | `users.companyId` | `companies` | **FK** | CASCADE |
| Usuários | `users.branchId` | `branches` | **FK** | SET NULL |
| Usuários | `user_roles.userId` | `users` | **FK** | CASCADE |
| Usuários | `user_roles.roleId` | `roles` | **FK** | CASCADE |
| Usuários | `role_permissions.roleId` | `roles` | **FK** | CASCADE |
| Usuários | `role_permissions.permissionId` | `permissions` | **FK** | CASCADE |
| Usuários | `refresh_tokens.userId` | `users` | **FK** | CASCADE |
| Produtos | `products.categoryId` | `categories` | **FK** | SET NULL |
| Produtos | `products.companyId` | `companies` | lógica (sem FK) | — |
| Produtos | `product_barcodes.productId` | `products` | lógica (sem FK) | — |
| Produtos | `product_images.productId` | `products` | lógica (sem FK) | — |
| Produtos | `combo_items.productId` | `products` | **FK** | CASCADE |
| Estoque | `stock_movements.productId` | `products` | **FK** | CASCADE |
| Estoque | `stock_movements.branchId` | `branches` | lógica (sem FK) | — |
| Estoque | `stock_movements.userId` | `users` | lógica (sem FK) | — |
| Estoque | `stock_reservations.productId` | `products` | **FK** | RESTRICT |
| Estoque | `transfer_items.transferId` | `transfers` | **FK** | CASCADE |
| Estoque | `transfer_items.productId` | `products` | **FK** | RESTRICT |
| Estoque | `inventory_counts.inventoryId` | `inventories` | **FK** | CASCADE |
| Estoque | `inventory_counts.productId` | `products` | **FK** | RESTRICT |
| Estoque | `damage_records.productId` | `products` | **FK** | RESTRICT |
| Vendas | `sales.customerId` | `customers` | **FK** | SET NULL |
| Vendas | `sales.userId` | `users` | **FK** | RESTRICT |
| Vendas | `sales.branchId` | `branches` | lógica (sem FK) | — |
| Vendas | `sales.cashRegisterId` | `cash_registers` | lógica (sem FK) | — |
| Vendas | `sale_items.saleId` | `sales` | **FK** | CASCADE |
| Vendas | `sale_items.productId` | `products` | **FK** | RESTRICT |
| Caixa | `cash_registers.branchId` | `branches` | lógica (sem FK) | — |
| Caixa | `cash_registers.userId` | `users` | lógica (sem FK) | — |
| Caixa | `cash_movements.cashRegisterId` | `cash_registers` | **FK** | CASCADE |
| Pagamentos | `payments.saleId` | `sales` | **FK** | CASCADE |
| Pagamentos | `tef_payments.saleId` | `sales` | lógica (sem FK) | — |
| Pagamentos | `payment_exceptions.paymentId` | `payments` | **FK** | RESTRICT |
| Compras | `purchase_orders.supplierId` | `suppliers` | **FK** | RESTRICT |
| Compras | `purchase_order_items.purchaseOrderId` | `purchase_orders` | **FK** | CASCADE |
| Compras | `purchase_order_items.productId` | `products` | **FK** | RESTRICT |
| Compras | `supplier_returns.supplierId` | `suppliers` | **FK** | RESTRICT |
| Compras | `supplier_return_items.returnId` | `supplier_returns` | **FK** | RESTRICT |
| Financeiro | `accounts_receivable.customerId` | `customers` | lógica (sem FK) | — |
| Financeiro | `accounts_payable.supplierId` | `suppliers` | lógica (sem FK) | — |
| Financeiro | `collection_attempts.receivableId` | `accounts_receivable` | **FK** | RESTRICT |
| Oficina | `service_orders.customerId` | `customers` | **FK** | RESTRICT |
| Oficina | `service_orders.motorcycleId` | `motorcycles` | **FK** | RESTRICT |
| Oficina | `service_order_items.serviceOrderId` | `service_orders` | **FK** | CASCADE |
| Oficina | `motorcycles.customerId` | `customers` | **FK** | RESTRICT |
| Fiscal | `fiscal_documents.saleId` | `sales` | lógica (sem FK) | — |
| Fiscal | `fiscal_documents.serviceOrderId` | `service_orders` | lógica (sem FK) | — |
| Canais | `external_orders.channelId` | `sales_channels` | **FK** | RESTRICT |
| Canais | `external_order_items.orderId` | `external_orders` | **FK** | RESTRICT |
| Canais | `channel_product_links.productId` | `products` | **FK** | RESTRICT |
| Privacidade (subjectId é polimórfico, conforme subjectType) | `privacy_requests.subjectId` | `customers` | lógica (sem FK) | — |
| Equipamento | `device_sessions.deviceId` | `devices` | **FK** | CASCADE |

Linhas "coluna não encontrada": **0** (nome da coluna difere do esperado; ver a tabela em [BANCO_DE_DADOS](BANCO_DE_DADOS.md)).

## 3. Chaves estrangeiras declaradas (todas)

Total **109**. Por regra ao apagar o pai: CASCADE 41 · RESTRICT 54 · SET NULL 14.

| Domínio (filho) | Filho.coluna | → Pai.coluna | Ao apagar | Ao atualizar |
|---|---|---|---|---|
| Plataforma, identidade e acesso | `activations.deviceId` | `devices.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `activations.licenseId` | `licenses.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `activations.userId` | `users.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `branches.companyId` | `companies.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `device_sessions.deviceId` | `devices.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `device_sessions.userId` | `users.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `devices.licenseId` | `licenses.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `invoices.purchaseOrderId` | `purchase_orders.id` | SET NULL | CASCADE |
| Plataforma, identidade e acesso | `invoices.supplierId` | `suppliers.id` | RESTRICT | CASCADE |
| Plataforma, identidade e acesso | `licenses.companyId` | `companies.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `permissions.companyId` | `companies.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `refresh_tokens.userId` | `users.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `role_permissions.permissionId` | `permissions.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `role_permissions.roleId` | `roles.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `roles.companyId` | `companies.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `user_roles.roleId` | `roles.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `user_roles.userId` | `users.id` | CASCADE | CASCADE |
| Plataforma, identidade e acesso | `users.branchId` | `branches.id` | SET NULL | CASCADE |
| Plataforma, identidade e acesso | `users.companyId` | `companies.id` | CASCADE | CASCADE |
| Auditoria, observabilidade e operação | `audit_logs.companyId` | `companies.id` | CASCADE | CASCADE |
| Auditoria, observabilidade e operação | `audit_logs.userId` | `users.id` | SET NULL | CASCADE |
| Auditoria, observabilidade e operação | `privacy_requests.companyId` | `companies.id` | CASCADE | CASCADE |
| Políticas e calendário | `installment_policies.companyId` | `companies.id` | CASCADE | CASCADE |
| Catálogo e estoque | `categories.parentId` | `categories.id` | SET NULL | CASCADE |
| Catálogo e estoque | `combo_items.comboId` | `products.id` | CASCADE | CASCADE |
| Catálogo e estoque | `combo_items.productId` | `products.id` | CASCADE | CASCADE |
| Catálogo e estoque | `damage_records.productId` | `products.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `inventory_counts.inventoryId` | `inventories.id` | CASCADE | CASCADE |
| Catálogo e estoque | `inventory_counts.productId` | `products.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `product_barcodes.companyId` | `companies.id` | CASCADE | CASCADE |
| Catálogo e estoque | `product_barcodes.companyId, productId` | `products.companyId, id` | RESTRICT | CASCADE |
| Catálogo e estoque | `product_images.companyId` | `companies.id` | CASCADE | CASCADE |
| Catálogo e estoque | `product_images.companyId, productId` | `products.companyId, id` | CASCADE | CASCADE |
| Catálogo e estoque | `products.categoryId` | `categories.id` | SET NULL | CASCADE |
| Catálogo e estoque | `purchase_order_items.productId` | `products.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `purchase_order_items.purchaseOrderId` | `purchase_orders.id` | CASCADE | CASCADE |
| Catálogo e estoque | `purchase_orders.supplierId` | `suppliers.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `stock_movements.productId` | `products.id` | CASCADE | CASCADE |
| Catálogo e estoque | `stock_reservations.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `stock_reservations.orderId` | `external_orders.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `stock_reservations.productId` | `products.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `supplier_return_events.returnId` | `supplier_returns.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `supplier_return_items.productId` | `products.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `supplier_return_items.returnId` | `supplier_returns.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `supplier_returns.supplierId` | `suppliers.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `transfer_items.productId` | `products.id` | RESTRICT | CASCADE |
| Catálogo e estoque | `transfer_items.transferId` | `transfers.id` | CASCADE | CASCADE |
| Clientes, veículos e pós-venda | `appointment_events.appointmentId` | `appointments.id` | CASCADE | CASCADE |
| Clientes, veículos e pós-venda | `appointments.customerId` | `customers.id` | RESTRICT | CASCADE |
| Clientes, veículos e pós-venda | `appointments.followUpId` | `follow_ups.id` | SET NULL | CASCADE |
| Clientes, veículos e pós-venda | `appointments.motorcycleId` | `motorcycles.id` | SET NULL | CASCADE |
| Clientes, veículos e pós-venda | `follow_up_events.followUpId` | `follow_ups.id` | CASCADE | CASCADE |
| Clientes, veículos e pós-venda | `follow_ups.customerId` | `customers.id` | RESTRICT | CASCADE |
| Clientes, veículos e pós-venda | `follow_ups.motorcycleId` | `motorcycles.id` | RESTRICT | CASCADE |
| Clientes, veículos e pós-venda | `follow_ups.revisionId` | `revisions.id` | SET NULL | CASCADE |
| Clientes, veículos e pós-venda | `motorcycles.customerId` | `customers.id` | RESTRICT | CASCADE |
| Clientes, veículos e pós-venda | `revisions.customerId` | `customers.id` | RESTRICT | CASCADE |
| Clientes, veículos e pós-venda | `revisions.motorcycleId` | `motorcycles.id` | RESTRICT | CASCADE |
| Clientes, veículos e pós-venda | `revisions.serviceOrderId` | `service_orders.id` | SET NULL | CASCADE |
| Vendas, caixa e pagamento | `cash_movements.cashRegisterId` | `cash_registers.id` | CASCADE | CASCADE |
| Vendas, caixa e pagamento | `partners.companyId` | `companies.id` | CASCADE | CASCADE |
| Vendas, caixa e pagamento | `payment_exceptions.paymentId` | `payments.id` | RESTRICT | CASCADE |
| Vendas, caixa e pagamento | `payments.saleId` | `sales.id` | CASCADE | CASCADE |
| Vendas, caixa e pagamento | `sale_items.productId` | `products.id` | RESTRICT | CASCADE |
| Vendas, caixa e pagamento | `sale_items.saleId` | `sales.id` | CASCADE | CASCADE |
| Vendas, caixa e pagamento | `sales.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Vendas, caixa e pagamento | `sales.customerId` | `customers.id` | SET NULL | CASCADE |
| Vendas, caixa e pagamento | `sales.partnerId` | `partners.id` | SET NULL | CASCADE |
| Vendas, caixa e pagamento | `sales.userId` | `users.id` | RESTRICT | CASCADE |
| Financeiro e convênios | `collection_attempts.receivableId` | `accounts_receivable.id` | RESTRICT | CASCADE |
| Financeiro e convênios | `employee_agreement_charges.agreementId` | `employee_agreements.id` | RESTRICT | CASCADE |
| Financeiro e convênios | `employee_payroll_deductions.chargeId` | `employee_agreement_charges.id` | RESTRICT | CASCADE |
| Financeiro e convênios | `mechanic_commissions.serviceOrderId` | `service_orders.id` | RESTRICT | CASCADE |
| Oficina | `quote_events.quoteId` | `quotes.id` | CASCADE | CASCADE |
| Oficina | `quote_items.quoteVersionId` | `quote_versions.id` | CASCADE | CASCADE |
| Oficina | `quote_versions.quoteId` | `quotes.id` | CASCADE | CASCADE |
| Oficina | `quotes.customerId` | `customers.id` | RESTRICT | CASCADE |
| Oficina | `quotes.motorcycleId` | `motorcycles.id` | RESTRICT | CASCADE |
| Oficina | `service_order_items.productId` | `products.id` | SET NULL | CASCADE |
| Oficina | `service_order_items.serviceOrderId` | `service_orders.id` | CASCADE | CASCADE |
| Oficina | `service_order_status_history.serviceOrderId` | `service_orders.id` | CASCADE | CASCADE |
| Oficina | `service_order_warranties.serviceOrderId` | `service_orders.id` | RESTRICT | CASCADE |
| Oficina | `service_orders.customerId` | `customers.id` | RESTRICT | CASCADE |
| Oficina | `service_orders.mechanicId` | `users.id` | SET NULL | CASCADE |
| Oficina | `service_orders.motorcycleId` | `motorcycles.id` | RESTRICT | CASCADE |
| Oficina | `service_orders.quoteVersionId` | `quote_versions.id` | SET NULL | CASCADE |
| Oficina | `vehicle_entry_checklist_items.checklistId` | `vehicle_entry_checklists.id` | CASCADE | CASCADE |
| Oficina | `vehicle_entry_checklists.motorcycleId` | `motorcycles.id` | RESTRICT | CASCADE |
| Oficina | `vehicle_entry_checklists.serviceOrderId` | `service_orders.id` | CASCADE | CASCADE |
| Oficina | `warranty_claims.warrantyId` | `service_order_warranties.id` | RESTRICT | CASCADE |
| Canais e integração | `channel_api_credentials.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `channel_events.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `channel_inbound_events.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `channel_outbox.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `channel_product_links.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `channel_product_links.productId` | `products.id` | RESTRICT | CASCADE |
| Canais e integração | `external_order_items.orderId` | `external_orders.id` | RESTRICT | CASCADE |
| Canais e integração | `external_order_items.productId` | `products.id` | RESTRICT | CASCADE |
| Canais e integração | `external_orders.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `external_orders.saleId` | `sales.id` | RESTRICT | CASCADE |
| Canais e integração | `external_payments.channelId` | `sales_channels.id` | RESTRICT | CASCADE |
| Canais e integração | `external_payments.orderId` | `external_orders.id` | RESTRICT | CASCADE |
| Canais e integração | `fulfillments.orderId` | `external_orders.id` | RESTRICT | CASCADE |
| Canais e integração | `fulfillments.saleId` | `sales.id` | RESTRICT | CASCADE |
| Ajuda e Suporte | `support_kb_articles.categoryId` | `support_kb_categories.id` | RESTRICT | CASCADE |
| Ajuda e Suporte | `support_ticket_attachments.messageId` | `support_ticket_messages.id` | RESTRICT | CASCADE |
| Ajuda e Suporte | `support_ticket_attachments.ticketId` | `support_tickets.id` | RESTRICT | CASCADE |
| Ajuda e Suporte | `support_ticket_events.ticketId` | `support_tickets.id` | RESTRICT | CASCADE |
| Ajuda e Suporte | `support_ticket_messages.ticketId` | `support_tickets.id` | RESTRICT | CASCADE |

## 4. Escopo de empresa e filial (sem FK — isolamento por RLS)

- Tabelas com `companyId`: **85** — sem FK para `companies`: **74** (por convenção; a policy RLS filtra por `companyId`).
- Tabelas com `branchId`: **65** — sem FK para `branches`: **64**.
- Tabelas **sem** `companyId` (21): `access_revocations`, `activations`, `appointment_events`, `cash_movements`, `combo_items`, `companies`, `devices`, `follow_up_events`, `inventory_counts`, `purchase_order_items`, `quote_items`, `quote_versions`, `role_permissions`, `sale_items`, `service_order_items`, `service_order_status_history`, `support_kb_articles`, `support_kb_categories`, `transfer_items`, `user_roles`, `vehicle_entry_checklist_items`.

Consequência: o banco **não impede** gravar um `companyId` inexistente nem uma filial de outra empresa; quem impede é a RLS (`WITH CHECK`) e a camada de serviço. Ver o risco em [REVISAO_BANCO_PENDENCIAS](REVISAO_BANCO_PENDENCIAS.md).

## 5. Relações lógicas sem FK (inferidas por nome — conferir)

Alvos mais referenciados sem FK: `users` 10 · `sales` 5 · `service_orders` 5 · `customers` 3 · `agreement_companies` 3 · `products` 3 · `employee_agreements` 2 · `devices` 2 · `payments` 2 · `branches` 2 · `suppliers` 1 · `quotes` 1.

| Domínio (origem) | Origem.coluna | → Alvo inferido |
|---|---|---|
| Plataforma, identidade e acesso | `device_telemetry.deviceId` | `devices` |
| Plataforma, identidade e acesso | `device_telemetry.userId` | `users` |
| Plataforma, identidade e acesso | `refresh_tokens.deviceSessionId` | `device_sessions` |
| Auditoria, observabilidade e operação | `idempotency_keys.userId` | `users` |
| Auditoria, observabilidade e operação | `import_batches.userId` | `users` |
| Auditoria, observabilidade e operação | `monitoring_alerts.deviceId` | `devices` |
| Auditoria, observabilidade e operação | `request_logs.userId` | `users` |
| Auditoria, observabilidade e operação | `system_logs.userId` | `users` |
| Catálogo e estoque | `product_barcodes.productId` | `products` |
| Catálogo e estoque | `product_images.productId` | `products` |
| Catálogo e estoque | `stock_movements.userId` | `users` |
| Catálogo e estoque | `supplier_return_events.userId` | `users` |
| Catálogo e estoque | `supplier_return_items.damageRecordId` | `damage_records` |
| Catálogo e estoque | `supplier_returns.purchaseOrderId` | `purchase_orders` |
| Catálogo e estoque | `transfers.fromBranchId` | `branches` |
| Catálogo e estoque | `transfers.toBranchId` | `branches` |
| Vendas, caixa e pagamento | `cash_movements.userId` | `users` |
| Vendas, caixa e pagamento | `cash_registers.userId` | `users` |
| Vendas, caixa e pagamento | `discount_events.saleId` | `sales` |
| Vendas, caixa e pagamento | `discount_events.serviceOrderId` | `service_orders` |
| Vendas, caixa e pagamento | `discount_events.quoteId` | `quotes` |
| Vendas, caixa e pagamento | `discount_rules.roleId` | `roles` |
| Vendas, caixa e pagamento | `payment_exceptions.saleId` | `sales` |
| Vendas, caixa e pagamento | `payments.agreementCompanyId` | `agreement_companies` |
| Vendas, caixa e pagamento | `payments.employeeAgreementId` | `employee_agreements` |
| Vendas, caixa e pagamento | `sales.cashRegisterId` | `cash_registers` |
| Vendas, caixa e pagamento | `tef_payments.saleId` | `sales` |
| Vendas, caixa e pagamento | `tef_payments.serviceOrderId` | `service_orders` |
| Vendas, caixa e pagamento | `tef_payments.paymentId` | `payments` |
| Financeiro e convênios | `accounts_payable.supplierId` | `suppliers` |
| Financeiro e convênios | `accounts_receivable.customerId` | `customers` |
| Financeiro e convênios | `accounts_receivable.agreementCompanyId` | `agreement_companies` |
| Financeiro e convênios | `accounts_receivable.employeeAgreementId` | `employee_agreements` |
| Financeiro e convênios | `collection_attempts.agreementCompanyId` | `agreement_companies` |
| Financeiro e convênios | `employee_agreement_charges.saleId` | `sales` |
| Financeiro e convênios | `employee_agreement_charges.paymentId` | `payments` |
| Financeiro e convênios | `employee_agreements.userId` | `users` |
| Financeiro e convênios | `employee_agreements.customerId` | `customers` |
| Oficina | `quote_items.productId` | `products` |
| Oficina | `service_order_warranties.customerId` | `customers` |
| Oficina | `service_order_warranties.motorcycleId` | `motorcycles` |
| Oficina | `warranty_claims.serviceOrderId` | `service_orders` |
| Oficina | `warranty_claims.newServiceOrderId` | `service_orders` |
| Fiscal | `fiscal_documents.saleId` | `sales` |
| Fiscal | `fiscal_documents.serviceOrderId` | `service_orders` |

## 6. Colunas `…Id` sem FK e sem alvo inferido

`accounts_payable.referenceId`, `accounts_receivable.referenceId`, `agenda_unavailabilities.mechanicId`, `appointments.mechanicId`, `audit_logs.entityId`, `cash_movements.referenceId`, `channel_api_credentials.keyId`, `channel_events.correlationId`, `channel_events.actorId`, `channel_inbound_events.externalEventId`, `channel_inbound_events.correlationId`, `channel_outbox.correlationId`, `channel_product_links.externalId`, `employee_payroll_deductions.agreementId`, `external_orders.correlationId`, `fiscal_configs.cscId`, `mechanic_commissions.mechanicId`, `payment_settings.terminalId`, `payments.transactionId`, `privacy_requests.subjectId`, `request_logs.requestId`, `sales_channels.externalAccountId`, `stock_movements.referenceId`, `support_kb_articles.authorId`, `support_ticket_events.actorId`, `support_ticket_messages.authorId`, `support_tickets.requesterId`, `support_tickets.assignedToId`, `system_logs.requestId`, `tef_payments.transactionId`, `users.numericId`

São identificadores externos (ex.: provedor, canal), referências polimórficas ou nomes que não coincidem com um modelo. Não é afirmação de que estejam corretos: cabe revisão humana.

## 7. Tabelas sem nenhum relacionamento (nem FK nem lógico)

`access_revocations` (Plataforma, identidade e acesso; plataforma/global), `agenda_unavailabilities` (Políticas e calendário; empresa+filial), `business_calendar_exceptions` (Políticas e calendário; empresa+filial), `business_hours` (Políticas e calendário; empresa+filial), `commission_rules` (Financeiro e convênios; empresa), `company_module_settings` (Plataforma, identidade e acesso; empresa+filial), `fiscal_configs` (Fiscal; empresa+filial), `health_incidents` (Auditoria, observabilidade e operação; empresa+filial), `monitoring_threshold_changes` (Auditoria, observabilidade e operação; empresa+filial), `monitoring_thresholds` (Auditoria, observabilidade e operação; empresa+filial), `payment_settings` (Políticas e calendário; empresa+filial), `policy_changes` (Políticas e calendário; empresa+filial), `policy_settings` (Políticas e calendário; empresa+filial)

## 8. Diagramas por domínio (Mermaid)

Linha cheia = FK declarada; linha pontilhada = relação lógica sem FK (inferida). `companyId`/`branchId` sem FK não são desenhados (ver §4).

### Plataforma, identidade e acesso

```mermaid
erDiagram
  devices ||--o{ activations : "deviceId"
  licenses ||--o{ activations : "licenseId"
  users ||--o{ activations : "userId"
  companies ||--o{ branches : "companyId"
  devices ||--o{ device_sessions : "deviceId"
  users ||--o{ device_sessions : "userId"
  devices ||..o{ device_telemetry : "deviceId sem FK"
  users ||..o{ device_telemetry : "userId sem FK"
  licenses ||--o{ devices : "licenseId"
  purchase_orders ||--o{ invoices : "purchaseOrderId"
  suppliers ||--o{ invoices : "supplierId"
  companies ||--o{ licenses : "companyId"
  companies ||--o{ permissions : "companyId"
  users ||--o{ refresh_tokens : "userId"
  device_sessions ||..o{ refresh_tokens : "deviceSessionId sem FK"
  permissions ||--o{ role_permissions : "permissionId"
  roles ||--o{ role_permissions : "roleId"
  companies ||--o{ roles : "companyId"
  roles ||--o{ user_roles : "roleId"
  users ||--o{ user_roles : "userId"
  branches ||--o{ users : "branchId"
  companies ||--o{ users : "companyId"
```

### Auditoria, observabilidade e operação

```mermaid
erDiagram
  companies ||--o{ audit_logs : "companyId"
  users ||--o{ audit_logs : "userId"
  users ||..o{ idempotency_keys : "userId sem FK"
  users ||..o{ import_batches : "userId sem FK"
  devices ||..o{ monitoring_alerts : "deviceId sem FK"
  companies ||--o{ privacy_requests : "companyId"
  users ||..o{ request_logs : "userId sem FK"
  users ||..o{ system_logs : "userId sem FK"
```

### Políticas e calendário

```mermaid
erDiagram
  companies ||--o{ installment_policies : "companyId"
```

### Catálogo e estoque

```mermaid
erDiagram
  categories ||--o{ categories : "parentId"
  products ||--o{ combo_items : "comboId"
  products ||--o{ combo_items : "productId"
  products ||--o{ damage_records : "productId"
  inventories ||--o{ inventory_counts : "inventoryId"
  products ||--o{ inventory_counts : "productId"
  companies ||--o{ product_barcodes : "companyId"
  products ||--o{ product_barcodes : "companyId, productId"
  products ||..o{ product_barcodes : "productId sem FK"
  companies ||--o{ product_images : "companyId"
  products ||--o{ product_images : "companyId, productId"
  products ||..o{ product_images : "productId sem FK"
  categories ||--o{ products : "categoryId"
  products ||--o{ purchase_order_items : "productId"
  purchase_orders ||--o{ purchase_order_items : "purchaseOrderId"
  suppliers ||--o{ purchase_orders : "supplierId"
  products ||--o{ stock_movements : "productId"
  users ||..o{ stock_movements : "userId sem FK"
  sales_channels ||--o{ stock_reservations : "channelId"
  external_orders ||--o{ stock_reservations : "orderId"
  products ||--o{ stock_reservations : "productId"
  supplier_returns ||--o{ supplier_return_events : "returnId"
  users ||..o{ supplier_return_events : "userId sem FK"
  products ||--o{ supplier_return_items : "productId"
  supplier_returns ||--o{ supplier_return_items : "returnId"
  damage_records ||..o{ supplier_return_items : "damageRecordId sem FK"
  suppliers ||--o{ supplier_returns : "supplierId"
  purchase_orders ||..o{ supplier_returns : "purchaseOrderId sem FK"
  products ||--o{ transfer_items : "productId"
  transfers ||--o{ transfer_items : "transferId"
  branches ||..o{ transfers : "fromBranchId sem FK"
  branches ||..o{ transfers : "toBranchId sem FK"
```

### Clientes, veículos e pós-venda

```mermaid
erDiagram
  appointments ||--o{ appointment_events : "appointmentId"
  customers ||--o{ appointments : "customerId"
  follow_ups ||--o| appointments : "followUpId"
  motorcycles ||--o{ appointments : "motorcycleId"
  follow_ups ||--o{ follow_up_events : "followUpId"
  customers ||--o{ follow_ups : "customerId"
  motorcycles ||--o{ follow_ups : "motorcycleId"
  revisions ||--o{ follow_ups : "revisionId"
  customers ||--o{ motorcycles : "customerId"
  customers ||--o{ revisions : "customerId"
  motorcycles ||--o{ revisions : "motorcycleId"
  service_orders ||--o{ revisions : "serviceOrderId"
```

### Vendas, caixa e pagamento

```mermaid
erDiagram
  cash_registers ||--o{ cash_movements : "cashRegisterId"
  users ||..o{ cash_movements : "userId sem FK"
  users ||..o{ cash_registers : "userId sem FK"
  sales ||..o{ discount_events : "saleId sem FK"
  service_orders ||..o{ discount_events : "serviceOrderId sem FK"
  quotes ||..o{ discount_events : "quoteId sem FK"
  roles ||..o{ discount_rules : "roleId sem FK"
  companies ||--o{ partners : "companyId"
  payments ||--o{ payment_exceptions : "paymentId"
  sales ||..o{ payment_exceptions : "saleId sem FK"
  sales ||--o{ payments : "saleId"
  agreement_companies ||..o{ payments : "agreementCompanyId sem FK"
  employee_agreements ||..o{ payments : "employeeAgreementId sem FK"
  products ||--o{ sale_items : "productId"
  sales ||--o{ sale_items : "saleId"
  sales_channels ||--o{ sales : "channelId"
  customers ||--o{ sales : "customerId"
  partners ||--o{ sales : "partnerId"
  users ||--o{ sales : "userId"
  cash_registers ||..o{ sales : "cashRegisterId sem FK"
  sales ||..o{ tef_payments : "saleId sem FK"
  service_orders ||..o{ tef_payments : "serviceOrderId sem FK"
  payments ||..o{ tef_payments : "paymentId sem FK"
```

### Financeiro e convênios

```mermaid
erDiagram
  suppliers ||..o{ accounts_payable : "supplierId sem FK"
  customers ||..o{ accounts_receivable : "customerId sem FK"
  agreement_companies ||..o{ accounts_receivable : "agreementCompanyId sem FK"
  employee_agreements ||..o{ accounts_receivable : "employeeAgreementId sem FK"
  accounts_receivable ||--o{ collection_attempts : "receivableId"
  agreement_companies ||..o{ collection_attempts : "agreementCompanyId sem FK"
  employee_agreements ||--o{ employee_agreement_charges : "agreementId"
  sales ||..o{ employee_agreement_charges : "saleId sem FK"
  payments ||..o{ employee_agreement_charges : "paymentId sem FK"
  users ||..o{ employee_agreements : "userId sem FK"
  customers ||..o{ employee_agreements : "customerId sem FK"
  employee_agreement_charges ||--o{ employee_payroll_deductions : "chargeId"
  service_orders ||--o{ mechanic_commissions : "serviceOrderId"
```

### Oficina

```mermaid
erDiagram
  quotes ||--o{ quote_events : "quoteId"
  quote_versions ||--o{ quote_items : "quoteVersionId"
  products ||..o{ quote_items : "productId sem FK"
  quotes ||--o{ quote_versions : "quoteId"
  customers ||--o{ quotes : "customerId"
  motorcycles ||--o{ quotes : "motorcycleId"
  products ||--o{ service_order_items : "productId"
  service_orders ||--o{ service_order_items : "serviceOrderId"
  service_orders ||--o{ service_order_status_history : "serviceOrderId"
  service_orders ||--o| service_order_warranties : "serviceOrderId"
  customers ||..o{ service_order_warranties : "customerId sem FK"
  motorcycles ||..o{ service_order_warranties : "motorcycleId sem FK"
  customers ||--o{ service_orders : "customerId"
  users ||--o{ service_orders : "mechanicId"
  motorcycles ||--o{ service_orders : "motorcycleId"
  quote_versions ||--o| service_orders : "quoteVersionId"
  vehicle_entry_checklists ||--o{ vehicle_entry_checklist_items : "checklistId"
  motorcycles ||--o{ vehicle_entry_checklists : "motorcycleId"
  service_orders ||--o| vehicle_entry_checklists : "serviceOrderId"
  service_order_warranties ||--o{ warranty_claims : "warrantyId"
  service_orders ||..o{ warranty_claims : "serviceOrderId sem FK"
  service_orders ||..o{ warranty_claims : "newServiceOrderId sem FK"
```

### Fiscal

```mermaid
erDiagram
  sales ||..o{ fiscal_documents : "saleId sem FK"
  service_orders ||..o{ fiscal_documents : "serviceOrderId sem FK"
```

### Canais e integração

```mermaid
erDiagram
  sales_channels ||--o{ channel_api_credentials : "channelId"
  sales_channels ||--o{ channel_events : "channelId"
  sales_channels ||--o{ channel_inbound_events : "channelId"
  sales_channels ||--o{ channel_outbox : "channelId"
  sales_channels ||--o{ channel_product_links : "channelId"
  products ||--o{ channel_product_links : "productId"
  external_orders ||--o{ external_order_items : "orderId"
  products ||--o{ external_order_items : "productId"
  sales_channels ||--o{ external_orders : "channelId"
  sales ||--o| external_orders : "saleId"
  sales_channels ||--o{ external_payments : "channelId"
  external_orders ||--o{ external_payments : "orderId"
  external_orders ||--o| fulfillments : "orderId"
  sales ||--o| fulfillments : "saleId"
```

### Ajuda e Suporte

```mermaid
erDiagram
  support_kb_categories ||--o{ support_kb_articles : "categoryId"
  support_ticket_messages ||--o{ support_ticket_attachments : "messageId"
  support_tickets ||--o{ support_ticket_attachments : "ticketId"
  support_tickets ||--o{ support_ticket_events : "ticketId"
  support_tickets ||--o{ support_ticket_messages : "ticketId"
```

