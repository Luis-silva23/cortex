**Execução de 2026-10-14** (`npm run db:replay-check`) — banco temporário vazio, criado e removido pelo script; o banco de desenvolvimento só foi lido. Resultado: **IDÊNTICO — nada no banco de desenvolvimento escapa das migrations**.

- `prisma migrate deploy` em banco vazio: sucesso (40 migrations encontradas em `prisma/migrations`).
- `prisma migrate diff` (banco → schema.prisma): banco reaplicado do zero e banco de desenvolvimento produzem **exatamente a mesma saída** — **vazia (0 instruções): o `schema.prisma` descreve exatamente o banco**.
- Catálogo completo (colunas, índices, constraints, policies, RLS, triggers, funções, sequências, enums): dev = 3339 itens, reaplicado = 3339 itens; **só no dev: 0**; **só no reaplicado: 0**.
- PostgreSQL: PostgreSQL 18.6 on x86_64-windows.
- `db:check-rls` no banco reaplicado: todas as invariantes OK — [check-rls] "lnsystem_db_replay_tmp": todas as invariantes de RLS OK
- Banco temporário removido: sim.

**Cenário com dados inconsistentes (migration das FKs compostas):**

- Banco temporário 2: 36 migrations aplicadas (até a anterior à FK composta): sucesso.
- Dados sintéticos: 2 empresas, 1 produto em cada e **1 código de barras da empresa A apontando para o produto da empresa B** (aceito pela FK antiga); linhas cruzadas confirmadas antes do deploy: 1.
- `migrate deploy` completo com a linha inconsistente: **falhou como esperado** (a migration `20261014155900_guard_product_children_same_company` recusou o dado cruzado).
- Atomicidade: depois da falha, índice composto 0, FK composta 0, FK antiga 1 → **nada ficou aplicado pela metade**.
- Recuperação (corrigir a linha → `migrate resolve --rolled-back 20261014155900_guard_product_children_same_company` → `migrate deploy`): **concluiu**, as 2 FKs compostas existem.
- Banco temporário 2 removido: sim.
