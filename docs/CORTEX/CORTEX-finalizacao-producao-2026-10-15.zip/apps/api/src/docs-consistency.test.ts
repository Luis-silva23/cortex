import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

/**
 * COERÊNCIA DA DOCUMENTAÇÃO DO BANCO COM O REPOSITÓRIO (sem banco, sem rede).
 * Motivo: a entrega de 2026-10-15 declarava 50 migrations, mas um documento disponível ainda dizia 40 e listava como pendentes itens já
 * corrigidos. Este teste impede a deriva: contagem de migrations, ausência de afirmações superadas nos documentos VIGENTES, links internos
 * que resolvem, decisões 128–140 sem "AGUARDANDO", todas as migrations listadas no relatório e — quando o pacote existe — o SHA-256 do ZIP
 * igual ao do manifesto.
 */
const REPO = path.resolve(__dirname, '../../..');
const DOCS = path.join(REPO, 'docs/CORTEX');
const MIG_DIR = path.join(REPO, 'packages/database/prisma/migrations');
const read = (rel: string) => fs.readFileSync(path.join(DOCS, rel), 'utf8').replace(/\r\n/g, '\n');
const migrations = fs.readdirSync(MIG_DIR).filter((d) => fs.statSync(path.join(MIG_DIR, d)).isDirectory()).sort();

// documentos que descrevem o estado ATUAL (não os históricos datados)
const CURRENT_DOCS = [
  'BANCO_DE_DADOS.md',
  'REVISAO_BANCO_PENDENCIAS.md',
  'RELATORIO_EXECUCAO_REVISAO_BANCO.md',
  'RELATORIO_MIGRATIONS.md',
  'MAPA_RELACIONAMENTOS.md',
  'CURRENT_STATE.md',
  'README.md',
  'contracts/tenant-branch-scope.md',
  'contracts/permission-matrix.md',
  'BACKUP_RECUPERACAO.md',
  'RELATORIO_FINALIZACAO_PRODUCAO.md',
];

describe('documentação do banco × repositório', () => {
  it('as migrations do repositório são 52 e cada uma aparece no RELATORIO_MIGRATIONS', () => {
    expect(migrations).toHaveLength(52);
    const rel = read('RELATORIO_MIGRATIONS.md');
    const missing = migrations.filter((m) => !rel.includes(m));
    expect(missing).toEqual([]);
  });

  it('os documentos principais declaram a contagem real de migrations', () => {
    const n = migrations.length;
    for (const f of ['BANCO_DE_DADOS.md', 'REVISAO_BANCO_PENDENCIAS.md', 'RELATORIO_EXECUCAO_REVISAO_BANCO.md', 'RELATORIO_MIGRATIONS.md', 'CURRENT_STATE.md']) {
      expect({ f, ok: new RegExp(`\\b${n}\\b`).test(read(f)) }).toEqual({ f, ok: true });
    }
    expect(read('BANCO_DE_DADOS.md')).toMatch(new RegExp(`as \\*\\*${n}\\*\\* migrations aplicadas do zero`));
  });

  it('nenhum documento vigente afirma o estado superado (40 migrations, refresh_tokens em texto, pendências já corrigidas)', () => {
    const stale: Array<[RegExp, string]> = [
      [/\b40 migra(ções|tions)\b/, '40 migrations'],
      [/\b36 migra(ções|tions)\b/, '36 migrations'],
      [/aguarda decisão 128/i, 'refresh_tokens aguardando decisão'],
      [/\*\*AGUARDANDO DECISÃO\*\* \(Alta\)/, 'item Alta aguardando decisão'],
      [/R1–R16/, 'riscos R1–R16 em aberto'],
      [/refresh_tokens.{0,40}sem isolamento por empresa e com o token em texto/i, 'refresh_tokens sem isolamento'],
    ];
    const hits: string[] = [];
    for (const f of CURRENT_DOCS) {
      const text = read(f);
      for (const [rx, label] of stale) {
        // linhas que descrevem o estado ANTERIOR de propósito (histórico/cenário "até a anterior") são marcadas e ignoradas
        const offending = text.split('\n').filter((l) => rx.test(l) && !/histórico|HISTÓRICO|até a anterior|superad/i.test(l));
        if (offending.length) hits.push(`${f}: ${label}`);
      }
    }
    expect(hits).toEqual([]);
  });

  it('as decisões 128 a 140 não estão "AGUARDANDO DECISÃO"; as que dependem do dono ou da infraestrutura estão marcadas assim', () => {
    const decisions = read('DECISIONS.md').split('\n');
    for (let n = 128; n <= 140; n++) {
      const row = decisions.find((l) => l.startsWith(`| ${n} |`));
      expect({ n, found: !!row }).toEqual({ n, found: true });
      expect({ n, aguardando: /AGUARDANDO DECIS/.test(row!) && n !== 135 }).toEqual({ n, aguardando: false });
    }
    for (const n of [141, 142]) {
      const row = decisions.find((l) => l.startsWith(`| ${n} |`))!;
      expect(row).toMatch(/PENDENTE-(DECISÃO|INFRA)/);
    }
  });

  it('as decisões 143 a 148 (escopo por filial, travas, compose) estão concluídas; 149 e 150 (backup/infra) ficam pendentes e dizem isso', () => {
    const decisions = read('DECISIONS.md').split('\n');
    for (let n = 143; n <= 148; n++) {
      const row = decisions.find((l) => l.startsWith(`| ${n} |`));
      expect({ n, found: !!row }).toEqual({ n, found: true });
      expect({ n, concluida: /CONCLUÍDA/.test(row!) }).toEqual({ n, concluida: true });
    }
    expect(decisions.find((l) => l.startsWith('| 149 |'))).toMatch(/PENDENTE-DECISÃO/);
    expect(decisions.find((l) => l.startsWith('| 150 |'))).toMatch(/PENDENTE-INFRA/);
  });

  it('o backup tem script, agenda, ensaio de restauração e documento; o RPO/RTO está proposto e marcado como pendente de aprovação', () => {
    for (const f of ['deploy/backup/backup.sh', 'deploy/backup/entrypoint.sh', 'deploy/backup/Dockerfile', 'deploy/postgres-init/10-roles.sh', 'deploy/postgres-init/after-migrate.sql', 'apps/api/scripts/restore-drill.ts']) {
      expect({ f, existe: fs.existsSync(path.join(REPO, f)) }).toEqual({ f, existe: true });
    }
    const doc = read('BACKUP_RECUPERACAO.md');
    expect(doc).toMatch(/RPO/);
    expect(doc).toMatch(/RTO/);
    expect(doc).toMatch(/PENDENTE DE APROVAÇÃO/);
    const script = fs.readFileSync(path.join(REPO, 'deploy/backup/backup.sh'), 'utf8');
    expect(script).toMatch(/pg_dump -Fc/);
    expect(script).not.toMatch(/PGPASSWORD=['"]?[A-Za-z0-9]{6,}/); // nenhuma senha escrita no script
  });

  it('o compose não conecta nenhum serviço como superusuário e o backup usa papel próprio', () => {
    const compose = fs.readFileSync(path.join(REPO, 'docker-compose.yml'), 'utf8');
    const apiDb = /api:[\s\S]*?DATABASE_URL: "postgresql:\/\/\$\{DB_APP_USER/.test(compose);
    const migrateDb = /migrate:[\s\S]*?DATABASE_URL: "postgresql:\/\/\$\{DB_OWNER_USER/.test(compose);
    expect({ apiDb, migrateDb }).toEqual({ apiDb: true, migrateDb: true });
    expect(compose).not.toMatch(/DATABASE_URL: "postgresql:\/\/\$\{POSTGRES_USER/);
    expect(compose).toMatch(/BACKUP_DATABASE_URL: "postgresql:\/\/\$\{DB_BACKUP_USER/);
  });

  it('os links internos dos documentos vigentes resolvem para arquivos que existem', () => {
    const broken: string[] = [];
    for (const f of CURRENT_DOCS) {
      const dir = path.dirname(path.join(DOCS, f));
      for (const m of read(f).matchAll(/\]\((?!https?:|#|mailto:)([^)\s]+)\)/g)) {
        const target = decodeURI(m[1].split('#')[0]);
        if (!target) continue;
        if (!fs.existsSync(path.resolve(dir, target))) broken.push(`${f} → ${m[1]}`);
      }
    }
    expect(broken).toEqual([]);
  });

  it('o pacote ZIP final, quando existe, tem o SHA-256 igual ao do manifesto', () => {
    const zip = path.join(DOCS, 'CORTEX-finalizacao-producao-2026-10-15.zip');
    const manifest = path.join(DOCS, 'SHA256SUMS-finalizacao-producao-2026-10-15.txt');
    if (!fs.existsSync(zip) || !fs.existsSync(manifest)) return; // gerado no fechamento; sem ele não há o que conferir
    const actual = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
    const line = fs.readFileSync(manifest, 'utf8').split(/\r?\n/).find((l) => l.endsWith('CORTEX-finalizacao-producao-2026-10-15.zip'));
    expect(line).toBeDefined();
    expect(line!.slice(0, 64)).toBe(actual);
  });
});
