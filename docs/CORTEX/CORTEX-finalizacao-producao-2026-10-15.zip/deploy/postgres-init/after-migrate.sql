-- PRIVILÉGIOS DA APLICAÇÃO E DO BACKUP DEPOIS DAS MIGRATIONS (idempotente; rodar como o DONO das tabelas após CADA `prisma migrate deploy`).
--   psql -v ON_ERROR_STOP=1 -v app=lnsystem_app -v bkp=lnsystem_backup -f after-migrate.sql <url do dono>
-- Papel da API: só DML (nada de DDL, TRUNCATE nem posse). _prisma_migrations fica ILEGÍVEL para ele (uma falha na aplicação não reescreve o histórico).
-- Papel de backup: SELECT em tudo (BYPASSRLS vem do próprio papel), inclusive _prisma_migrations (o manifesto do backup conta as migrações aplicadas).
-- Mesmo modelo de deploy/db-runtime-role.sql, que continua válido para bancos que já existem.

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO :"app";
REVOKE ALL ON TABLE public."_prisma_migrations" FROM :"app";
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO :"app";
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO :"app";

GRANT SELECT ON ALL TABLES IN SCHEMA public TO :"bkp";
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO :"bkp";
