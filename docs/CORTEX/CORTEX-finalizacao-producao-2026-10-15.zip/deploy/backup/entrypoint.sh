#!/bin/sh
# Ponto de entrada do serviço `backup`: monta o ambiente do cron e o agendamento e fica em primeiro plano (crond).
#   00:00 (fuso BACKUP_TZ, padrão America/Sao_Paulo)  backup completo + retenção
#   12:00                                             verificação de integridade (hash + leitura do sumário), SEM novo dump
# Segredos: as variáveis PG* e as de backup são gravadas em /etc/backup.env (modo 600, dono postgres) para o cron — nunca em log.
set -eu

: "${PGHOST:?defina PGHOST}"; : "${PGUSER:?defina PGUSER}"; : "${PGPASSWORD:?defina PGPASSWORD}"; : "${PGDATABASE:?defina PGDATABASE}"
export TZ="${BACKUP_TZ:-America/Sao_Paulo}"

umask 077
{
  for v in PGHOST PGPORT PGUSER PGPASSWORD PGDATABASE PGSSLMODE BACKUP_DIR BACKUP_PREFIX KEEP_DAILY KEEP_WEEKLY KEEP_MONTHLY \
           BACKUP_ENCRYPTION_KEY_FILE BACKUP_OFFSITE_CMD BACKUP_ALERT_CMD BACKUP_MAX_AGE_HOURS TZ; do
    eval "val=\${$v:-}"
    [ -n "$val" ] && printf "export %s='%s'\n" "$v" "$(printf '%s' "$val" | sed "s/'/'\\\\''/g")"
  done
} > /etc/backup.env
chown postgres:postgres /etc/backup.env; chmod 600 /etc/backup.env
export BACKUP_DIR="${BACKUP_DIR:-/backups}"
mkdir -p "$BACKUP_DIR"; chown postgres:postgres "$BACKUP_DIR"; chmod 700 "$BACKUP_DIR"

cat > /etc/crontabs/postgres <<'EOF'
0 0 * * * . /etc/backup.env; /opt/backup/backup.sh backup; /opt/backup/backup.sh prune
0 12 * * * . /etc/backup.env; /opt/backup/backup.sh verify
EOF
chmod 600 /etc/crontabs/postgres

# primeira execução: se ainda não existe nenhum backup, não espere até a meia-noite (BACKUP_RUN_ON_START=0 desliga)
if [ "${BACKUP_RUN_ON_START:-1}" = "1" ] && ! ls "$BACKUP_DIR" | grep -q '[.]dump'; then
  su postgres -s /bin/sh -c '. /etc/backup.env; /opt/backup/backup.sh backup' || echo "[backup] primeiro backup falhou — veja $BACKUP_DIR/backup.log"
fi

echo "[backup] agenda ativa: 00:00 backup+retenção, 12:00 verificação (fuso $TZ)"
exec crond -f -l 8 -L /dev/stdout
